--
-- PostgreSQL database dump
--

\restrict bZZcbRdii1dkMa7O6qIapMTOJLSQnshgmkgU2aSVjLAIz2XTiXCojw3hdeVfJgP

-- Dumped from database version 17.11 (Debian 17.11-1.pgdg12+2)
-- Dumped by pg_dump version 17.11 (Debian 17.11-1.pgdg12+2)

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET transaction_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: ops; Type: SCHEMA; Schema: -; Owner: -
--

CREATE SCHEMA ops;


--
-- Name: btree_gist; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS btree_gist WITH SCHEMA public;


--
-- Name: EXTENSION btree_gist; Type: COMMENT; Schema: -; Owner: -
--

COMMENT ON EXTENSION btree_gist IS 'support for indexing common datatypes in GiST';


--
-- Name: pg_trgm; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS pg_trgm WITH SCHEMA public;


--
-- Name: EXTENSION pg_trgm; Type: COMMENT; Schema: -; Owner: -
--

COMMENT ON EXTENSION pg_trgm IS 'text similarity measurement and index searching based on trigrams';


--
-- Name: pgcrypto; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS pgcrypto WITH SCHEMA public;


--
-- Name: EXTENSION pgcrypto; Type: COMMENT; Schema: -; Owner: -
--

COMMENT ON EXTENSION pgcrypto IS 'cryptographic functions';


--
-- Name: appointment_kind; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.appointment_kind AS ENUM (
    'on_site',
    'remote',
    'internal',
    'personal'
);


--
-- Name: appointment_status; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.appointment_status AS ENUM (
    'scheduled',
    'in_progress',
    'done',
    'cancelled'
);


--
-- Name: attachment_kind; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.attachment_kind AS ENUM (
    'ticket_comment',
    'email_message',
    'ticket'
);


--
-- Name: board_role; Type: TYPE; Schema: public; Owner: -
--

CREATE TYPE public.board_role AS ENUM (
    'viewer',
    'member',
    'admin'
);


--
-- Name: alert_source_auth_lookup(text); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.alert_source_auth_lookup(p_source_ref text) RETURNS TABLE(r_id uuid, r_org_id uuid, r_source_ref text, r_board_id uuid, r_client_id uuid, r_secret_encrypted bytea, r_correlation_window_secs integer, r_enabled boolean)
    LANGUAGE sql STABLE SECURITY DEFINER
    SET search_path TO 'public'
    AS $$
  SELECT id, org_id, source_ref, board_id, client_id, secret_encrypted,
         correlation_window_secs, enabled
  FROM alert_sources
  WHERE source_ref = p_source_ref
$$;


--
-- Name: api_key_auth_lookup(text); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.api_key_auth_lookup(p_key_hash text) RETURNS TABLE(id uuid, org_id uuid, name text, key_hash text, prefix text, scopes jsonb, created_by uuid, last_used_at timestamp with time zone, revoked_at timestamp with time zone, created_at timestamp with time zone)
    LANGUAGE sql STABLE SECURITY DEFINER
    SET search_path TO 'public'
    AS $$
  SELECT id, org_id, name, key_hash, prefix, scopes, created_by,
         last_used_at, revoked_at, created_at
  FROM api_keys
  WHERE key_hash = p_key_hash AND revoked_at IS NULL
$$;


--
-- Name: api_key_touch_last_used(uuid, integer); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.api_key_touch_last_used(p_key_id uuid, p_min_interval_secs integer) RETURNS void
    LANGUAGE sql SECURITY DEFINER
    SET search_path TO 'public'
    AS $$
  UPDATE api_keys SET last_used_at = now()
  WHERE id = p_key_id
    AND (last_used_at IS NULL
         OR last_used_at < now() - make_interval(secs => p_min_interval_secs));
$$;


--
-- Name: app_list_enabled_oidc_providers(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.app_list_enabled_oidc_providers() RETURNS TABLE(org_id uuid, name text, display_name text)
    LANGUAGE sql STABLE SECURITY DEFINER
    SET search_path TO 'public'
    AS $$
  SELECT o.org_id, o.name, o.display_name
  FROM oidc_providers o
  WHERE o.enabled
  ORDER BY o.created_at
  LIMIT 20
$$;


--
-- Name: app_resolve_login(text); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.app_resolve_login(p_email text) RETURNS TABLE(user_id uuid, org_id uuid)
    LANGUAGE sql STABLE SECURITY DEFINER
    SET search_path TO 'public'
    AS $$
  SELECT u.id, u.org_id
  FROM users u
  WHERE lower(u.email) = lower(p_email) AND u.is_active
  LIMIT 1
$$;


--
-- Name: app_resolve_oidc_provider(text); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.app_resolve_oidc_provider(p_name text) RETURNS TABLE(provider_id uuid, org_id uuid, issuer text, discovery_url text, client_id text, jit_provisioning boolean)
    LANGUAGE sql STABLE SECURITY DEFINER
    SET search_path TO 'public'
    AS $$
  SELECT o.id, o.org_id, o.issuer, o.discovery_url, o.client_id, o.jit_provisioning
  FROM oidc_providers o
  WHERE o.name = p_name AND o.enabled
  ORDER BY o.created_at
  LIMIT 1
$$;


--
-- Name: app_resolve_refresh(uuid, text); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.app_resolve_refresh(p_session_id uuid, p_token_hash text) RETURNS TABLE(user_id uuid, org_id uuid, chain_id uuid, active boolean)
    LANGUAGE sql STABLE SECURITY DEFINER
    SET search_path TO 'public'
    AS $$
  SELECT s.user_id, u.org_id, s.chain_id, (s.revoked_at IS NULL AND s.expires_at > now())
  FROM auth_sessions s
  JOIN users u ON u.id = s.user_id
  WHERE s.id = p_session_id
    AND s.refresh_token_hash = p_token_hash
    AND u.is_active
  LIMIT 1
$$;


--
-- Name: app_resolve_session(uuid, text); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.app_resolve_session(p_session_id uuid, p_token_hash text) RETURNS TABLE(user_id uuid, org_id uuid)
    LANGUAGE sql STABLE SECURITY DEFINER
    SET search_path TO 'public'
    AS $$
  SELECT s.user_id, u.org_id
  FROM auth_sessions s
  JOIN users u ON u.id = s.user_id
  WHERE s.id = p_session_id
    AND s.refresh_token_hash = p_token_hash
    AND s.revoked_at IS NULL
    AND s.expires_at > now()
    AND u.is_active
  LIMIT 1
$$;


--
-- Name: app_resolve_sso_code(uuid); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.app_resolve_sso_code(p_code uuid) RETURNS uuid
    LANGUAGE sql STABLE SECURITY DEFINER
    SET search_path TO 'public'
    AS $$
  SELECT c.org_id
  FROM mfa_challenges c
  WHERE c.id = p_code AND c.kind = 'sso_code' AND c.expires_at > now()
  LIMIT 1
$$;


--
-- Name: apply_email_send_result(uuid, boolean, text, text, interval); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.apply_email_send_result(p_id uuid, p_ok boolean, p_provider_id text, p_error text, p_delay interval) RETURNS boolean
    LANGUAGE plpgsql SECURITY DEFINER
    SET search_path TO 'public'
    AS $$
BEGIN
  IF p_ok THEN
    UPDATE email_outbound
       SET status = 'sent', provider_message_id = p_provider_id,
           last_error = NULL, claimed_at = NULL, updated_at = now()
     WHERE id = p_id AND status = 'sending';
  ELSE
    UPDATE email_outbound
       SET status = CASE WHEN attempts >= max_attempts THEN 'dead' ELSE 'queued' END,
           next_attempt_at = CASE WHEN attempts >= max_attempts THEN next_attempt_at
                                  ELSE now() + p_delay END,
           last_error = p_error, provider_message_id = NULL,
           claimed_at = NULL, updated_at = now()
     WHERE id = p_id AND status = 'sending';
  END IF;
  RETURN FOUND;
END
$$;


--
-- Name: claim_due_email_outbound(integer, interval); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.claim_due_email_outbound(p_limit integer, p_lease interval) RETURNS TABLE(r_ledger_id uuid, r_org_id uuid, r_attempts integer, r_max_attempts integer, r_rfc_message_id text, r_from_address text, r_from_name text, r_to_addresses text[], r_subject text, r_body_text text, r_in_reply_to text, r_refs text[])
    LANGUAGE sql SECURITY DEFINER
    SET search_path TO 'public'
    AS $$
  WITH claimed AS (
    UPDATE email_outbound AS q
       SET status = 'sending', claimed_at = now(), updated_at = now(),
           attempts = q.attempts + 1
     WHERE q.id IN (
           SELECT c.id FROM email_outbound c
            WHERE (c.status = 'queued' AND c.next_attempt_at <= now())
               OR (c.status = 'sending' AND c.claimed_at < now() - p_lease)
            ORDER BY c.next_attempt_at
            LIMIT LEAST(GREATEST(p_limit, 1), 1000)
            FOR UPDATE SKIP LOCKED
     )
     RETURNING q.id, q.org_id, q.attempts, q.max_attempts, q.email_message_id
  )
  SELECT cl.id, cl.org_id, cl.attempts, cl.max_attempts,
         m.rfc_message_id, m.from_address, m.from_name, m.to_addresses,
         m.subject, m.body_text, m.in_reply_to, m.email_refs
    FROM claimed cl
    JOIN email_messages m ON m.id = cl.email_message_id
   ORDER BY cl.id
$$;


--
-- Name: portal_resolve_login(text); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.portal_resolve_login(p_email text) RETURNS TABLE(portal_user_id uuid, org_id uuid, client_id uuid)
    LANGUAGE sql STABLE SECURITY DEFINER
    SET search_path TO 'public'
    AS $$
  SELECT pu.id, pu.org_id, pu.client_id
  FROM portal_users pu
  WHERE lower(pu.email) = lower(p_email)
    AND pu.status IN ('active', 'invited')
  LIMIT 1
$$;


--
-- Name: portal_resolve_session(uuid, text); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.portal_resolve_session(p_session_id uuid, p_token_hash text) RETURNS TABLE(portal_user_id uuid, org_id uuid, client_id uuid)
    LANGUAGE sql STABLE SECURITY DEFINER
    SET search_path TO 'public'
    AS $$
  SELECT s.portal_user_id, s.org_id, pu.client_id
  FROM portal_sessions s
  JOIN portal_users pu ON pu.id = s.portal_user_id
  WHERE s.id = p_session_id
    AND s.refresh_token_hash = p_token_hash
    AND s.revoked_at IS NULL
    AND s.expires_at > now()
    AND pu.status = 'active'
  LIMIT 1
$$;


--
-- Name: provenance_diff(jsonb, jsonb); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.provenance_diff(p_before jsonb, p_after jsonb) RETURNS TABLE(field text, prior jsonb, applied jsonb)
    LANGUAGE sql STABLE
    AS $$
  SELECT changed.key,
         p_before -> changed.key,
         p_after -> changed.key
  FROM (
    SELECT key FROM jsonb_object_keys(COALESCE(p_before, '{}'::jsonb)) AS k(key)
    UNION
    SELECT key FROM jsonb_object_keys(COALESCE(p_after, '{}'::jsonb)) AS k(key)
  ) changed
  WHERE (p_before -> changed.key) IS DISTINCT FROM (p_after -> changed.key)
  ORDER BY changed.key;
$$;


--
-- Name: provenance_project_write(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.provenance_project_write() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
  INSERT INTO provenance_events (write_id, field_seq, org_id, entity, entity_id,
                                 seq, op, actor_kind, actor_id, field, before, after,
                                 session_id, skill, ruleset_hash, is_undo,
                                 idempotency_key, occurred_at)
  SELECT NEW.id,
         fields.field_seq,
         NEW.org_id, NEW.entity, NEW.entity_id,
         NEW.seq, NEW.op, NEW.actor_kind, NEW.actor_id,
         fields.field, fields.prior, fields.applied,
         NEW.session_id, NEW.skill, NEW.ruleset_hash, NEW.is_undo,
         NEW.idempotency_key, NEW.created_at
  FROM (
    SELECT row_number() OVER (ORDER BY d.field) AS field_seq,
           d.field, d.prior, d.applied
    FROM provenance_diff(NEW.before, NEW.after) AS d
  ) fields;
  RETURN NEW;
END;
$$;


--
-- Name: resolve_inbound_email_route(text[]); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.resolve_inbound_email_route(p_addresses text[]) RETURNS TABLE(r_org_id uuid, r_board_id uuid)
    LANGUAGE sql STABLE SECURITY DEFINER
    SET search_path TO 'public'
    AS $$
  SELECT x.r_org_id, x.r_board_id FROM (
    SELECT b.org_id AS r_org_id, b.id AS r_board_id, 1 AS prio
      FROM boards b
     WHERE lower(b.inbound_address) = ANY (p_addresses)
    UNION ALL
    SELECT s.org_id, s.catchall_board_id, 2
      FROM email_inbound_settings s
     WHERE s.enabled AND lower(s.catchall_address) = ANY (p_addresses)
  ) x
  ORDER BY x.prio
  LIMIT 1
$$;


SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: entity_writes; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.entity_writes (
    id uuid NOT NULL,
    org_id uuid NOT NULL,
    entity text NOT NULL,
    entity_id uuid NOT NULL,
    seq bigint NOT NULL,
    op text NOT NULL,
    actor_id uuid NOT NULL,
    actor_kind text DEFAULT 'human'::text NOT NULL,
    idempotency_key text,
    before jsonb,
    after jsonb NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    session_id uuid,
    skill text,
    ruleset_hash text,
    is_undo boolean DEFAULT false NOT NULL,
    CONSTRAINT entity_writes_actor_kind_check CHECK ((actor_kind = ANY (ARRAY['human'::text, 'agent'::text, 'plugin'::text, 'connector'::text, 'system'::text, 'portal_contact'::text, 'portal_approver'::text, 'portal_it_manager'::text, 'import'::text])))
);


--
-- Name: v1_field_undo_stack; Type: VIEW; Schema: ops; Owner: -
--

CREATE VIEW ops.v1_field_undo_stack WITH (security_invoker='true') AS
 SELECT w.id,
    w.org_id,
    w.entity,
    w.entity_id,
    w.seq,
    w.op,
    a.key AS field,
    b.value AS prior,
    a.value AS new_value,
    (b.value IS DISTINCT FROM a.value) AS changed,
    w.actor_id,
    w.actor_kind,
    w.created_at
   FROM ((public.entity_writes w
     CROSS JOIN LATERAL jsonb_each(w.after) a(key, value))
     LEFT JOIN LATERAL ( SELECT jsonb_each.key,
            jsonb_each.value
           FROM jsonb_each(w.before) jsonb_each(key, value)) b ON ((b.key = a.key)));


--
-- Name: ticket_comments; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.ticket_comments (
    id uuid NOT NULL,
    org_id uuid NOT NULL,
    ticket_id uuid NOT NULL,
    author_id uuid,
    kind text DEFAULT 'internal'::text NOT NULL,
    body text NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone,
    CONSTRAINT ticket_comments_kind_check CHECK ((kind = ANY (ARRAY['internal'::text, 'client_visible'::text, 'in_house_update'::text])))
);


--
-- Name: ticket_sla_state; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.ticket_sla_state (
    ticket_id uuid NOT NULL,
    org_id uuid NOT NULL,
    policy_id uuid NOT NULL,
    first_response_due timestamp with time zone,
    resolution_due timestamp with time zone,
    first_responded_at timestamp with time zone,
    paused_business_secs bigint DEFAULT 0 NOT NULL,
    paused_since timestamp with time zone,
    breached boolean DEFAULT false NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: tickets; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.tickets (
    id uuid NOT NULL,
    org_id uuid NOT NULL,
    number text NOT NULL,
    board_id uuid NOT NULL,
    status_id uuid NOT NULL,
    title text NOT NULL,
    body text,
    priority text DEFAULT 'p3'::text NOT NULL,
    client_id uuid,
    site_id uuid,
    contact_id uuid,
    assignee_id uuid,
    requester_id uuid,
    category text NOT NULL,
    due_at timestamp with time zone,
    resolved_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT tickets_category_check CHECK ((category = ANY (ARRAY['open'::text, 'in_progress'::text, 'waiting'::text, 'closed'::text]))),
    CONSTRAINT tickets_priority_check CHECK ((priority = ANY (ARRAY['p1'::text, 'p2'::text, 'p3'::text, 'p4'::text])))
);


--
-- Name: v1_first_response; Type: VIEW; Schema: ops; Owner: -
--

CREATE VIEW ops.v1_first_response WITH (security_invoker='true') AS
 SELECT t.id AS ticket_id,
    t.org_id,
    t.number AS ticket_number,
    t.client_id,
    t.assignee_id,
    t.created_at,
    fc.first_staff_comment_at,
        CASE
            WHEN (fc.first_staff_comment_at IS NOT NULL) THEN (EXTRACT(epoch FROM (fc.first_staff_comment_at - t.created_at)))::bigint
            ELSE NULL::bigint
        END AS first_response_secs,
    sl.first_response_due
   FROM ((public.tickets t
     LEFT JOIN LATERAL ( SELECT min(c.created_at) AS first_staff_comment_at
           FROM public.ticket_comments c
          WHERE ((c.ticket_id = t.id) AND (c.author_id IS NOT NULL))) fc ON (true))
     LEFT JOIN public.ticket_sla_state sl ON ((sl.ticket_id = t.id)));


--
-- Name: time_gap_audits; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.time_gap_audits (
    id uuid NOT NULL,
    org_id uuid NOT NULL,
    user_id uuid NOT NULL,
    day date NOT NULL,
    activity boolean NOT NULL,
    logged_minutes integer NOT NULL,
    expected_minutes integer NOT NULL,
    has_gap boolean NOT NULL,
    nudge_sent_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT time_gap_audits_expected_minutes_check CHECK ((expected_minutes >= 0)),
    CONSTRAINT time_gap_audits_logged_minutes_check CHECK ((logged_minutes >= 0))
);


--
-- Name: users; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.users (
    id uuid NOT NULL,
    org_id uuid NOT NULL,
    email text NOT NULL,
    display_name text NOT NULL,
    password_hash text NOT NULL,
    timezone text DEFAULT 'UTC'::text NOT NULL,
    is_active boolean DEFAULT true NOT NULL,
    mfa_totp_secret text,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: v1_gap_days; Type: VIEW; Schema: ops; Owner: -
--

CREATE VIEW ops.v1_gap_days WITH (security_invoker='true') AS
 SELECT g.id,
    g.org_id,
    g.user_id,
    u.display_name AS user_display_name,
    u.timezone AS user_timezone,
    g.day,
    g.activity,
    g.logged_minutes,
    g.expected_minutes,
    g.has_gap,
    g.nudge_sent_at,
    g.updated_at
   FROM (public.time_gap_audits g
     JOIN public.users u ON ((u.id = g.user_id)));


--
-- Name: v1_record_undo_stack; Type: VIEW; Schema: ops; Owner: -
--

CREATE VIEW ops.v1_record_undo_stack WITH (security_invoker='true') AS
 SELECT id,
    org_id,
    entity,
    entity_id,
    seq,
    op,
    actor_id,
    actor_kind,
    idempotency_key,
    before,
    after,
    ((op <> 'create'::text) AND (before IS NOT NULL)) AS restorable,
    created_at
   FROM public.entity_writes w;


--
-- Name: sla_calendars; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.sla_calendars (
    id uuid NOT NULL,
    org_id uuid NOT NULL,
    name text NOT NULL,
    timezone text DEFAULT 'UTC'::text NOT NULL,
    windows jsonb NOT NULL,
    holidays jsonb DEFAULT '[]'::jsonb NOT NULL,
    maintenance jsonb DEFAULT '[]'::jsonb NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: sla_policies; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.sla_policies (
    id uuid NOT NULL,
    org_id uuid NOT NULL,
    name text NOT NULL,
    is_default boolean DEFAULT false NOT NULL,
    targets jsonb NOT NULL,
    calendar jsonb NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    calendar_id uuid
);


--
-- Name: v1_sla_outcomes; Type: VIEW; Schema: ops; Owner: -
--

CREATE VIEW ops.v1_sla_outcomes WITH (security_invoker='true') AS
 SELECT st.ticket_id,
    st.org_id,
    t.number AS ticket_number,
    t.priority,
    t.assignee_id,
    t.created_at AS ticket_created_at,
    p.id AS policy_id,
    p.name AS policy_name,
    cal.name AS calendar_name,
    cal.timezone AS calendar_timezone,
    st.first_response_due,
    st.first_responded_at,
        CASE
            WHEN ((st.first_response_due IS NOT NULL) AND (st.first_responded_at IS NOT NULL)) THEN (st.first_responded_at <= st.first_response_due)
            ELSE NULL::boolean
        END AS response_met,
    st.resolution_due,
    t.resolved_at,
        CASE
            WHEN ((st.resolution_due IS NOT NULL) AND (t.resolved_at IS NOT NULL)) THEN (t.resolved_at <= st.resolution_due)
            ELSE NULL::boolean
        END AS resolution_met,
    st.breached,
    st.paused_business_secs
   FROM (((public.ticket_sla_state st
     JOIN public.sla_policies p ON ((p.id = st.policy_id)))
     LEFT JOIN public.sla_calendars cal ON ((cal.id = p.calendar_id)))
     JOIN public.tickets t ON ((t.id = st.ticket_id)));


--
-- Name: board_statuses; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.board_statuses (
    id uuid NOT NULL,
    board_id uuid NOT NULL,
    org_id uuid NOT NULL,
    name text NOT NULL,
    category text NOT NULL,
    sort_order integer DEFAULT 0 NOT NULL,
    is_entry boolean DEFAULT false NOT NULL,
    color text,
    CONSTRAINT board_statuses_category_check CHECK ((category = ANY (ARRAY['open'::text, 'in_progress'::text, 'waiting'::text, 'closed'::text])))
);


--
-- Name: boards; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.boards (
    id uuid NOT NULL,
    org_id uuid NOT NULL,
    name text NOT NULL,
    description text,
    is_default boolean DEFAULT false NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    inbound_address text,
    require_checklist_close boolean DEFAULT false NOT NULL,
    board_group_id uuid
);


--
-- Name: clients; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.clients (
    id uuid NOT NULL,
    org_id uuid NOT NULL,
    name text NOT NULL,
    restricted_to jsonb DEFAULT '[]'::jsonb NOT NULL,
    notes text,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: v1_tickets; Type: VIEW; Schema: ops; Owner: -
--

CREATE VIEW ops.v1_tickets WITH (security_invoker='true') AS
 SELECT t.id,
    t.org_id,
    t.number,
    t.board_id,
    b.name AS board_name,
    t.status_id,
    s.name AS status_name,
    s.category,
    t.priority,
    t.title,
    t.client_id,
    c.name AS client_name,
    t.site_id,
    t.assignee_id,
    u.display_name AS assignee_name,
    t.requester_id,
    t.due_at,
    t.resolved_at,
    t.created_at,
    t.updated_at,
    sl.first_response_due,
    sl.resolution_due,
    COALESCE(sl.breached, false) AS breached
   FROM (((((public.tickets t
     JOIN public.board_statuses s ON ((s.id = t.status_id)))
     JOIN public.boards b ON ((b.id = t.board_id)))
     LEFT JOIN public.clients c ON ((c.id = t.client_id)))
     LEFT JOIN public.users u ON ((u.id = t.assignee_id)))
     LEFT JOIN public.ticket_sla_state sl ON ((sl.ticket_id = t.id)));


--
-- Name: time_entries; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.time_entries (
    id uuid NOT NULL,
    org_id uuid NOT NULL,
    ticket_id uuid NOT NULL,
    user_id uuid NOT NULL,
    started_at timestamp with time zone NOT NULL,
    ended_at timestamp with time zone NOT NULL,
    minutes integer NOT NULL,
    billable boolean DEFAULT true NOT NULL,
    notes text,
    work_type text,
    timer_session_id uuid,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT time_entries_minutes_check CHECK ((minutes >= 0))
);


--
-- Name: v1_time_entries; Type: VIEW; Schema: ops; Owner: -
--

CREATE VIEW ops.v1_time_entries WITH (security_invoker='true') AS
 SELECT e.id,
    e.org_id,
    e.ticket_id,
    t.number AS ticket_number,
    t.client_id,
    c.name AS client_name,
    e.user_id,
    u.display_name AS user_display_name,
    e.started_at,
    e.ended_at,
    e.minutes,
    e.billable,
    e.work_type,
    ((e.started_at AT TIME ZONE 'UTC'::text))::date AS day_utc,
    e.timer_session_id,
    e.created_at
   FROM (((public.time_entries e
     JOIN public.tickets t ON ((t.id = e.ticket_id)))
     LEFT JOIN public.clients c ON ((c.id = t.client_id)))
     LEFT JOIN public.users u ON ((u.id = e.user_id)));


--
-- Name: _sqlx_migrations; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public._sqlx_migrations (
    version bigint NOT NULL,
    description text NOT NULL,
    installed_on timestamp with time zone DEFAULT now() NOT NULL,
    success boolean NOT NULL,
    checksum bytea NOT NULL,
    execution_time bigint NOT NULL
);


--
-- Name: agent_proposals; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.agent_proposals (
    id uuid NOT NULL,
    org_id uuid NOT NULL,
    entity text NOT NULL,
    entity_id uuid,
    op text NOT NULL,
    before_value jsonb DEFAULT 'null'::jsonb NOT NULL,
    proposed_value jsonb NOT NULL,
    classification text DEFAULT 'internal'::text NOT NULL,
    capability text,
    dial_mode text DEFAULT 'proposed'::text NOT NULL,
    base_version bigint DEFAULT 0 NOT NULL,
    status text DEFAULT 'proposed'::text NOT NULL,
    agent_kind text DEFAULT 'agent'::text NOT NULL,
    agent_ref text NOT NULL,
    skill_slug text,
    skill_version integer,
    rule_set_hash text,
    session_id text,
    tool text,
    for_user uuid,
    rationale text,
    decided_by uuid,
    decided_at timestamp with time zone,
    decision_note text,
    applied_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT agent_proposals_agent_kind_check CHECK ((agent_kind = ANY (ARRAY['agent'::text, 'api-key'::text, 'mcp'::text]))),
    CONSTRAINT agent_proposals_before_value_check CHECK ((jsonb_typeof(before_value) = ANY (ARRAY['object'::text, 'null'::text]))),
    CONSTRAINT agent_proposals_check CHECK (((op <> 'update'::text) OR (entity_id IS NOT NULL))),
    CONSTRAINT agent_proposals_classification_check CHECK ((classification = ANY (ARRAY['internal'::text, 'client_visible'::text, 'external_commit'::text]))),
    CONSTRAINT agent_proposals_dial_mode_check CHECK ((dial_mode = ANY (ARRAY['proposed'::text, 'autonomous'::text]))),
    CONSTRAINT agent_proposals_op_check CHECK ((op = ANY (ARRAY['create'::text, 'update'::text, 'delete'::text]))),
    CONSTRAINT agent_proposals_proposed_value_check CHECK ((jsonb_typeof(proposed_value) = ANY (ARRAY['object'::text, 'null'::text]))),
    CONSTRAINT agent_proposals_status_check CHECK ((status = ANY (ARRAY['proposed'::text, 'approved'::text, 'declined'::text, 'withdrawn'::text, 'applied'::text])))
);


--
-- Name: agent_skills; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.agent_skills (
    id uuid NOT NULL,
    org_id uuid NOT NULL,
    slug text NOT NULL,
    version integer NOT NULL,
    manifest jsonb NOT NULL,
    created_by uuid NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT agent_skills_manifest_check CHECK ((jsonb_typeof(manifest) = 'object'::text)),
    CONSTRAINT agent_skills_slug_check CHECK ((slug ~ '^[a-z0-9][a-z0-9_-]{0,63}$'::text)),
    CONSTRAINT agent_skills_version_check CHECK ((version >= 1))
);


--
-- Name: alert_incidents; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.alert_incidents (
    id uuid NOT NULL,
    org_id uuid NOT NULL,
    source_id uuid NOT NULL,
    correlation_key text NOT NULL,
    ticket_id uuid NOT NULL,
    alert_count integer DEFAULT 1 NOT NULL,
    first_alert_at timestamp with time zone NOT NULL,
    last_alert_at timestamp with time zone DEFAULT now() NOT NULL,
    closed_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT alert_incidents_alert_count_check CHECK ((alert_count >= 1))
);


--
-- Name: alert_sources; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.alert_sources (
    id uuid NOT NULL,
    org_id uuid NOT NULL,
    name text NOT NULL,
    source_ref text NOT NULL,
    secret_encrypted bytea NOT NULL,
    board_id uuid NOT NULL,
    client_id uuid,
    correlation_window_secs integer DEFAULT 900 NOT NULL,
    enabled boolean DEFAULT true NOT NULL,
    created_by uuid,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT alert_sources_correlation_window_secs_check CHECK (((correlation_window_secs >= 10) AND (correlation_window_secs <= 86400)))
);


--
-- Name: alerts; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.alerts (
    id uuid NOT NULL,
    org_id uuid NOT NULL,
    source_id uuid NOT NULL,
    dedup_key text NOT NULL,
    correlation_key text NOT NULL,
    title text NOT NULL,
    description text,
    severity text NOT NULL,
    occurred_at timestamp with time zone NOT NULL,
    attributes jsonb DEFAULT '{}'::jsonb NOT NULL,
    incident_ticket_id uuid,
    received_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT alerts_severity_check CHECK ((severity = ANY (ARRAY['info'::text, 'warning'::text, 'critical'::text])))
);


--
-- Name: api_keys; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.api_keys (
    id uuid NOT NULL,
    org_id uuid NOT NULL,
    name text NOT NULL,
    key_hash text NOT NULL,
    prefix text NOT NULL,
    scopes jsonb DEFAULT '[]'::jsonb NOT NULL,
    created_by uuid,
    last_used_at timestamp with time zone,
    revoked_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: appointments; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.appointments (
    id uuid NOT NULL,
    org_id uuid NOT NULL,
    user_id uuid NOT NULL,
    ticket_id uuid,
    client_id uuid,
    site_id uuid,
    title text NOT NULL,
    starts_at timestamp with time zone NOT NULL,
    ends_at timestamp with time zone NOT NULL,
    kind public.appointment_kind DEFAULT 'on_site'::public.appointment_kind NOT NULL,
    status public.appointment_status DEFAULT 'scheduled'::public.appointment_status NOT NULL,
    travel_minutes integer DEFAULT 0 NOT NULL,
    notes text,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT appointments_check CHECK ((ends_at > starts_at)),
    CONSTRAINT appointments_travel_minutes_check CHECK ((travel_minutes >= 0))
);


--
-- Name: attachments; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.attachments (
    id uuid NOT NULL,
    org_id uuid NOT NULL,
    kind public.attachment_kind NOT NULL,
    ticket_id uuid,
    ticket_comment_id uuid,
    email_message_id uuid,
    filename text NOT NULL,
    content_type text NOT NULL,
    size_bytes bigint NOT NULL,
    sha256 text NOT NULL,
    storage_key text NOT NULL,
    uploaded_by_user_id uuid,
    uploaded_by_portal_user_id uuid,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT attachments_link_shape CHECK (((ticket_comment_id IS NULL) OR ((ticket_id IS NOT NULL) AND (email_message_id IS NULL)))),
    CONSTRAINT attachments_owner_shape CHECK ((((email_message_id IS NOT NULL) AND (ticket_id IS NULL) AND (ticket_comment_id IS NULL)) OR ((email_message_id IS NULL) AND (ticket_id IS NOT NULL)))),
    CONSTRAINT attachments_sha256_check CHECK ((sha256 ~ '^[0-9a-f]{64}$'::text)),
    CONSTRAINT attachments_size_bytes_check CHECK ((size_bytes > 0)),
    CONSTRAINT attachments_uploader_shape CHECK (((uploaded_by_user_id IS NULL) OR (uploaded_by_portal_user_id IS NULL)))
);


--
-- Name: audit_events; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.audit_events (
    id uuid NOT NULL,
    org_id uuid NOT NULL,
    actor_kind text NOT NULL,
    actor_id text,
    action text NOT NULL,
    entity_type text,
    entity_id text,
    detail jsonb DEFAULT '{}'::jsonb NOT NULL,
    ip text,
    occurred_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT audit_events_actor_kind_check CHECK ((actor_kind = ANY (ARRAY['human'::text, 'agent'::text, 'plugin'::text, 'connector'::text, 'system'::text, 'portal_contact'::text, 'portal_approver'::text, 'portal_it_manager'::text, 'import'::text])))
);


--
-- Name: auth_sessions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.auth_sessions (
    id uuid NOT NULL,
    user_id uuid NOT NULL,
    refresh_token_hash text NOT NULL,
    user_agent text,
    expires_at timestamp with time zone NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    revoked_at timestamp with time zone,
    chain_id uuid NOT NULL,
    rotated_from uuid
);


--
-- Name: automation_rules; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.automation_rules (
    id uuid NOT NULL,
    org_id uuid NOT NULL,
    board_id uuid,
    name text NOT NULL,
    trigger_event text NOT NULL,
    conditions jsonb DEFAULT '[]'::jsonb NOT NULL,
    actions jsonb NOT NULL,
    enabled boolean DEFAULT true NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: availability_windows; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.availability_windows (
    id uuid NOT NULL,
    org_id uuid NOT NULL,
    user_id uuid NOT NULL,
    weekday smallint NOT NULL,
    start_local time without time zone NOT NULL,
    end_local time without time zone NOT NULL,
    timezone text NOT NULL,
    effective_from date,
    effective_until date,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT availability_windows_check CHECK ((start_local < end_local)),
    CONSTRAINT availability_windows_check1 CHECK (((effective_until IS NULL) OR (effective_from IS NULL) OR (effective_until >= effective_from))),
    CONSTRAINT availability_windows_weekday_check CHECK (((weekday >= 0) AND (weekday <= 6)))
);


--
-- Name: board_checklist_templates; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.board_checklist_templates (
    id uuid NOT NULL,
    org_id uuid NOT NULL,
    board_id uuid NOT NULL,
    name text NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: board_favorites; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.board_favorites (
    user_id uuid NOT NULL,
    board_id uuid NOT NULL,
    sort_order integer DEFAULT 0 NOT NULL
);


--
-- Name: board_groups; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.board_groups (
    id uuid NOT NULL,
    org_id uuid NOT NULL,
    owner_id uuid NOT NULL,
    name text NOT NULL,
    "position" integer DEFAULT 0 NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: board_members; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.board_members (
    org_id uuid NOT NULL,
    board_id uuid NOT NULL,
    user_id uuid NOT NULL,
    role public.board_role DEFAULT 'member'::public.board_role NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: board_portal_exposure; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.board_portal_exposure (
    id uuid NOT NULL,
    org_id uuid NOT NULL,
    board_id uuid NOT NULL,
    client_id uuid NOT NULL,
    exposed boolean DEFAULT false NOT NULL,
    visible_status_ids uuid[] DEFAULT '{}'::uuid[] NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: board_status_transitions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.board_status_transitions (
    org_id uuid NOT NULL,
    board_id uuid NOT NULL,
    from_status_id uuid NOT NULL,
    to_status_id uuid NOT NULL,
    CONSTRAINT board_transitions_distinct CHECK ((from_status_id <> to_status_id))
);


--
-- Name: byok_secrets; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.byok_secrets (
    id uuid NOT NULL,
    org_id uuid NOT NULL,
    provider text NOT NULL,
    secret_encrypted bytea NOT NULL,
    created_by uuid,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: calendar_exclusions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.calendar_exclusions (
    id uuid NOT NULL,
    org_id uuid NOT NULL,
    user_id uuid NOT NULL,
    starts_at timestamp with time zone NOT NULL,
    ends_at timestamp with time zone NOT NULL,
    reason text,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT calendar_exclusions_check CHECK ((ends_at > starts_at))
);


--
-- Name: checklist_items; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.checklist_items (
    id uuid NOT NULL,
    org_id uuid NOT NULL,
    ticket_id uuid NOT NULL,
    text text NOT NULL,
    checked boolean DEFAULT false NOT NULL,
    sort_order integer DEFAULT 0 NOT NULL,
    checked_by uuid,
    checked_at timestamp with time zone,
    template_item_id uuid
);


--
-- Name: checklist_template_items; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.checklist_template_items (
    id uuid NOT NULL,
    org_id uuid NOT NULL,
    template_id uuid NOT NULL,
    text text NOT NULL,
    sort_order integer DEFAULT 0 NOT NULL
);


--
-- Name: connector_installations; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.connector_installations (
    id uuid NOT NULL,
    org_id uuid NOT NULL,
    connector_type text NOT NULL,
    config_encrypted bytea NOT NULL,
    capability_scopes text[] DEFAULT '{}'::text[] NOT NULL,
    consented_by uuid,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: contacts; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.contacts (
    id uuid NOT NULL,
    org_id uuid NOT NULL,
    client_id uuid NOT NULL,
    site_id uuid,
    name text NOT NULL,
    email text,
    phone text,
    title text,
    is_primary boolean DEFAULT false NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: contract_fixed_fees; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.contract_fixed_fees (
    id uuid NOT NULL,
    org_id uuid NOT NULL,
    contract_id uuid NOT NULL,
    label text NOT NULL,
    amount_minor bigint NOT NULL,
    due_on date NOT NULL,
    notes text,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: contract_rates; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.contract_rates (
    id uuid NOT NULL,
    org_id uuid NOT NULL,
    contract_id uuid NOT NULL,
    work_type text NOT NULL,
    rate_minor bigint NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: contracts; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.contracts (
    id uuid NOT NULL,
    org_id uuid NOT NULL,
    client_id uuid NOT NULL,
    number text NOT NULL,
    name text NOT NULL,
    contract_type text NOT NULL,
    status text DEFAULT 'draft'::text NOT NULL,
    currency text NOT NULL,
    effective_from date NOT NULL,
    effective_until date,
    billing_frequency text,
    billing_anchor date,
    amount_minor bigint,
    hourly_rate_minor bigint,
    included_minutes integer,
    overage_rate_minor bigint,
    notes text,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT contracts_billing_frequency_check CHECK (((billing_frequency IS NULL) OR (billing_frequency = ANY (ARRAY['weekly'::text, 'monthly'::text, 'quarterly'::text, 'semiannual'::text, 'annual'::text])))),
    CONSTRAINT contracts_contract_type_check CHECK ((contract_type = ANY (ARRAY['recurring'::text, 'time_and_materials'::text, 'retainer'::text, 'fixed_fee'::text]))),
    CONSTRAINT contracts_status_check CHECK ((status = ANY (ARRAY['draft'::text, 'active'::text, 'ended'::text, 'cancelled'::text])))
);


--
-- Name: custom_field_defs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.custom_field_defs (
    id uuid NOT NULL,
    org_id uuid NOT NULL,
    entity text NOT NULL,
    name text NOT NULL,
    kind text NOT NULL,
    config jsonb DEFAULT '{}'::jsonb NOT NULL,
    required boolean DEFAULT false NOT NULL,
    sort_order integer DEFAULT 0 NOT NULL,
    archived_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    board_id uuid,
    CONSTRAINT custom_field_defs_entity_check CHECK ((entity = ANY (ARRAY['ticket'::text, 'client'::text, 'contact'::text, 'asset'::text]))),
    CONSTRAINT custom_field_defs_kind_check CHECK ((kind = ANY (ARRAY['text'::text, 'number'::text, 'date'::text, 'select'::text, 'multiselect'::text, 'bool'::text, 'url'::text, 'user'::text])))
);


--
-- Name: custom_field_values; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.custom_field_values (
    field_id uuid NOT NULL,
    entity_id uuid NOT NULL,
    org_id uuid NOT NULL,
    value jsonb NOT NULL
);


--
-- Name: device_assets; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.device_assets (
    id uuid NOT NULL,
    org_id uuid NOT NULL,
    client_id uuid NOT NULL,
    site_id uuid,
    tag text NOT NULL,
    name text NOT NULL,
    kind text DEFAULT 'device'::text NOT NULL,
    status text DEFAULT 'active'::text NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: dispatch_queue_entries; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.dispatch_queue_entries (
    id uuid NOT NULL,
    org_id uuid NOT NULL,
    ticket_id uuid NOT NULL,
    rank integer NOT NULL,
    note text,
    created_by uuid NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT dispatch_queue_entries_note_check CHECK ((char_length(note) <= 500)),
    CONSTRAINT dispatch_queue_entries_rank_check CHECK ((rank >= 0))
);


--
-- Name: dispatch_status_updates; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.dispatch_status_updates (
    id uuid NOT NULL,
    org_id uuid NOT NULL,
    appointment_id uuid NOT NULL,
    status text NOT NULL,
    note text,
    actor_id uuid NOT NULL,
    source text NOT NULL,
    occurred_at timestamp with time zone DEFAULT now() NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT dispatch_status_updates_note_check CHECK ((char_length(note) <= 500)),
    CONSTRAINT dispatch_status_updates_source_check CHECK ((source = ANY (ARRAY['connector'::text, 'staff'::text]))),
    CONSTRAINT dispatch_status_updates_status_check CHECK ((status = ANY (ARRAY['en_route'::text, 'arrived'::text, 'in_progress'::text, 'completed'::text, 'blocked'::text, 'delayed'::text])))
);


--
-- Name: document_versions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.document_versions (
    id uuid NOT NULL,
    org_id uuid NOT NULL,
    document_id uuid NOT NULL,
    version integer NOT NULL,
    title text NOT NULL,
    body text DEFAULT ''::text NOT NULL,
    change_summary text DEFAULT ''::text NOT NULL,
    author_id uuid,
    restored_from_version integer,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: documents; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.documents (
    id uuid NOT NULL,
    org_id uuid NOT NULL,
    title text NOT NULL,
    current_version integer DEFAULT 1 NOT NULL,
    created_by uuid,
    updated_by uuid,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: email_inbound_settings; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.email_inbound_settings (
    id uuid NOT NULL,
    org_id uuid NOT NULL,
    catchall_address text NOT NULL,
    catchall_board_id uuid NOT NULL,
    enabled boolean DEFAULT true NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: email_messages; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.email_messages (
    id uuid NOT NULL,
    org_id uuid NOT NULL,
    direction text NOT NULL,
    rfc_message_id text NOT NULL,
    in_reply_to text,
    email_refs text[] DEFAULT '{}'::text[] NOT NULL,
    subject text,
    from_address text NOT NULL,
    from_name text,
    to_addresses text[] DEFAULT '{}'::text[] NOT NULL,
    body_text text,
    ticket_id uuid,
    comment_id uuid,
    scan_status text NOT NULL,
    transport text NOT NULL,
    raw_ref text,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT email_messages_direction_check CHECK ((direction = ANY (ARRAY['inbound'::text, 'outbound'::text]))),
    CONSTRAINT email_messages_scan_status_check CHECK ((scan_status = ANY (ARRAY['clean'::text, 'infected'::text, 'skipped'::text])))
);


--
-- Name: email_outbound; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.email_outbound (
    id uuid NOT NULL,
    org_id uuid NOT NULL,
    email_message_id uuid NOT NULL,
    status text DEFAULT 'queued'::text NOT NULL,
    attempts integer DEFAULT 0 NOT NULL,
    max_attempts integer DEFAULT 8 NOT NULL,
    next_attempt_at timestamp with time zone DEFAULT now() NOT NULL,
    last_error text,
    provider_message_id text,
    claimed_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT email_outbound_status_check CHECK ((status = ANY (ARRAY['queued'::text, 'sending'::text, 'sent'::text, 'dead'::text])))
);


--
-- Name: entity_write_seqs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.entity_write_seqs (
    org_id uuid NOT NULL,
    entity text NOT NULL,
    entity_id uuid NOT NULL,
    seq bigint DEFAULT 0 NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: external_ids; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.external_ids (
    id uuid NOT NULL,
    org_id uuid NOT NULL,
    entity_kind text NOT NULL,
    external_key text NOT NULL,
    internal_id uuid NOT NULL,
    last_seen_batch uuid,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT external_ids_entity_kind_check CHECK ((entity_kind = ANY (ARRAY['client'::text, 'site'::text, 'contact'::text, 'board'::text, 'ticket'::text, 'time_entry'::text, 'kb_category'::text, 'kb_article'::text])))
);


--
-- Name: idempotency_keys; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.idempotency_keys (
    id uuid NOT NULL,
    org_id uuid NOT NULL,
    key text NOT NULL,
    entity text NOT NULL,
    entity_id uuid,
    request_hash text NOT NULL,
    response jsonb,
    actor_id uuid NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: import_batches; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.import_batches (
    id uuid NOT NULL,
    org_id uuid NOT NULL,
    label text DEFAULT 'unnamed'::text NOT NULL,
    source_note text,
    entity_kind text NOT NULL,
    conflict_policy text NOT NULL,
    dry_run boolean DEFAULT false NOT NULL,
    rows_total integer DEFAULT 0 NOT NULL,
    rows_created integer DEFAULT 0 NOT NULL,
    rows_updated integer DEFAULT 0 NOT NULL,
    rows_skipped integer DEFAULT 0 NOT NULL,
    rows_failed integer DEFAULT 0 NOT NULL,
    created_by uuid NOT NULL,
    created_by_kind text NOT NULL,
    started_at timestamp with time zone DEFAULT now() NOT NULL,
    finished_at timestamp with time zone,
    staged_chunks integer DEFAULT 0 NOT NULL,
    queued_at timestamp with time zone,
    CONSTRAINT import_batches_conflict_policy_check CHECK ((conflict_policy = ANY (ARRAY['skip'::text, 'update'::text, 'fail'::text]))),
    CONSTRAINT import_batches_created_by_kind_check CHECK ((created_by_kind = ANY (ARRAY['user'::text, 'api_key'::text]))),
    CONSTRAINT import_batches_entity_kind_check CHECK ((entity_kind = ANY (ARRAY['client'::text, 'site'::text, 'contact'::text, 'board'::text, 'ticket'::text, 'time_entry'::text, 'kb_category'::text, 'kb_article'::text])))
);


--
-- Name: import_mapping_templates; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.import_mapping_templates (
    id uuid NOT NULL,
    org_id uuid NOT NULL,
    name text NOT NULL,
    source_system text NOT NULL,
    entity_kind text NOT NULL,
    mapping jsonb NOT NULL,
    created_by uuid NOT NULL,
    created_by_kind text NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT import_mapping_templates_created_by_kind_check CHECK ((created_by_kind = ANY (ARRAY['user'::text, 'api_key'::text]))),
    CONSTRAINT import_mapping_templates_entity_kind_check CHECK ((entity_kind = ANY (ARRAY['client'::text, 'site'::text, 'contact'::text, 'board'::text, 'ticket'::text, 'time_entry'::text, 'kb_category'::text, 'kb_article'::text])))
);


--
-- Name: invoice_lines; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.invoice_lines (
    id uuid NOT NULL,
    org_id uuid NOT NULL,
    invoice_id uuid NOT NULL,
    contract_id uuid NOT NULL,
    kind text NOT NULL,
    description text NOT NULL,
    period_start date NOT NULL,
    period_end date NOT NULL,
    quantity_minutes bigint DEFAULT 0 NOT NULL,
    unit_amount_minor bigint NOT NULL,
    amount_minor bigint NOT NULL,
    "position" integer DEFAULT 0 NOT NULL,
    CONSTRAINT invoice_lines_kind_check CHECK ((kind = ANY (ARRAY['recurring_base'::text, 'retainer_base'::text, 'retainer_overage'::text, 'time_materials'::text, 'fixed_fee'::text])))
);


--
-- Name: invoice_payments; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.invoice_payments (
    id uuid NOT NULL,
    org_id uuid NOT NULL,
    invoice_id uuid NOT NULL,
    amount_minor bigint NOT NULL,
    currency text NOT NULL,
    provider text DEFAULT 'none'::text NOT NULL,
    provider_ref text,
    notes text,
    received_at timestamp with time zone DEFAULT now() NOT NULL,
    created_by uuid,
    CONSTRAINT invoice_payments_amount_minor_check CHECK ((amount_minor > 0))
);


--
-- Name: invoice_runs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.invoice_runs (
    id uuid NOT NULL,
    org_id uuid NOT NULL,
    number text NOT NULL,
    period_from date NOT NULL,
    period_to date NOT NULL,
    invoice_count integer DEFAULT 0 NOT NULL,
    total_minor bigint DEFAULT 0 NOT NULL,
    currency text,
    due_in_days integer DEFAULT 30 NOT NULL,
    created_by uuid,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: invoice_time_entries; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.invoice_time_entries (
    id uuid NOT NULL,
    org_id uuid NOT NULL,
    invoice_id uuid NOT NULL,
    time_entry_id uuid NOT NULL
);


--
-- Name: invoices; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.invoices (
    id uuid NOT NULL,
    org_id uuid NOT NULL,
    run_id uuid,
    client_id uuid NOT NULL,
    contract_id uuid NOT NULL,
    number text NOT NULL,
    status text DEFAULT 'issued'::text NOT NULL,
    currency text NOT NULL,
    period_from date,
    period_to date,
    issued_at date NOT NULL,
    due_on date NOT NULL,
    total_minor bigint NOT NULL,
    total_paid_minor bigint DEFAULT 0 NOT NULL,
    dunning_state text DEFAULT 'none'::text NOT NULL,
    dunning_updated_at timestamp with time zone,
    dunning_note text,
    notes text,
    created_by uuid,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT invoices_dunning_state_check CHECK ((dunning_state = ANY (ARRAY['none'::text, 'reminder_sent'::text, 'overdue'::text, 'final_notice'::text, 'collections'::text]))),
    CONSTRAINT invoices_status_check CHECK ((status = ANY (ARRAY['draft'::text, 'issued'::text, 'paid'::text, 'void'::text])))
);


--
-- Name: jobs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.jobs (
    id uuid NOT NULL,
    org_id uuid NOT NULL,
    kind text NOT NULL,
    payload jsonb NOT NULL,
    status text DEFAULT 'pending'::text NOT NULL,
    run_after timestamp with time zone DEFAULT now() NOT NULL,
    attempts integer DEFAULT 0 NOT NULL,
    max_attempts integer DEFAULT 5 NOT NULL,
    last_error text,
    claimed_at timestamp with time zone,
    claimed_by text,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT jobs_status_check CHECK ((status = ANY (ARRAY['pending'::text, 'running'::text, 'done'::text, 'failed'::text, 'dead'::text])))
);


--
-- Name: kb_articles; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.kb_articles (
    id uuid NOT NULL,
    org_id uuid NOT NULL,
    category_id uuid,
    title text NOT NULL,
    slug text NOT NULL,
    body text DEFAULT ''::text NOT NULL,
    status text DEFAULT 'draft'::text NOT NULL,
    client_visible boolean DEFAULT false NOT NULL,
    created_by uuid,
    updated_by uuid,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT kb_articles_status_check CHECK ((status = ANY (ARRAY['draft'::text, 'published'::text, 'archived'::text])))
);


--
-- Name: kb_categories; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.kb_categories (
    id uuid NOT NULL,
    org_id uuid NOT NULL,
    name text NOT NULL,
    slug text NOT NULL,
    description text DEFAULT ''::text NOT NULL,
    "position" integer DEFAULT 0 NOT NULL,
    client_visible boolean DEFAULT false NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: mcp_capability_grants; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.mcp_capability_grants (
    id uuid NOT NULL,
    org_id uuid NOT NULL,
    capability text NOT NULL,
    mode text DEFAULT 'proposed'::text NOT NULL,
    granted_by uuid NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT mcp_capability_grants_capability_check CHECK ((capability ~ '^[a-z][a-z0-9_-]*:(read|write)$'::text)),
    CONSTRAINT mcp_capability_grants_check CHECK (((mode = 'proposed'::text) OR (capability ~~ '%:write'::text))),
    CONSTRAINT mcp_capability_grants_mode_check CHECK ((mode = ANY (ARRAY['proposed'::text, 'autonomous'::text])))
);


--
-- Name: mfa_challenges; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.mfa_challenges (
    id uuid NOT NULL,
    org_id uuid NOT NULL,
    user_id uuid NOT NULL,
    kind text NOT NULL,
    state jsonb NOT NULL,
    expires_at timestamp with time zone NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT mfa_challenges_kind_check CHECK ((kind = ANY (ARRAY['registration'::text, 'authentication'::text, 'sso_code'::text])))
);


--
-- Name: migration_push_chunks; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.migration_push_chunks (
    id uuid NOT NULL,
    org_id uuid NOT NULL,
    session_id uuid NOT NULL,
    chunk_index integer NOT NULL,
    fingerprint text NOT NULL,
    summary jsonb NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT migration_push_chunks_chunk_index_check CHECK ((chunk_index >= 0)),
    CONSTRAINT migration_push_chunks_summary_check CHECK ((jsonb_typeof(summary) = 'object'::text))
);


--
-- Name: migration_push_sessions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.migration_push_sessions (
    id uuid NOT NULL,
    org_id uuid NOT NULL,
    batch_id uuid NOT NULL,
    label text DEFAULT 'unnamed'::text NOT NULL,
    source_note text,
    created_by uuid NOT NULL,
    created_by_kind text NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    finished_at timestamp with time zone,
    CONSTRAINT migration_push_sessions_created_by_kind_check CHECK ((created_by_kind = ANY (ARRAY['user'::text, 'api_key'::text])))
);


--
-- Name: notification_org_defaults; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.notification_org_defaults (
    org_id uuid NOT NULL,
    kind text NOT NULL,
    in_app boolean DEFAULT true NOT NULL,
    email boolean DEFAULT false NOT NULL,
    quiet_from text,
    quiet_until text,
    timezone text DEFAULT 'UTC'::text NOT NULL,
    CONSTRAINT notification_org_defaults_kind_check CHECK ((kind = ANY (ARRAY['mention'::text, 'assignment'::text, 'sla_risk'::text, 'sla_breach'::text, 'escalation'::text, 'missing_time'::text, 'ticket_update'::text, 'report_delivery'::text]))),
    CONSTRAINT notification_org_defaults_quiet_from_check CHECK (((quiet_from IS NULL) OR (quiet_from ~ '^\d{2}:\d{2}$'::text))),
    CONSTRAINT notification_org_defaults_quiet_pair CHECK (((quiet_from IS NULL) = (quiet_until IS NULL))),
    CONSTRAINT notification_org_defaults_quiet_until_check CHECK (((quiet_until IS NULL) OR (quiet_until ~ '^\d{2}:\d{2}$'::text)))
);


--
-- Name: notification_preferences; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.notification_preferences (
    user_id uuid NOT NULL,
    kind text NOT NULL,
    in_app boolean DEFAULT true NOT NULL,
    email boolean DEFAULT false NOT NULL,
    quiet_from text,
    quiet_until text,
    timezone text DEFAULT 'UTC'::text NOT NULL,
    CONSTRAINT notification_preferences_kind_check CHECK ((kind = ANY (ARRAY['mention'::text, 'assignment'::text, 'sla_risk'::text, 'sla_breach'::text, 'escalation'::text, 'missing_time'::text, 'ticket_update'::text, 'report_delivery'::text]))),
    CONSTRAINT notification_prefs_quiet_pair CHECK (((quiet_from IS NULL) = (quiet_until IS NULL)))
);


--
-- Name: notifications; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.notifications (
    id uuid NOT NULL,
    org_id uuid NOT NULL,
    user_id uuid NOT NULL,
    kind text NOT NULL,
    ticket_id uuid,
    title text NOT NULL,
    body text,
    read_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT notifications_kind_check CHECK ((kind = ANY (ARRAY['mention'::text, 'assignment'::text, 'sla_risk'::text, 'sla_breach'::text, 'escalation'::text, 'missing_time'::text, 'ticket_update'::text, 'report_delivery'::text])))
);


--
-- Name: oidc_accounts; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.oidc_accounts (
    id uuid NOT NULL,
    org_id uuid NOT NULL,
    provider_id uuid NOT NULL,
    user_id uuid NOT NULL,
    subject text NOT NULL,
    email text NOT NULL,
    linked_by uuid,
    linked_at timestamp with time zone DEFAULT now() NOT NULL,
    last_login_at timestamp with time zone
);


--
-- Name: oidc_providers; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.oidc_providers (
    id uuid NOT NULL,
    org_id uuid NOT NULL,
    name text NOT NULL,
    display_name text NOT NULL,
    issuer text NOT NULL,
    discovery_url text NOT NULL,
    client_id text NOT NULL,
    client_secret_enc bytea NOT NULL,
    jit_provisioning boolean DEFAULT false NOT NULL,
    enabled boolean DEFAULT true NOT NULL,
    created_by uuid,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: on_call_blocks; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.on_call_blocks (
    id uuid NOT NULL,
    org_id uuid NOT NULL,
    user_id uuid NOT NULL,
    starts_at timestamp with time zone NOT NULL,
    ends_at timestamp with time zone NOT NULL,
    category text DEFAULT 'primary'::text NOT NULL,
    notes text,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT on_call_blocks_check CHECK ((ends_at > starts_at))
);


--
-- Name: orgs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.orgs (
    id uuid NOT NULL,
    name text NOT NULL,
    slug text NOT NULL,
    ticket_prefix text DEFAULT 'MER'::text NOT NULL,
    ticket_sequence bigint DEFAULT 1000 NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    eod_nudges_enabled boolean DEFAULT true NOT NULL,
    eod_nudge_hour smallint DEFAULT 18 NOT NULL,
    time_gap_min_minutes integer DEFAULT 60 NOT NULL,
    invoice_sequence bigint DEFAULT 0 NOT NULL,
    CONSTRAINT orgs_eod_nudge_hour_check CHECK (((eod_nudge_hour >= 0) AND (eod_nudge_hour <= 23))),
    CONSTRAINT orgs_time_gap_min_minutes_check CHECK (((time_gap_min_minutes >= 0) AND (time_gap_min_minutes <= 1440)))
);


--
-- Name: outbox_events; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.outbox_events (
    id uuid NOT NULL,
    org_id uuid NOT NULL,
    event_type text NOT NULL,
    entity text NOT NULL,
    entity_id text,
    payload jsonb NOT NULL,
    payload_schema_ref text DEFAULT 'core-domain/v1'::text NOT NULL,
    occurred_at timestamp with time zone DEFAULT now() NOT NULL,
    published_at timestamp with time zone
);


--
-- Name: portal_appointment_requests; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.portal_appointment_requests (
    id uuid NOT NULL,
    org_id uuid NOT NULL,
    client_id uuid NOT NULL,
    portal_user_id uuid NOT NULL,
    user_id uuid NOT NULL,
    title text NOT NULL,
    starts_at timestamp with time zone NOT NULL,
    ends_at timestamp with time zone NOT NULL,
    kind public.appointment_kind DEFAULT 'remote'::public.appointment_kind NOT NULL,
    notes text,
    status text DEFAULT 'pending'::text NOT NULL,
    decision_note text,
    decided_by uuid,
    decided_at timestamp with time zone,
    appointment_id uuid,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT portal_appointment_requests_check CHECK ((ends_at > starts_at)),
    CONSTRAINT portal_appointment_requests_status_check CHECK ((status = ANY (ARRAY['pending'::text, 'approved'::text, 'declined'::text, 'cancelled'::text])))
);


--
-- Name: portal_sessions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.portal_sessions (
    id uuid NOT NULL,
    org_id uuid NOT NULL,
    portal_user_id uuid NOT NULL,
    refresh_token_hash text NOT NULL,
    user_agent text,
    expires_at timestamp with time zone NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    revoked_at timestamp with time zone
);


--
-- Name: portal_users; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.portal_users (
    id uuid NOT NULL,
    org_id uuid NOT NULL,
    client_id uuid NOT NULL,
    email text NOT NULL,
    display_name text NOT NULL,
    password_hash text NOT NULL,
    role text DEFAULT 'contact'::text NOT NULL,
    status text DEFAULT 'invited'::text NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT portal_users_role_check CHECK ((role = ANY (ARRAY['contact'::text, 'approver'::text, 'it_manager'::text]))),
    CONSTRAINT portal_users_status_check CHECK ((status = ANY (ARRAY['invited'::text, 'active'::text, 'disabled'::text])))
);


--
-- Name: project_phases; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.project_phases (
    id uuid NOT NULL,
    org_id uuid NOT NULL,
    project_id uuid NOT NULL,
    name text NOT NULL,
    description text,
    sort_order integer DEFAULT 0 NOT NULL,
    status text DEFAULT 'pending'::text NOT NULL,
    is_milestone boolean DEFAULT false NOT NULL,
    milestone_amount_minor bigint,
    milestone_currency text,
    completed_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT project_phases_status_check CHECK ((status = ANY (ARRAY['pending'::text, 'active'::text, 'completed'::text, 'cancelled'::text])))
);


--
-- Name: project_task_deps; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.project_task_deps (
    org_id uuid NOT NULL,
    task_id uuid NOT NULL,
    depends_on_task_id uuid NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT project_task_deps_check CHECK ((task_id <> depends_on_task_id))
);


--
-- Name: project_tasks; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.project_tasks (
    id uuid NOT NULL,
    org_id uuid NOT NULL,
    project_id uuid NOT NULL,
    phase_id uuid,
    title text NOT NULL,
    description text,
    status text DEFAULT 'pending'::text NOT NULL,
    assignee_id uuid,
    sort_order integer DEFAULT 0 NOT NULL,
    is_milestone boolean DEFAULT false NOT NULL,
    milestone_amount_minor bigint,
    milestone_currency text,
    due_at timestamp with time zone,
    completed_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT project_tasks_status_check CHECK ((status = ANY (ARRAY['pending'::text, 'in_progress'::text, 'blocked'::text, 'completed'::text, 'cancelled'::text])))
);


--
-- Name: project_templates; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.project_templates (
    id uuid NOT NULL,
    org_id uuid NOT NULL,
    name text NOT NULL,
    description text,
    spec jsonb NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: project_views; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.project_views (
    id uuid NOT NULL,
    org_id uuid NOT NULL,
    project_id uuid,
    name text NOT NULL,
    spec jsonb DEFAULT '{}'::jsonb NOT NULL,
    is_default boolean DEFAULT false NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: projects; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.projects (
    id uuid NOT NULL,
    org_id uuid NOT NULL,
    client_id uuid,
    name text NOT NULL,
    description text,
    status text DEFAULT 'planning'::text NOT NULL,
    billing_method text DEFAULT 'non_billable'::text NOT NULL,
    budget_minor bigint,
    currency text,
    start_date date,
    due_date date,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT projects_billing_method_check CHECK ((billing_method = ANY (ARRAY['milestone'::text, 'time_and_materials'::text, 'fixed_fee'::text, 'non_billable'::text]))),
    CONSTRAINT projects_status_check CHECK ((status = ANY (ARRAY['planning'::text, 'active'::text, 'on_hold'::text, 'completed'::text, 'cancelled'::text])))
);


--
-- Name: provenance_events; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.provenance_events (
    write_id uuid NOT NULL,
    field_seq integer NOT NULL,
    org_id uuid NOT NULL,
    entity text NOT NULL,
    entity_id uuid NOT NULL,
    seq bigint NOT NULL,
    op text NOT NULL,
    actor_kind text NOT NULL,
    actor_id uuid,
    field text NOT NULL,
    before jsonb,
    after jsonb,
    session_id uuid,
    skill text,
    ruleset_hash text,
    is_undo boolean DEFAULT false NOT NULL,
    idempotency_key text,
    occurred_at timestamp with time zone NOT NULL
);


--
-- Name: recovery_codes; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.recovery_codes (
    id uuid NOT NULL,
    org_id uuid NOT NULL,
    user_id uuid NOT NULL,
    code_hash text NOT NULL,
    used_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: report_definitions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.report_definitions (
    id uuid NOT NULL,
    org_id uuid NOT NULL,
    name text NOT NULL,
    description text,
    kind text NOT NULL,
    spec jsonb NOT NULL,
    viz text NOT NULL,
    scope text DEFAULT 'self'::text NOT NULL,
    created_by uuid NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT report_definitions_kind_check CHECK ((kind = ANY (ARRAY['tickets'::text, 'time_entries'::text, 'sla_outcomes'::text, 'gap_days'::text, 'first_response'::text]))),
    CONSTRAINT report_definitions_scope_check CHECK ((scope = ANY (ARRAY['org'::text, 'self'::text]))),
    CONSTRAINT report_definitions_spec_check CHECK ((jsonb_typeof(spec) = 'object'::text)),
    CONSTRAINT report_definitions_viz_check CHECK ((viz = ANY (ARRAY['bar'::text, 'line'::text, 'pie'::text, 'table'::text])))
);


--
-- Name: report_deliveries; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.report_deliveries (
    id uuid NOT NULL,
    org_id uuid NOT NULL,
    schedule_id uuid NOT NULL,
    slot_at timestamp with time zone NOT NULL,
    status text NOT NULL,
    detail jsonb NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT report_deliveries_detail_check CHECK ((jsonb_typeof(detail) = 'object'::text)),
    CONSTRAINT report_deliveries_status_check CHECK ((status = ANY (ARRAY['delivered'::text, 'partial'::text, 'failed'::text, 'skipped'::text])))
);


--
-- Name: report_schedules; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.report_schedules (
    id uuid NOT NULL,
    org_id uuid NOT NULL,
    report_definition_id uuid NOT NULL,
    name text NOT NULL,
    recipients uuid[] NOT NULL,
    cadence text NOT NULL,
    time_of_day time without time zone NOT NULL,
    day_of_week smallint,
    day_of_month smallint,
    timezone text DEFAULT 'UTC'::text NOT NULL,
    window_days integer DEFAULT 30 NOT NULL,
    enabled boolean DEFAULT true NOT NULL,
    next_run_at timestamp with time zone NOT NULL,
    last_run_at timestamp with time zone,
    last_error text,
    created_by uuid NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT report_schedules_cadence_check CHECK ((cadence = ANY (ARRAY['daily'::text, 'weekly'::text, 'monthly'::text]))),
    CONSTRAINT report_schedules_cadence_shape CHECK ((((cadence = 'daily'::text) AND (day_of_week IS NULL) AND (day_of_month IS NULL)) OR ((cadence = 'weekly'::text) AND (day_of_week IS NOT NULL) AND (day_of_month IS NULL)) OR ((cadence = 'monthly'::text) AND (day_of_week IS NULL) AND (day_of_month IS NOT NULL)))),
    CONSTRAINT report_schedules_day_of_month_check CHECK (((day_of_month >= 1) AND (day_of_month <= 28))),
    CONSTRAINT report_schedules_day_of_week_check CHECK (((day_of_week >= 0) AND (day_of_week <= 6))),
    CONSTRAINT report_schedules_recipients_check CHECK ((array_length(recipients, 1) >= 1)),
    CONSTRAINT report_schedules_window_days_check CHECK (((window_days >= 1) AND (window_days <= 366)))
);


--
-- Name: roles; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.roles (
    id uuid NOT NULL,
    org_id uuid NOT NULL,
    name text NOT NULL,
    builtin text,
    permissions jsonb DEFAULT '[]'::jsonb NOT NULL,
    is_system boolean DEFAULT false NOT NULL
);


--
-- Name: search_index; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.search_index (
    id uuid NOT NULL,
    org_id uuid NOT NULL,
    entity_kind text NOT NULL,
    entity_id uuid NOT NULL,
    parent_id uuid,
    title text DEFAULT ''::text NOT NULL,
    body text DEFAULT ''::text NOT NULL,
    tsv tsvector GENERATED ALWAYS AS ((setweight(to_tsvector('english'::regconfig, COALESCE(title, ''::text)), 'A'::"char") || setweight(to_tsvector('english'::regconfig, COALESCE(body, ''::text)), 'B'::"char"))) STORED,
    indexed_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT search_index_entity_kind_check CHECK ((entity_kind = ANY (ARRAY['ticket'::text, 'comment'::text, 'client'::text, 'site'::text, 'contact'::text, 'kb_article'::text, 'document'::text])))
);


--
-- Name: settings; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.settings (
    id uuid NOT NULL,
    org_id uuid NOT NULL,
    scope text NOT NULL,
    key text NOT NULL,
    owner_id uuid NOT NULL,
    value jsonb NOT NULL,
    updated_by uuid,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT settings_owner_shape CHECK ((((scope = 'org'::text) AND (owner_id = org_id)) OR ((scope = 'user'::text) AND (owner_id <> org_id)))),
    CONSTRAINT settings_scope_check CHECK ((scope = ANY (ARRAY['org'::text, 'user'::text]))),
    CONSTRAINT settings_value_check CHECK ((jsonb_typeof(value) = ANY (ARRAY['string'::text, 'number'::text, 'boolean'::text])))
);


--
-- Name: sites; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.sites (
    id uuid NOT NULL,
    org_id uuid NOT NULL,
    client_id uuid NOT NULL,
    name text NOT NULL,
    address text,
    city text,
    region text,
    postal_code text,
    country text,
    latitude double precision,
    longitude double precision,
    timezone text,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: sla_escalation_steps; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.sla_escalation_steps (
    id uuid NOT NULL,
    org_id uuid NOT NULL,
    policy_id uuid NOT NULL,
    step_index integer NOT NULL,
    trigger_kind text NOT NULL,
    at_pct integer NOT NULL,
    notify_user_ids jsonb DEFAULT '[]'::jsonb NOT NULL,
    enabled boolean DEFAULT true NOT NULL,
    CONSTRAINT sla_escalation_steps_at_pct_check CHECK (((at_pct >= 1) AND (at_pct <= 500))),
    CONSTRAINT sla_escalation_steps_step_index_check CHECK ((step_index >= 0)),
    CONSTRAINT sla_escalation_steps_trigger_kind_check CHECK ((trigger_kind = ANY (ARRAY['risk'::text, 'breach'::text, 'escalate'::text])))
);


--
-- Name: sla_fired_escalations; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.sla_fired_escalations (
    org_id uuid NOT NULL,
    ticket_id uuid NOT NULL,
    step_id uuid NOT NULL,
    target text NOT NULL,
    fired_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT sla_fired_escalations_target_check CHECK ((target = ANY (ARRAY['first_response'::text, 'resolution'::text])))
);


--
-- Name: ticket_required_skills; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.ticket_required_skills (
    id uuid NOT NULL,
    org_id uuid NOT NULL,
    ticket_id uuid NOT NULL,
    skill text NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT ticket_required_skills_skill_check CHECK (((char_length(skill) >= 1) AND (char_length(skill) <= 80)))
);


--
-- Name: timer_sessions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.timer_sessions (
    id uuid NOT NULL,
    org_id uuid NOT NULL,
    user_id uuid NOT NULL,
    ticket_id uuid NOT NULL,
    started_at timestamp with time zone DEFAULT now() NOT NULL,
    stopped_at timestamp with time zone,
    segments jsonb DEFAULT '[]'::jsonb NOT NULL,
    is_running boolean GENERATED ALWAYS AS (((stopped_at IS NULL) AND (jsonb_array_length(segments) > 0) AND (((segments -> (jsonb_array_length(segments) - 1)) ->> 'ended_at'::text) IS NULL))) STORED
);


--
-- Name: totp_secrets; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.totp_secrets (
    id uuid NOT NULL,
    org_id uuid NOT NULL,
    user_id uuid NOT NULL,
    secret_enc bytea NOT NULL,
    confirmed boolean DEFAULT false NOT NULL,
    last_used_step bigint DEFAULT '-1'::integer NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: travel_entry_drafts; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.travel_entry_drafts (
    id uuid NOT NULL,
    org_id uuid NOT NULL,
    user_id uuid NOT NULL,
    ticket_id uuid NOT NULL,
    started_at timestamp with time zone NOT NULL,
    ended_at timestamp with time zone NOT NULL,
    distance double precision NOT NULL,
    distance_unit text NOT NULL,
    vehicle text NOT NULL,
    billable boolean DEFAULT false NOT NULL,
    notes text,
    status text DEFAULT 'draft'::text NOT NULL,
    submitted_time_entry_id uuid,
    created_by uuid NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT travel_entry_drafts_check CHECK ((ended_at > started_at)),
    CONSTRAINT travel_entry_drafts_check1 CHECK (((status = 'draft'::text) OR (submitted_time_entry_id IS NOT NULL))),
    CONSTRAINT travel_entry_drafts_distance_check CHECK ((distance > (0)::double precision)),
    CONSTRAINT travel_entry_drafts_distance_unit_check CHECK ((distance_unit = ANY (ARRAY['km'::text, 'mi'::text]))),
    CONSTRAINT travel_entry_drafts_notes_check CHECK ((char_length(notes) <= 2000)),
    CONSTRAINT travel_entry_drafts_status_check CHECK ((status = ANY (ARRAY['draft'::text, 'submitted'::text]))),
    CONSTRAINT travel_entry_drafts_vehicle_check CHECK (((char_length(vehicle) >= 1) AND (char_length(vehicle) <= 40)))
);


--
-- Name: user_roles; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.user_roles (
    user_id uuid NOT NULL,
    role_id uuid NOT NULL
);


--
-- Name: user_skills; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.user_skills (
    id uuid NOT NULL,
    org_id uuid NOT NULL,
    user_id uuid NOT NULL,
    skill text NOT NULL,
    expires_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT user_skills_skill_check CHECK (((char_length(skill) >= 1) AND (char_length(skill) <= 80)))
);


--
-- Name: webauthn_credentials; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.webauthn_credentials (
    id uuid NOT NULL,
    org_id uuid NOT NULL,
    user_id uuid NOT NULL,
    cred_id text NOT NULL,
    credential jsonb NOT NULL,
    label text DEFAULT ''::text NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    last_used_at timestamp with time zone
);


--
-- Name: webhook_deliveries; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.webhook_deliveries (
    id uuid NOT NULL,
    org_id uuid NOT NULL,
    webhook_id uuid NOT NULL,
    event_id uuid NOT NULL,
    event_type text NOT NULL,
    attempt integer NOT NULL,
    response_status integer,
    next_retry_at timestamp with time zone,
    delivered_at timestamp with time zone,
    last_error text,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT webhook_deliveries_attempt_check CHECK ((attempt >= 1))
);


--
-- Name: webhooks; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.webhooks (
    id uuid NOT NULL,
    org_id uuid NOT NULL,
    url text NOT NULL,
    secret_encrypted bytea NOT NULL,
    event_types text[] DEFAULT '{}'::text[] NOT NULL,
    enabled boolean DEFAULT true NOT NULL,
    created_by uuid,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Data for Name: _sqlx_migrations; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public._sqlx_migrations (version, description, installed_on, success, checksum, execution_time) FROM stdin;
1	orgs auth	2026-09-03 02:08:26.420379+00	t	\\x7c0da349497618a3c5d035304f30ea83a7b0852c82b81bb2acc8e4814620edf4565b95292ba6780f2e84f5f12d6c245b	27122084
2	clients	2026-09-03 02:08:26.448699+00	t	\\x9c520e7c89b5f4deb82687eadb6bed1b938e24cba689705924fe3b12664d28933fd71e3b70f67716eb2de714f4096398	8258000
3	boards	2026-09-03 02:08:26.457643+00	t	\\x70144709d81625cb562204378233f5796d602aa4db354de9f8703e557a83aa8bbaf2b3d988f44423666128ff141c268e	6013959
4	tickets	2026-09-03 02:08:26.464157+00	t	\\x6701b5e3a564064867ee049b72224dd0a0fa3a1f59f30e0114235563245b141398a0c91bac7dd41d2b671bed1f4300c5	8733667
5	time	2026-09-03 02:08:26.473408+00	t	\\x6713fef5ac2b92bcbb8d861fa85d691cad55bc81b1affda432e54cd27c49bacc0e14a8b05c5e6b79ba075f34fcb2dce9	5860666
6	outbox	2026-09-03 02:08:26.47983+00	t	\\x96e5da322541254bdf39c0f1854947218cef218957c9c53a37d3b29cc5819c146276847f3334123923731202fd3c8e48	2629417
7	notifications	2026-09-03 02:08:26.482883+00	t	\\x360ebd04548f539ede2827e1730df8ef9c4ff914286ab4b3522c126ebb7283a8a492e00038b13ca45ac2507e5049b4ec	4115333
8	sla	2026-09-03 02:08:26.487484+00	t	\\x175e6d430752720274d1f4a2a3465bda62fd3e3a604afb80dac0ae4ccee87283d47469c831086f305bed875f4a1a0917	3649084
9	custom fields	2026-09-03 02:08:26.491647+00	t	\\xa90466e2ec2a6335c64013356106d63bfadbc1b178aaa5c838abe4ddf72d76d72235e984d405ad9d6118686b03b340a2	3627042
10	login resolver	2026-09-03 02:08:26.495756+00	t	\\x4519be4f5d6587ae51991cbe36183d30f65425bea5b754f8032a183a84830f079efc646f90ebe047c7f14491ad4a1c63	1926583
11	board statuses	2026-09-03 02:08:26.498048+00	t	\\xebd30a7cfd4d75af42af2b4f7a7c3990de7c55388bcb5dbc5f638a342d0b8f4e38712161c809fab470444476594293d1	4189875
12	notification prefs	2026-09-03 02:08:26.502638+00	t	\\xb4d03590a3fb90b4b8a6d65b16fd39cff9c54f7c596f5bd9ab7b1cb29cbf80ae840709dc5ad7a79dcfd76622819d2c49	3038250
13	auth hardening	2026-09-03 02:08:26.506216+00	t	\\x80873f3a41ee3d97da0f102aaa2ca6cdd3ab694d6ae39bce73b562b1ddc4f0d2ae9b420e5ef83e7a37d3751c41b4dcbf	10544167
14	email	2026-09-03 02:08:26.51719+00	t	\\xebb9ffa31d8098f82137b71a16229cfac857d699bf98a65096795fe62d9da7539b1df8f90dd962b8e26de04717c6355f	6890458
15	sla v1	2026-09-03 02:08:26.524548+00	t	\\x1f3ee82aac676d4729fdeb75ed5f6f13f71bbe15e740ff9c6804af8c6ea11e5ebc41d5c1c7f3aed6b8dc733010f9c0a3	8600125
16	notes taxonomy	2026-09-03 02:08:26.533631+00	t	\\x9989e5a77305b696ed5fd6b755dc86ed811034189063eba417bc66d4add2786d1aac9082c3ba199724c0c091db10dc9a	4533458
17	timer discipline--breaking	2026-09-03 02:08:26.538632+00	t	\\x0c9d0a1c9ead00466cbb9e9a5a5788f3160de47cd30fc56ff7d04f14f446ee9f312740b9ab6b4dce9b920e04d73ed29b	6069333
18	settings registry	2026-09-03 02:08:26.54525+00	t	\\x03bccc5b5a49ef4a27d4a9e36b3d9737419594ec8ae4023a89f60c3cc2600626c91f73a6acf5e262f1010e5dc09e30d5	3323875
19	board organize rbac	2026-09-03 02:08:26.549063+00	t	\\x3ff89f3c0bc9b064617942845fc3284ac58c402f25fc245f93fb99adfe9f2e4233e4c113ae50b9c5ebb6e3ddf4010ff7	4813792
20	webhooks connectors	2026-09-03 02:08:26.554377+00	t	\\xf44ae09c1075c1fe10844aacea9483d928f76d9bd70f071585a6fb9cd2dcf0df4a7e224a140a9eccc80462fd5f12a7fa	5748542
21	portal v1	2026-09-03 02:08:26.560543+00	t	\\xeea3986d5e9573ba17bac76eeb082dd0dac175451459a881e10ef06c7874f5bdd242d91b5f30b5793b1ffc6f6734bfed	6403000
22	calendar scheduling	2026-09-03 02:08:26.56764+00	t	\\x112be008d489dec18a09430086b5da0cc771a6993e99b00f9879863efada2d430122ded11cf7d1778132e09a6e5423fe	30502417
23	search v1	2026-09-03 02:08:26.598759+00	t	\\x6a2aa20cddae7e611fd79ec6f7a78f93555f7a0fe0aa946c9316bab2f5bae3df08d482857834143d7dba88111b9e6a48	6180625
24	attachments	2026-09-03 02:08:26.60547+00	t	\\xfe305ea05195da090228ad7c60731254cb52c7c46981ee61e685d93469c63174b6a1cd1d3d7d9a278d5deb4ea3bd1269	4172792
25	custom fields ui	2026-09-03 02:08:26.610103+00	t	\\xe2c1ee5bdc9342335be80f6431df997c17fba089094b7a675ea35fbefa5385910586e281bcbf7cc59057c46f67b0f939	1985125
26	reports read model	2026-09-03 02:08:26.612491+00	t	\\xe3161abff5238aca6afc642528a27f7d2ba3688450984ec58d0a7ed1c76e6033bed136c9cefb97f20906974924d1a094	5729459
27	import framework	2026-09-03 02:08:26.618696+00	t	\\x9432ded275e648fa1206a0200e6d29d9868120e3a13475680c7bcc0cce722fdcd896a0ec1f98efacda2dba157ef10095	4374833
28	instant first write path	2026-09-03 02:08:26.623495+00	t	\\x8806629f25172ddb8d626d234ebb0e1a54498fddacd602523ee80e961cbb10ae2bb0113172d10682aaebcab7e3f863de	4778833
29	contracts	2026-09-03 02:08:26.628811+00	t	\\xecd0141aca930382257a072b31244e47d354f08d2589e137a43d1baa62b5ba7c1c862cd3755089d787ee1308cbb73f32	5309792
30	projects	2026-09-03 02:08:26.634628+00	t	\\x651aafee60594b0e262d23f90668394775a189f0b46e3549dcca0ac8d0b12200711f2d411797f399f49d563aa942fed0	8776167
31	kb v1--breaking	2026-09-03 02:08:26.643817+00	t	\\xf993f5226688605ba7da868593dc4beaa1c73b169370371e6a179f1e09acb629a79fdfed5e0f5fe6d53beabca1759035	4074292
32	document versions	2026-09-03 02:08:26.648421+00	t	\\x8abd7ccc061acf092349d4a9926380327c6d715b60394d80a8b78dbbc6642e438ba8e22d07d090a5ede7210175ebe6fd	4046792
33	export import d2 remainder	2026-09-03 02:08:26.652985+00	t	\\x742355e71045fdaeaabc132ec3270291db19ad02edce287a42784b886acf297c68370689a2d6112d07bc230cac619d01	3204625
34	report definitions	2026-09-03 02:08:26.65666+00	t	\\xf06a47afc40ee08a67995bb0ffd7543f58d1194822c357733f39fea4398979f1844463541ff4cbf69c924ae660bbe5f0	2874292
35	kb import d5	2026-09-03 02:08:26.65991+00	t	\\x57f73c9fb51662dc52a729c825ec004fa725cea3d25e50bea95765ba9c30501e2b31c07504620ea549fa0cfc9957f7fb	1667666
36	invoicing v1	2026-09-03 02:08:26.661994+00	t	\\xe41f7857f1925d625bf83acc95d6837b456eef8efb1eb68534ca1fb36031bc096d60304a92ee7dbeb28377cdc8421942	9583750
37	alert ingestor	2026-09-03 02:08:26.672166+00	t	\\x09d948b31e7e4324c648abf6be0b76560c8048b7a15b66d05d00d6c6c02b15c4eaba1152b36a0ec384f6de7bf442a6a2	6279709
38	report schedules	2026-09-03 02:08:26.67887+00	t	\\x80a3c8c9bdd5a0bcec5ba1e08224607bc7eccb5e965310b052550b72877804deff6d5e05c2bac00a5133a5403dcada67	5635791
39	portal appointment requests	2026-09-03 02:08:26.685001+00	t	\\x0a17c79e0458196e828cdaf0b62f2d8ef8d24aefbad6da98cff9dfcd5700c89f29427333d44aa19ce80a3873d7043ce9	3918917
40	mcp agent platform	2026-09-03 02:08:26.689329+00	t	\\xfcf4ceb4a345b36744fef05258cd932c9b6fb80be63788f057886d7829b4f6875f93cdc6c0e62cd147b74f5197c713ce	6376500
41	undo read model	2026-09-03 02:08:26.696279+00	t	\\xde4eae6b82bbb4d9c5c1493259b59ef4cf9cc1bc18765d4b235d855ab885d246678d19a588f77963bdee612e6d459384	2667875
42	migration connector	2026-09-03 02:08:26.699373+00	t	\\xc2a662e75f4f1a2d220bf7273cdcde78e36e00e2678b5e0288931d16e52026c780a756ce721dca9cb2a691985fa8ae4f	4049166
43	provenance read model	2026-09-03 02:08:26.703888+00	t	\\x164fc88baeb4b62183c062cc140beff169a8b46c1be8857a4499f048bf624d3d6e5864cbcabb95c5d03ce208925e506d	4127250
44	byok secrets	2026-09-03 02:08:26.70845+00	t	\\xf84219db81b50947f9200f9ff94b8b69ddca7e2a860a5eb51df56211acc0c4ba52a25ec3a3ea945ecf9cff50a22a6d42	2896250
45	dispatch v2	2026-09-03 02:08:26.711774+00	t	\\x87f2090a69badc53e56a7b441ab887fb4be45f21b46f23b5234a9010df98b707647b2dc01ce0bf2ea59c5c0b220cf685	8673250
\.


--
-- Data for Name: agent_proposals; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.agent_proposals (id, org_id, entity, entity_id, op, before_value, proposed_value, classification, capability, dial_mode, base_version, status, agent_kind, agent_ref, skill_slug, skill_version, rule_set_hash, session_id, tool, for_user, rationale, decided_by, decided_at, decision_note, applied_at, created_at, updated_at) FROM stdin;
00000000-0000-4000-8000-000000000424	00000000-0000-4000-8000-000000000001	ticket	00000000-0000-4000-8000-000000000305	update	{"priority": "p3"}	{"priority": "p2"}	internal	tickets:write	proposed	3	proposed	agent	triage-bot@meridian	ticket-triage	1	rules-2026-08	sess-fixture-001	set_priority	00000000-0000-4000-8000-000000000021	5 accounts affected, onboarding deadline	\N	\N	\N	\N	2026-09-03 03:27:13.553703+00	2026-09-03 03:27:13.553703+00
\.


--
-- Data for Name: agent_skills; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.agent_skills (id, org_id, slug, version, manifest, created_by, created_at) FROM stdin;
00000000-0000-4000-8000-000000000423	00000000-0000-4000-8000-000000000001	ticket-triage	1	{"name": "ticket-triage", "tools": ["tickets:read", "tickets:write"], "api_version": 1, "description": "Suggest triage for inbound tickets"}	00000000-0000-4000-8000-000000000021	2026-09-03 03:27:13.553703+00
\.


--
-- Data for Name: alert_incidents; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.alert_incidents (id, org_id, source_id, correlation_key, ticket_id, alert_count, first_alert_at, last_alert_at, closed_at, created_at) FROM stdin;
00000000-0000-4000-8000-000000000374	00000000-0000-4000-8000-000000000001	00000000-0000-4000-8000-000000000371	device:nw-fw-01	00000000-0000-4000-8000-000000000301	3	2026-09-01 08:20:00+00	2026-09-01 08:50:00+00	\N	2026-09-03 03:27:13.553703+00
\.


--
-- Data for Name: alert_sources; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.alert_sources (id, org_id, name, source_ref, secret_encrypted, board_id, client_id, correlation_window_secs, enabled, created_by, created_at, updated_at) FROM stdin;
00000000-0000-4000-8000-000000000371	00000000-0000-4000-8000-000000000001	NinjaOne production	ninjaone:prod-tenant	\\x616c657274736f7572636573656372657430313233343536373839616263	00000000-0000-4000-8000-000000000081	00000000-0000-4000-8000-000000000051	900	t	00000000-0000-4000-8000-000000000021	2026-09-03 03:27:13.553703+00	2026-09-03 03:27:13.553703+00
\.


--
-- Data for Name: alerts; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.alerts (id, org_id, source_id, dedup_key, correlation_key, title, description, severity, occurred_at, attributes, incident_ticket_id, received_at) FROM stdin;
00000000-0000-4000-8000-000000000372	00000000-0000-4000-8000-000000000001	00000000-0000-4000-8000-000000000371	nw-fw-01-wan-20260901	device:nw-fw-01	WAN interface down	Interface eth0 lost link	critical	2026-09-01 08:20:00+00	{"site": "HQ", "device": "NW-FW-01"}	00000000-0000-4000-8000-000000000301	2026-09-03 03:27:13.553703+00
00000000-0000-4000-8000-000000000373	00000000-0000-4000-8000-000000000001	00000000-0000-4000-8000-000000000371	nw-esx-02-diskwarn	device:nw-esx-02	Disk usage warning	Volume at 82%	warning	2026-08-30 05:10:00+00	{"device": "NW-ESX-02"}	\N	2026-09-03 03:27:13.553703+00
\.


--
-- Data for Name: api_keys; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.api_keys (id, org_id, name, key_hash, prefix, scopes, created_by, last_used_at, revoked_at, created_at) FROM stdin;
00000000-0000-4000-8000-000000000041	00000000-0000-4000-8000-000000000001	CI integration	argon2$fixtureseed$apikey01	mrd_ab12cd34	["tickets:read", "clients:read", "time_entries:read"]	00000000-0000-4000-8000-000000000021	2026-09-02 02:00:00+00	\N	2026-09-03 03:27:13.553703+00
00000000-0000-4000-8000-000000000042	00000000-0000-4000-8000-000000000001	Legacy exporter	argon2$fixtureseed$apikey02	mrd_ef90ab12	["clients:read"]	00000000-0000-4000-8000-000000000021	2026-07-01 00:00:00+00	2026-08-01 00:00:00+00	2026-09-03 03:27:13.553703+00
\.


--
-- Data for Name: appointments; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.appointments (id, org_id, user_id, ticket_id, client_id, site_id, title, starts_at, ends_at, kind, status, travel_minutes, notes, created_at, updated_at) FROM stdin;
00000000-0000-4000-8000-000000000395	00000000-0000-4000-8000-000000000001	00000000-0000-4000-8000-000000000023	00000000-0000-4000-8000-000000000304	00000000-0000-4000-8000-000000000051	00000000-0000-4000-8000-000000000054	Printer maintenance visit	2026-09-10 17:00:00+00	2026-09-10 19:00:00+00	on_site	scheduled	45	Parts in van stock	2026-09-03 03:27:13.553703+00	2026-09-03 03:27:13.553703+00
\.


--
-- Data for Name: attachments; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.attachments (id, org_id, kind, ticket_id, ticket_comment_id, email_message_id, filename, content_type, size_bytes, sha256, storage_key, uploaded_by_user_id, uploaded_by_portal_user_id, created_at) FROM stdin;
00000000-0000-4000-8000-000000000481	00000000-0000-4000-8000-000000000001	ticket	00000000-0000-4000-8000-000000000301	\N	\N	wan-graph.png	image/png	48213	e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855	fixtures/v0.2.0/wan-graph.png	00000000-0000-4000-8000-000000000023	\N	2026-09-03 03:27:13.553703+00
\.


--
-- Data for Name: audit_events; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.audit_events (id, org_id, actor_kind, actor_id, action, entity_type, entity_id, detail, ip, occurred_at) FROM stdin;
00000000-0000-4000-8000-000000000441	00000000-0000-4000-8000-000000000001	human	00000000-0000-4000-8000-000000000021	auth.login	user	00000000-0000-4000-8000-000000000021	{"mfa": false}	203.0.113.10	2026-09-01 12:55:00+00
00000000-0000-4000-8000-000000000442	00000000-0000-4000-8000-000000000001	agent	triage-bot@meridian	ticket.update	ticket	00000000-0000-4000-8000-000000000301	{"field": "priority"}	\N	2026-09-01 13:02:00+00
00000000-0000-4000-8000-000000000443	00000000-0000-4000-8000-000000000001	import	00000000-0000-4000-8000-000000000381	import.batch	import_batch	00000000-0000-4000-8000-000000000381	{"rows": 42}	\N	2026-04-10 09:04:00+00
00000000-0000-4000-8000-000000000444	00000000-0000-4000-8000-000000000001	system	\N	sla.escalation	ticket	00000000-0000-4000-8000-000000000301	{"step": 0, "target": "first_response"}	\N	2026-09-01 09:29:00+00
00000000-0000-4000-8000-000000000445	00000000-0000-4000-8000-000000000001	portal_contact	00000000-0000-4000-8000-000000000391	portal.login	portal_user	00000000-0000-4000-8000-000000000391	{}	198.51.100.7	2026-09-02 08:00:00+00
\.


--
-- Data for Name: auth_sessions; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.auth_sessions (id, user_id, refresh_token_hash, user_agent, expires_at, created_at, revoked_at, chain_id, rotated_from) FROM stdin;
00000000-0000-4000-8000-000000000036	00000000-0000-4000-8000-000000000021	sha256$fixtureseed$authsession01	Mozilla/5.0 fixture	2026-10-01 00:00:00+00	2026-09-03 03:27:13.553703+00	\N	00000000-0000-4000-8000-000000000037	\N
\.


--
-- Data for Name: automation_rules; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.automation_rules (id, org_id, board_id, name, trigger_event, conditions, actions, enabled, created_at, updated_at) FROM stdin;
00000000-0000-4000-8000-000000000121	00000000-0000-4000-8000-000000000001	\N	P1 pages on-call	ticket.created	[{"op": "equals", "field": "priority", "value": "p1"}]	[{"type": "assign", "user_id": "00000000-0000-4000-8000-000000000023"}, {"kind": "sla_risk", "type": "notify", "user_ids": ["00000000-0000-4000-8000-000000000022"]}]	t	2026-09-03 03:27:13.553703+00	2026-09-03 03:27:13.553703+00
00000000-0000-4000-8000-000000000122	00000000-0000-4000-8000-000000000001	00000000-0000-4000-8000-000000000081	Waiting-state watchdog	ticket.status_changed	[{"op": "equals", "field": "to_category", "value": "waiting"}]	[{"body": "Flagged as waiting — remember to follow up.", "type": "add_comment"}]	t	2026-09-03 03:27:13.553703+00	2026-09-03 03:27:13.553703+00
00000000-0000-4000-8000-000000000123	00000000-0000-4000-8000-000000000001	00000000-0000-4000-8000-000000000082	Stale intake reminder	ticket.commented	[{"op": "equals", "field": "category", "value": "open"}]	[{"kind": "ticket_update", "type": "notify", "user_ids": ["00000000-0000-4000-8000-000000000024"]}]	f	2026-09-03 03:27:13.553703+00	2026-09-03 03:27:13.553703+00
\.


--
-- Data for Name: availability_windows; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.availability_windows (id, org_id, user_id, weekday, start_local, end_local, timezone, effective_from, effective_until, created_at) FROM stdin;
00000000-0000-4000-8000-000000000396	00000000-0000-4000-8000-000000000001	00000000-0000-4000-8000-000000000023	1	09:00:00	17:00:00	America/Chicago	\N	\N	2026-09-03 03:27:13.553703+00
00000000-0000-4000-8000-000000000397	00000000-0000-4000-8000-000000000001	00000000-0000-4000-8000-000000000023	3	09:00:00	17:00:00	America/Chicago	\N	\N	2026-09-03 03:27:13.553703+00
\.


--
-- Data for Name: board_checklist_templates; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.board_checklist_templates (id, org_id, board_id, name, created_at, updated_at) FROM stdin;
00000000-0000-4000-8000-000000000111	00000000-0000-4000-8000-000000000001	00000000-0000-4000-8000-000000000081	Resolution checklist	2026-09-03 03:27:13.553703+00	2026-09-03 03:27:13.553703+00
\.


--
-- Data for Name: board_favorites; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.board_favorites (user_id, board_id, sort_order) FROM stdin;
00000000-0000-4000-8000-000000000021	00000000-0000-4000-8000-000000000081	0
\.


--
-- Data for Name: board_groups; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.board_groups (id, org_id, owner_id, name, "position", created_at) FROM stdin;
00000000-0000-4000-8000-000000000071	00000000-0000-4000-8000-000000000001	00000000-0000-4000-8000-000000000021	Service Delivery	0	2026-09-03 03:27:13.553703+00
\.


--
-- Data for Name: board_members; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.board_members (org_id, board_id, user_id, role, created_at) FROM stdin;
00000000-0000-4000-8000-000000000001	00000000-0000-4000-8000-000000000081	00000000-0000-4000-8000-000000000023	admin	2026-09-03 03:27:13.553703+00
00000000-0000-4000-8000-000000000001	00000000-0000-4000-8000-000000000082	00000000-0000-4000-8000-000000000024	viewer	2026-09-03 03:27:13.553703+00
\.


--
-- Data for Name: board_portal_exposure; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.board_portal_exposure (id, org_id, board_id, client_id, exposed, visible_status_ids, created_at, updated_at) FROM stdin;
00000000-0000-4000-8000-000000000394	00000000-0000-4000-8000-000000000001	00000000-0000-4000-8000-000000000081	00000000-0000-4000-8000-000000000051	t	{00000000-0000-4000-8000-000000000091,00000000-0000-4000-8000-000000000093,00000000-0000-4000-8000-000000000094}	2026-09-03 03:27:13.553703+00	2026-09-03 03:27:13.553703+00
\.


--
-- Data for Name: board_status_transitions; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.board_status_transitions (org_id, board_id, from_status_id, to_status_id) FROM stdin;
00000000-0000-4000-8000-000000000001	00000000-0000-4000-8000-000000000081	00000000-0000-4000-8000-000000000091	00000000-0000-4000-8000-000000000092
00000000-0000-4000-8000-000000000001	00000000-0000-4000-8000-000000000081	00000000-0000-4000-8000-000000000091	00000000-0000-4000-8000-000000000095
00000000-0000-4000-8000-000000000001	00000000-0000-4000-8000-000000000081	00000000-0000-4000-8000-000000000092	00000000-0000-4000-8000-000000000093
00000000-0000-4000-8000-000000000001	00000000-0000-4000-8000-000000000081	00000000-0000-4000-8000-000000000092	00000000-0000-4000-8000-000000000094
00000000-0000-4000-8000-000000000001	00000000-0000-4000-8000-000000000081	00000000-0000-4000-8000-000000000093	00000000-0000-4000-8000-000000000092
00000000-0000-4000-8000-000000000001	00000000-0000-4000-8000-000000000081	00000000-0000-4000-8000-000000000094	00000000-0000-4000-8000-000000000092
00000000-0000-4000-8000-000000000001	00000000-0000-4000-8000-000000000081	00000000-0000-4000-8000-000000000095	00000000-0000-4000-8000-000000000092
\.


--
-- Data for Name: board_statuses; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.board_statuses (id, board_id, org_id, name, category, sort_order, is_entry, color) FROM stdin;
00000000-0000-4000-8000-000000000091	00000000-0000-4000-8000-000000000081	00000000-0000-4000-8000-000000000001	New	open	0	t	#64748b
00000000-0000-4000-8000-000000000092	00000000-0000-4000-8000-000000000081	00000000-0000-4000-8000-000000000001	Triage	in_progress	1	f	#0ea5e9
00000000-0000-4000-8000-000000000093	00000000-0000-4000-8000-000000000081	00000000-0000-4000-8000-000000000001	Waiting on Customer	waiting	2	f	#f59e0b
00000000-0000-4000-8000-000000000094	00000000-0000-4000-8000-000000000081	00000000-0000-4000-8000-000000000001	Resolved	closed	3	f	#10b981
00000000-0000-4000-8000-000000000095	00000000-0000-4000-8000-000000000081	00000000-0000-4000-8000-000000000001	Scheduled	waiting	4	f	#8b5cf6
00000000-0000-4000-8000-000000000096	00000000-0000-4000-8000-000000000082	00000000-0000-4000-8000-000000000001	Intake	open	0	t	#64748b
00000000-0000-4000-8000-000000000097	00000000-0000-4000-8000-000000000082	00000000-0000-4000-8000-000000000001	Scoping	in_progress	1	f	#0ea5e9
00000000-0000-4000-8000-000000000098	00000000-0000-4000-8000-000000000082	00000000-0000-4000-8000-000000000001	On Hold	waiting	2	f	#f59e0b
00000000-0000-4000-8000-000000000099	00000000-0000-4000-8000-000000000082	00000000-0000-4000-8000-000000000001	Delivered	closed	3	f	#10b981
\.


--
-- Data for Name: boards; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.boards (id, org_id, name, description, is_default, created_at, inbound_address, require_checklist_close, board_group_id) FROM stdin;
00000000-0000-4000-8000-000000000081	00000000-0000-4000-8000-000000000001	Service Desk	Default intake for client requests	t	2026-09-03 03:27:13.553703+00	support-8f2k@inbound.acme-it.example	t	00000000-0000-4000-8000-000000000071
00000000-0000-4000-8000-000000000082	00000000-0000-4000-8000-000000000001	Projects Board	Non-ticket project work intake	f	2026-09-03 03:27:13.553703+00	\N	f	00000000-0000-4000-8000-000000000071
\.


--
-- Data for Name: byok_secrets; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.byok_secrets (id, org_id, provider, secret_encrypted, created_by, created_at, updated_at) FROM stdin;
00000000-0000-4000-8000-000000000463	00000000-0000-4000-8000-000000000001	openai	\\x62796f6b736563726574666978747572653031323334353637383930	00000000-0000-4000-8000-000000000021	2026-09-03 03:27:13.553703+00	2026-09-03 03:27:13.553703+00
\.


--
-- Data for Name: calendar_exclusions; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.calendar_exclusions (id, org_id, user_id, starts_at, ends_at, reason, created_at) FROM stdin;
00000000-0000-4000-8000-000000000399	00000000-0000-4000-8000-000000000001	00000000-0000-4000-8000-000000000023	2026-09-21 08:00:00+00	2026-09-25 08:00:00+00	PTO	2026-09-03 03:27:13.553703+00
\.


--
-- Data for Name: checklist_items; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.checklist_items (id, org_id, ticket_id, text, checked, sort_order, checked_by, checked_at, template_item_id) FROM stdin;
00000000-0000-4000-8000-000000000321	00000000-0000-4000-8000-000000000001	00000000-0000-4000-8000-000000000301	Root cause documented	t	0	00000000-0000-4000-8000-000000000023	2026-09-01 16:00:00+00	00000000-0000-4000-8000-000000000112
00000000-0000-4000-8000-000000000322	00000000-0000-4000-8000-000000000001	00000000-0000-4000-8000-000000000301	KB article linked or created	f	1	\N	\N	00000000-0000-4000-8000-000000000113
00000000-0000-4000-8000-000000000323	00000000-0000-4000-8000-000000000001	00000000-0000-4000-8000-000000000301	Client notified	f	2	\N	\N	00000000-0000-4000-8000-000000000114
\.


--
-- Data for Name: checklist_template_items; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.checklist_template_items (id, org_id, template_id, text, sort_order) FROM stdin;
00000000-0000-4000-8000-000000000112	00000000-0000-4000-8000-000000000001	00000000-0000-4000-8000-000000000111	Root cause documented	0
00000000-0000-4000-8000-000000000113	00000000-0000-4000-8000-000000000001	00000000-0000-4000-8000-000000000111	KB article linked or created	1
00000000-0000-4000-8000-000000000114	00000000-0000-4000-8000-000000000001	00000000-0000-4000-8000-000000000111	Client notified	2
\.


--
-- Data for Name: clients; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.clients (id, org_id, name, restricted_to, notes, created_at, updated_at) FROM stdin;
00000000-0000-4000-8000-000000000051	00000000-0000-4000-8000-000000000001	Northwind Traders	[]	Flagship MSP account	2026-09-03 03:27:13.553703+00	2026-09-03 03:27:13.553703+00
00000000-0000-4000-8000-000000000052	00000000-0000-4000-8000-000000000001	Contoso Manufacturing	[]	\N	2026-09-03 03:27:13.553703+00	2026-09-03 03:27:13.553703+00
\.


--
-- Data for Name: connector_installations; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.connector_installations (id, org_id, connector_type, config_encrypted, capability_scopes, consented_by, created_at, updated_at) FROM stdin;
00000000-0000-4000-8000-000000000461	00000000-0000-4000-8000-000000000001	qbo-export-sync	\\x776f726b666c6f77736563726574313233343536373839616263646566	{billing:export,clients:read}	00000000-0000-4000-8000-000000000021	2026-09-03 03:27:13.553703+00	2026-09-03 03:27:13.553703+00
00000000-0000-4000-8000-000000000462	00000000-0000-4000-8000-000000000001	immybot	\\x696d6d79626f74	{alerts:ingest}	00000000-0000-4000-8000-000000000021	2026-09-03 03:27:13.553703+00	2026-09-03 03:27:13.553703+00
\.


--
-- Data for Name: contacts; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.contacts (id, org_id, client_id, site_id, name, email, phone, title, is_primary, created_at) FROM stdin;
00000000-0000-4000-8000-000000000057	00000000-0000-4000-8000-000000000001	00000000-0000-4000-8000-000000000051	00000000-0000-4000-8000-000000000054	Lena Fischer	lena.fischer@northwind.example	+1-206-555-0141	IT Manager	t	2026-09-03 03:27:13.553703+00
00000000-0000-4000-8000-000000000058	00000000-0000-4000-8000-000000000001	00000000-0000-4000-8000-000000000052	00000000-0000-4000-8000-000000000055	Marco Ruiz	marco.ruiz@contoso.example	+1-313-555-0177	Plant Systems Lead	t	2026-09-03 03:27:13.553703+00
\.


--
-- Data for Name: contract_fixed_fees; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.contract_fixed_fees (id, org_id, contract_id, label, amount_minor, due_on, notes, created_at) FROM stdin;
00000000-0000-4000-8000-000000000206	00000000-0000-4000-8000-000000000001	00000000-0000-4000-8000-000000000203	SOC rollout milestone 1	250000	2026-10-01	On phase completion	2026-09-03 03:27:13.553703+00
\.


--
-- Data for Name: contract_rates; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.contract_rates (id, org_id, contract_id, work_type, rate_minor, created_at) FROM stdin;
00000000-0000-4000-8000-000000000204	00000000-0000-4000-8000-000000000001	00000000-0000-4000-8000-000000000201	remote	15000	2026-09-03 03:27:13.553703+00
00000000-0000-4000-8000-000000000205	00000000-0000-4000-8000-000000000001	00000000-0000-4000-8000-000000000201	on_site	19000	2026-09-03 03:27:13.553703+00
\.


--
-- Data for Name: contracts; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.contracts (id, org_id, client_id, number, name, contract_type, status, currency, effective_from, effective_until, billing_frequency, billing_anchor, amount_minor, hourly_rate_minor, included_minutes, overage_rate_minor, notes, created_at, updated_at) FROM stdin;
00000000-0000-4000-8000-000000000201	00000000-0000-4000-8000-000000000001	00000000-0000-4000-8000-000000000051	CTR-2026-001	Northwind managed services	recurring	active	USD	2026-01-01	2026-12-31	monthly	2026-02-01	150000	\N	600	15000	Auto-renews annually	2026-09-03 03:27:13.553703+00	2026-09-03 03:27:13.553703+00
00000000-0000-4000-8000-000000000203	00000000-0000-4000-8000-000000000001	00000000-0000-4000-8000-000000000052	CTR-2026-002	Contoso retainer	retainer	active	USD	2026-03-01	\N	\N	\N	120000	\N	\N	\N	\N	2026-09-03 03:27:13.553703+00	2026-09-03 03:27:13.553703+00
\.


--
-- Data for Name: custom_field_defs; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.custom_field_defs (id, org_id, entity, name, kind, config, required, sort_order, archived_at, created_at, board_id) FROM stdin;
00000000-0000-4000-8000-000000000101	00000000-0000-4000-8000-000000000001	ticket	Environment	select	{"options": ["Production", "Staging", "Development"]}	t	0	\N	2026-09-03 03:27:13.553703+00	00000000-0000-4000-8000-000000000081
00000000-0000-4000-8000-000000000102	00000000-0000-4000-8000-000000000001	ticket	Business Impact	text	{"max_length": 280}	t	1	\N	2026-09-03 03:27:13.553703+00	\N
00000000-0000-4000-8000-000000000103	00000000-0000-4000-8000-000000000001	ticket	Estimated Hours	number	{"max": 500, "min": 0, "step": 0.5}	f	2	\N	2026-09-03 03:27:13.553703+00	\N
00000000-0000-4000-8000-000000000104	00000000-0000-4000-8000-000000000001	client	Contract Tier	select	{"options": ["Bronze", "Silver", "Gold"]}	f	0	\N	2026-09-03 03:27:13.553703+00	\N
00000000-0000-4000-8000-000000000105	00000000-0000-4000-8000-000000000001	contact	Preferred Language	select	{"options": ["English", "Spanish", "German"]}	f	0	\N	2026-09-03 03:27:13.553703+00	\N
00000000-0000-4000-8000-000000000106	00000000-0000-4000-8000-000000000001	asset	Warranty Expiry	date	{}	f	0	\N	2026-09-03 03:27:13.553703+00	\N
00000000-0000-4000-8000-000000000107	00000000-0000-4000-8000-000000000001	ticket	Legacy Source ID	text	{}	f	3	2026-05-01 00:00:00+00	2026-09-03 03:27:13.553703+00	\N
\.


--
-- Data for Name: custom_field_values; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.custom_field_values (field_id, entity_id, org_id, value) FROM stdin;
00000000-0000-4000-8000-000000000101	00000000-0000-4000-8000-000000000301	00000000-0000-4000-8000-000000000001	"Production"
00000000-0000-4000-8000-000000000102	00000000-0000-4000-8000-000000000301	00000000-0000-4000-8000-000000000001	"Full branch office outage risk"
00000000-0000-4000-8000-000000000103	00000000-0000-4000-8000-000000000301	00000000-0000-4000-8000-000000000001	6.5
00000000-0000-4000-8000-000000000101	00000000-0000-4000-8000-000000000305	00000000-0000-4000-8000-000000000001	"Staging"
00000000-0000-4000-8000-000000000107	00000000-0000-4000-8000-000000000302	00000000-0000-4000-8000-000000000001	"CW-99120"
00000000-0000-4000-8000-000000000104	00000000-0000-4000-8000-000000000051	00000000-0000-4000-8000-000000000001	"Gold"
00000000-0000-4000-8000-000000000105	00000000-0000-4000-8000-000000000058	00000000-0000-4000-8000-000000000001	"Spanish"
00000000-0000-4000-8000-000000000106	00000000-0000-4000-8000-000000000059	00000000-0000-4000-8000-000000000001	"2027-03-31"
\.


--
-- Data for Name: device_assets; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.device_assets (id, org_id, client_id, site_id, tag, name, kind, status, created_at, updated_at) FROM stdin;
00000000-0000-4000-8000-000000000059	00000000-0000-4000-8000-000000000001	00000000-0000-4000-8000-000000000051	00000000-0000-4000-8000-000000000054	NW-FW-01	Perimeter firewall	device	active	2026-09-03 03:27:13.553703+00	2026-09-03 03:27:13.553703+00
\.


--
-- Data for Name: dispatch_queue_entries; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.dispatch_queue_entries (id, org_id, ticket_id, rank, note, created_by, created_at, updated_at) FROM stdin;
00000000-0000-4000-8000-000000000411	00000000-0000-4000-8000-000000000001	00000000-0000-4000-8000-000000000304	0	Morning run — bring toner	00000000-0000-4000-8000-000000000021	2026-09-03 03:27:13.553703+00	2026-09-03 03:27:13.553703+00
\.


--
-- Data for Name: dispatch_status_updates; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.dispatch_status_updates (id, org_id, appointment_id, status, note, actor_id, source, occurred_at, created_at) FROM stdin;
00000000-0000-4000-8000-000000000412	00000000-0000-4000-8000-000000000001	00000000-0000-4000-8000-000000000395	en_route	On the way	00000000-0000-4000-8000-000000000023	connector	2026-09-03 03:27:13.553703+00	2026-09-03 03:27:13.553703+00
\.


--
-- Data for Name: document_versions; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.document_versions (id, org_id, document_id, version, title, body, change_summary, author_id, restored_from_version, created_at) FROM stdin;
00000000-0000-4000-8000-000000000193	00000000-0000-4000-8000-000000000001	00000000-0000-4000-8000-000000000191	1	Network topology — Northwind HQ	v1 body	Initial import	00000000-0000-4000-8000-000000000022	\N	2026-09-03 03:27:13.553703+00
00000000-0000-4000-8000-000000000194	00000000-0000-4000-8000-000000000001	00000000-0000-4000-8000-000000000191	2	Network topology — Northwind HQ	v2 body with new VLANs	Added VLAN 40 refresh	00000000-0000-4000-8000-000000000022	\N	2026-09-03 03:27:13.553703+00
00000000-0000-4000-8000-000000000195	00000000-0000-4000-8000-000000000001	00000000-0000-4000-8000-000000000192	1	Escalation policy	Escalation ladder document	Initial version	00000000-0000-4000-8000-000000000021	\N	2026-09-03 03:27:13.553703+00
\.


--
-- Data for Name: documents; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.documents (id, org_id, title, current_version, created_by, updated_by, created_at, updated_at) FROM stdin;
00000000-0000-4000-8000-000000000191	00000000-0000-4000-8000-000000000001	Network topology — Northwind HQ	2	00000000-0000-4000-8000-000000000022	00000000-0000-4000-8000-000000000022	2026-09-03 03:27:13.553703+00	2026-09-03 03:27:13.553703+00
00000000-0000-4000-8000-000000000192	00000000-0000-4000-8000-000000000001	Escalation policy	1	00000000-0000-4000-8000-000000000021	00000000-0000-4000-8000-000000000021	2026-09-03 03:27:13.553703+00	2026-09-03 03:27:13.553703+00
\.


--
-- Data for Name: email_inbound_settings; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.email_inbound_settings (id, org_id, catchall_address, catchall_board_id, enabled, created_at) FROM stdin;
00000000-0000-4000-8000-000000000351	00000000-0000-4000-8000-000000000001	support-8f2k@inbound.acme-it.example	00000000-0000-4000-8000-000000000081	t	2026-09-03 03:27:13.553703+00
\.


--
-- Data for Name: email_messages; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.email_messages (id, org_id, direction, rfc_message_id, in_reply_to, email_refs, subject, from_address, from_name, to_addresses, body_text, ticket_id, comment_id, scan_status, transport, raw_ref, created_at) FROM stdin;
00000000-0000-4000-8000-000000000352	00000000-0000-4000-8000-000000000001	inbound	<fw-update-1@northwind.example>	\N	{}	Re: Firewall flapping	lena.fischer@northwind.example	Lena Fischer	{support-8f2k@inbound.acme-it.example}	Any update on the drops?	00000000-0000-4000-8000-000000000301	00000000-0000-4000-8000-000000000312	clean	smtp	\N	2026-09-03 03:27:13.553703+00
00000000-0000-4000-8000-000000000353	00000000-0000-4000-8000-000000000001	outbound	<meridian-reply-001@acme-it.example>	<fw-update-1@northwind.example>	{<fw-update-1@northwind.example>}	Re: Firewall flapping	support@acme-it.example	Acme IT Support	{lena.fischer@northwind.example}	Rollback scheduled tonight.	00000000-0000-4000-8000-000000000301	00000000-0000-4000-8000-000000000311	clean	smtp	\N	2026-09-03 03:27:13.553703+00
\.


--
-- Data for Name: email_outbound; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.email_outbound (id, org_id, email_message_id, status, attempts, max_attempts, next_attempt_at, last_error, provider_message_id, claimed_at, created_at, updated_at) FROM stdin;
00000000-0000-4000-8000-000000000354	00000000-0000-4000-8000-000000000001	00000000-0000-4000-8000-000000000353	sent	1	8	2026-09-01 13:30:00+00	\N	relay-20260901-001	\N	2026-09-03 03:27:13.553703+00	2026-09-03 03:27:13.553703+00
\.


--
-- Data for Name: entity_write_seqs; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.entity_write_seqs (org_id, entity, entity_id, seq, updated_at) FROM stdin;
00000000-0000-4000-8000-000000000001	ticket	00000000-0000-4000-8000-000000000301	3	2026-09-03 03:27:13.553703+00
\.


--
-- Data for Name: entity_writes; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.entity_writes (id, org_id, entity, entity_id, seq, op, actor_id, actor_kind, idempotency_key, before, after, created_at, session_id, skill, ruleset_hash, is_undo) FROM stdin;
00000000-0000-4000-8000-000000000431	00000000-0000-4000-8000-000000000001	ticket	00000000-0000-4000-8000-000000000301	1	update	00000000-0000-4000-8000-000000000023	human	\N	{"status": "open"}	{"status": "in_progress"}	2026-09-03 03:27:13.553703+00	\N	\N	\N	f
00000000-0000-4000-8000-000000000432	00000000-0000-4000-8000-000000000001	ticket	00000000-0000-4000-8000-000000000301	2	update	00000000-0000-4000-8000-000000000022	agent	\N	{"priority": "p2"}	{"priority": "p1"}	2026-09-03 03:27:13.553703+00	00000000-0000-4000-8000-000000000434	ticket-triage	rules-2026-08	f
\.


--
-- Data for Name: external_ids; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.external_ids (id, org_id, entity_kind, external_key, internal_id, last_seen_batch, created_at, updated_at) FROM stdin;
00000000-0000-4000-8000-000000000382	00000000-0000-4000-8000-000000000001	client	NW-001	00000000-0000-4000-8000-000000000051	00000000-0000-4000-8000-000000000381	2026-09-03 03:27:13.553703+00	2026-09-03 03:27:13.553703+00
00000000-0000-4000-8000-000000000383	00000000-0000-4000-8000-000000000001	ticket	CW-99120	00000000-0000-4000-8000-000000000302	\N	2026-09-03 03:27:13.553703+00	2026-09-03 03:27:13.553703+00
\.


--
-- Data for Name: idempotency_keys; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.idempotency_keys (id, org_id, key, entity, entity_id, request_hash, response, actor_id, created_at) FROM stdin;
00000000-0000-4000-8000-000000000433	00000000-0000-4000-8000-000000000001	idem-fixture-0001	ticket	00000000-0000-4000-8000-000000000305	sha256$fixtureseed$req01	{"id": "00000000-0000-4000-8000-000000000305"}	00000000-0000-4000-8000-000000000021	2026-09-03 03:27:13.553703+00
\.


--
-- Data for Name: import_batches; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.import_batches (id, org_id, label, source_note, entity_kind, conflict_policy, dry_run, rows_total, rows_created, rows_updated, rows_skipped, rows_failed, created_by, created_by_kind, started_at, finished_at, staged_chunks, queued_at) FROM stdin;
00000000-0000-4000-8000-000000000381	00000000-0000-4000-8000-000000000001	Northwind client import	connectwise export	client	update	f	42	40	2	0	0	00000000-0000-4000-8000-000000000021	user	2026-04-10 09:00:00+00	2026-04-10 09:04:00+00	3	2026-04-10 09:01:00+00
\.


--
-- Data for Name: import_mapping_templates; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.import_mapping_templates (id, org_id, name, source_system, entity_kind, mapping, created_by, created_by_kind, created_at, updated_at) FROM stdin;
00000000-0000-4000-8000-000000000384	00000000-0000-4000-8000-000000000001	ConnectWise clients	connectwise	client	{"name": "company_name", "notes": "note_text", "external_key": "company_id"}	00000000-0000-4000-8000-000000000021	user	2026-09-03 03:27:13.553703+00	2026-09-03 03:27:13.553703+00
\.


--
-- Data for Name: invoice_lines; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.invoice_lines (id, org_id, invoice_id, contract_id, kind, description, period_start, period_end, quantity_minutes, unit_amount_minor, amount_minor, "position") FROM stdin;
00000000-0000-4000-8000-000000000364	00000000-0000-4000-8000-000000000001	00000000-0000-4000-8000-000000000362	00000000-0000-4000-8000-000000000201	recurring_base	Managed services — August	2026-08-01	2026-08-31	0	150000	150000	0
00000000-0000-4000-8000-000000000365	00000000-0000-4000-8000-000000000001	00000000-0000-4000-8000-000000000362	00000000-0000-4000-8000-000000000201	time_materials	Remote support overage	2026-08-01	2026-08-31	165	15000	15000	1
00000000-0000-4000-8000-000000000366	00000000-0000-4000-8000-000000000001	00000000-0000-4000-8000-000000000363	00000000-0000-4000-8000-000000000203	retainer_base	Retainer — August	2026-08-01	2026-08-31	0	120000	120000	0
\.


--
-- Data for Name: invoice_payments; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.invoice_payments (id, org_id, invoice_id, amount_minor, currency, provider, provider_ref, notes, received_at, created_by) FROM stdin;
00000000-0000-4000-8000-000000000368	00000000-0000-4000-8000-000000000001	00000000-0000-4000-8000-000000000363	120000	USD	none	ACH-20260901-7	Client ACH transfer	2026-09-03 03:27:13.553703+00	00000000-0000-4000-8000-000000000021
\.


--
-- Data for Name: invoice_runs; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.invoice_runs (id, org_id, number, period_from, period_to, invoice_count, total_minor, currency, due_in_days, created_by, created_at) FROM stdin;
00000000-0000-4000-8000-000000000361	00000000-0000-4000-8000-000000000001	RUN-2026-08	2026-08-01	2026-08-31	2	165000	USD	30	00000000-0000-4000-8000-000000000021	2026-09-03 03:27:13.553703+00
\.


--
-- Data for Name: invoice_time_entries; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.invoice_time_entries (id, org_id, invoice_id, time_entry_id) FROM stdin;
00000000-0000-4000-8000-000000000367	00000000-0000-4000-8000-000000000001	00000000-0000-4000-8000-000000000362	00000000-0000-4000-8000-000000000332
\.


--
-- Data for Name: invoices; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.invoices (id, org_id, run_id, client_id, contract_id, number, status, currency, period_from, period_to, issued_at, due_on, total_minor, total_paid_minor, dunning_state, dunning_updated_at, dunning_note, notes, created_by, created_at, updated_at) FROM stdin;
00000000-0000-4000-8000-000000000362	00000000-0000-4000-8000-000000000001	00000000-0000-4000-8000-000000000361	00000000-0000-4000-8000-000000000051	00000000-0000-4000-8000-000000000201	ACM-INV-0001	issued	USD	2026-08-01	2026-08-31	2026-09-01	2026-10-01	165000	0	reminder_sent	2026-09-02 09:00:00+00	\N	\N	00000000-0000-4000-8000-000000000021	2026-09-03 03:27:13.553703+00	2026-09-03 03:27:13.553703+00
00000000-0000-4000-8000-000000000363	00000000-0000-4000-8000-000000000001	00000000-0000-4000-8000-000000000361	00000000-0000-4000-8000-000000000052	00000000-0000-4000-8000-000000000203	ACM-INV-0002	paid	USD	2026-08-01	2026-08-31	2026-09-01	2026-10-01	120000	120000	none	\N	\N	Paid via ACH	00000000-0000-4000-8000-000000000021	2026-09-03 03:27:13.553703+00	2026-09-03 03:27:13.553703+00
\.


--
-- Data for Name: jobs; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.jobs (id, org_id, kind, payload, status, run_after, attempts, max_attempts, last_error, claimed_at, claimed_by, created_at, updated_at) FROM stdin;
00000000-0000-4000-8000-000000000464	00000000-0000-4000-8000-000000000001	webhook.deliver	{"event_id": "00000000-0000-4000-8000-000000000452", "webhook_id": "00000000-0000-4000-8000-000000000131"}	pending	2026-09-03 03:00:00+00	0	5	\N	\N	\N	2026-09-03 03:27:13.553703+00	2026-09-03 03:27:13.553703+00
\.


--
-- Data for Name: kb_articles; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.kb_articles (id, org_id, category_id, title, slug, body, status, client_visible, created_by, updated_by, created_at, updated_at) FROM stdin;
00000000-0000-4000-8000-000000000183	00000000-0000-4000-8000-000000000001	00000000-0000-4000-8000-000000000181	Welcome to the portal	welcome-to-the-portal	# Welcome\\n\\nHow to raise your first request.	published	t	00000000-0000-4000-8000-000000000021	00000000-0000-4000-8000-000000000021	2026-09-03 03:27:13.553703+00	2026-09-03 03:27:13.553703+00
00000000-0000-4000-8000-000000000184	00000000-0000-4000-8000-000000000001	00000000-0000-4000-8000-000000000181	VPN setup guide	vpn-setup	# VPN\\n\\nStep-by-step VPN onboarding.	published	t	00000000-0000-4000-8000-000000000023	00000000-0000-4000-8000-000000000023	2026-09-03 03:27:13.553703+00	2026-09-03 03:27:13.553703+00
00000000-0000-4000-8000-000000000185	00000000-0000-4000-8000-000000000001	00000000-0000-4000-8000-000000000182	Firewall change runbook	firewall-change-runbook	# Runbook\\n\\nChange control steps for NW-FW-01.	draft	f	00000000-0000-4000-8000-000000000022	00000000-0000-4000-8000-000000000022	2026-09-03 03:27:13.553703+00	2026-09-03 03:27:13.553703+00
00000000-0000-4000-8000-000000000186	00000000-0000-4000-8000-000000000001	00000000-0000-4000-8000-000000000182	Old backup restore procedure	backup-restore-legacy	# Legacy\\n\\nSuperseded by the new restore runbook.	archived	f	00000000-0000-4000-8000-000000000021	00000000-0000-4000-8000-000000000021	2026-09-03 03:27:13.553703+00	2026-09-03 03:27:13.553703+00
\.


--
-- Data for Name: kb_categories; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.kb_categories (id, org_id, name, slug, description, "position", client_visible, created_at, updated_at) FROM stdin;
00000000-0000-4000-8000-000000000181	00000000-0000-4000-8000-000000000001	Onboarding	onboarding	New client setup guides	0	t	2026-09-03 03:27:13.553703+00	2026-09-03 03:27:13.553703+00
00000000-0000-4000-8000-000000000182	00000000-0000-4000-8000-000000000001	Runbooks	runbooks	Internal operational runbooks	1	f	2026-09-03 03:27:13.553703+00	2026-09-03 03:27:13.553703+00
\.


--
-- Data for Name: mcp_capability_grants; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.mcp_capability_grants (id, org_id, capability, mode, granted_by, created_at, updated_at) FROM stdin;
00000000-0000-4000-8000-000000000421	00000000-0000-4000-8000-000000000001	tickets:read	proposed	00000000-0000-4000-8000-000000000021	2026-09-03 03:27:13.553703+00	2026-09-03 03:27:13.553703+00
00000000-0000-4000-8000-000000000422	00000000-0000-4000-8000-000000000001	tickets:write	autonomous	00000000-0000-4000-8000-000000000021	2026-09-03 03:27:13.553703+00	2026-09-03 03:27:13.553703+00
\.


--
-- Data for Name: mfa_challenges; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.mfa_challenges (id, org_id, user_id, kind, state, expires_at, created_at) FROM stdin;
\.


--
-- Data for Name: migration_push_chunks; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.migration_push_chunks (id, org_id, session_id, chunk_index, fingerprint, summary, created_at) FROM stdin;
\.


--
-- Data for Name: migration_push_sessions; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.migration_push_sessions (id, org_id, batch_id, label, source_note, created_by, created_by_kind, created_at, finished_at) FROM stdin;
\.


--
-- Data for Name: notification_org_defaults; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.notification_org_defaults (org_id, kind, in_app, email, quiet_from, quiet_until, timezone) FROM stdin;
00000000-0000-4000-8000-000000000001	mention	t	f	\N	\N	UTC
00000000-0000-4000-8000-000000000001	sla_breach	t	t	22:00	07:00	America/New_York
\.


--
-- Data for Name: notification_preferences; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.notification_preferences (user_id, kind, in_app, email, quiet_from, quiet_until, timezone) FROM stdin;
00000000-0000-4000-8000-000000000021	assignment	t	t	21:00	07:00	America/New_York
00000000-0000-4000-8000-000000000023	mention	t	f	\N	\N	America/Chicago
\.


--
-- Data for Name: notifications; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.notifications (id, org_id, user_id, kind, ticket_id, title, body, read_at, created_at) FROM stdin;
00000000-0000-4000-8000-000000000341	00000000-0000-4000-8000-000000000001	00000000-0000-4000-8000-000000000022	sla_risk	00000000-0000-4000-8000-000000000301	P1 at risk	ACM-1001 consumed 75% of response budget	\N	2026-09-03 03:27:13.553703+00
00000000-0000-4000-8000-000000000342	00000000-0000-4000-8000-000000000001	00000000-0000-4000-8000-000000000023	assignment	00000000-0000-4000-8000-000000000301	Assigned to you	ACM-1001 auto-assigned by P1 pager rule	2026-09-01 13:05:00+00	2026-09-03 03:27:13.553703+00
\.


--
-- Data for Name: oidc_accounts; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.oidc_accounts (id, org_id, provider_id, user_id, subject, email, linked_by, linked_at, last_login_at) FROM stdin;
00000000-0000-4000-8000-000000000032	00000000-0000-4000-8000-000000000001	00000000-0000-4000-8000-000000000031	00000000-0000-4000-8000-000000000024	priya.natarajan@jumpcloud	priya@acme-it.example	00000000-0000-4000-8000-000000000021	2026-06-15 14:00:00+00	2026-09-01 09:12:00+00
\.


--
-- Data for Name: oidc_providers; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.oidc_providers (id, org_id, name, display_name, issuer, discovery_url, client_id, client_secret_enc, jit_provisioning, enabled, created_by, created_at, updated_at) FROM stdin;
00000000-0000-4000-8000-000000000031	00000000-0000-4000-8000-000000000001	jumpcloud	JumpCloud SSO	https://oauth.jumpcloud.com/	https://oauth.jumpcloud.com/.well-known/openid-configuration	acme-meridian-sp	\\x9faf5d0c1b2e4a6780c3d5e7f1902a4b6c8d0e2f4a6b8c0d2e4f6a8b0c2d4e6f	t	t	00000000-0000-4000-8000-000000000021	2026-09-03 03:27:13.553703+00	2026-09-03 03:27:13.553703+00
\.


--
-- Data for Name: on_call_blocks; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.on_call_blocks (id, org_id, user_id, starts_at, ends_at, category, notes, created_at) FROM stdin;
00000000-0000-4000-8000-000000000398	00000000-0000-4000-8000-000000000001	00000000-0000-4000-8000-000000000022	2026-09-05 00:00:00+00	2026-09-12 00:00:00+00	primary	Week 37 rotation	2026-09-03 03:27:13.553703+00
\.


--
-- Data for Name: orgs; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.orgs (id, name, slug, ticket_prefix, ticket_sequence, created_at, eod_nudges_enabled, eod_nudge_hour, time_gap_min_minutes, invoice_sequence) FROM stdin;
00000000-0000-4000-8000-000000000001	Acme IT Services	acme-it	ACM	1009	2026-09-03 03:27:13.553703+00	t	18	60	2
\.


--
-- Data for Name: outbox_events; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.outbox_events (id, org_id, event_type, entity, entity_id, payload, payload_schema_ref, occurred_at, published_at) FROM stdin;
00000000-0000-4000-8000-000000000451	00000000-0000-4000-8000-000000000001	ticket.created	ticket	00000000-0000-4000-8000-000000000301	{"ticket": {"title": "Firewall flapping on NW-FW-01", "number": "ACM-1001", "priority": "p1"}}	core-domain/v1	2026-09-03 03:27:13.553703+00	2026-09-01 09:00:10+00
00000000-0000-4000-8000-000000000452	00000000-0000-4000-8000-000000000001	ticket.status_changed	ticket	00000000-0000-4000-8000-000000000301	{"to": "in_progress", "from": "open"}	core-domain/v1	2026-09-03 03:27:13.553703+00	\N
00000000-0000-4000-8000-000000000453	00000000-0000-4000-8000-000000000001	invoice.issued	invoice	00000000-0000-4000-8000-000000000362	{"number": "ACM-INV-0001", "total_minor": 165000}	core-domain/v1	2026-09-03 03:27:13.553703+00	2026-09-01 09:00:20+00
\.


--
-- Data for Name: portal_appointment_requests; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.portal_appointment_requests (id, org_id, client_id, portal_user_id, user_id, title, starts_at, ends_at, kind, notes, status, decision_note, decided_by, decided_at, appointment_id, created_at, updated_at) FROM stdin;
00000000-0000-4000-8000-000000000400	00000000-0000-4000-8000-000000000001	00000000-0000-4000-8000-000000000051	00000000-0000-4000-8000-000000000391	00000000-0000-4000-8000-000000000023	Quarterly review call	2026-09-18 15:00:00+00	2026-09-18 16:00:00+00	remote	Agenda to follow	pending	\N	\N	\N	\N	2026-09-03 03:27:13.553703+00	2026-09-03 03:27:13.553703+00
00000000-0000-4000-8000-000000000401	00000000-0000-4000-8000-000000000001	00000000-0000-4000-8000-000000000051	00000000-0000-4000-8000-000000000391	00000000-0000-4000-8000-000000000023	Firewall walkthrough	2026-09-09 16:00:00+00	2026-09-09 17:00:00+00	remote	\N	approved	Approved — invites sent	00000000-0000-4000-8000-000000000021	2026-09-01 14:00:00+00	\N	2026-09-03 03:27:13.553703+00	2026-09-03 03:27:13.553703+00
\.


--
-- Data for Name: portal_sessions; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.portal_sessions (id, org_id, portal_user_id, refresh_token_hash, user_agent, expires_at, created_at, revoked_at) FROM stdin;
00000000-0000-4000-8000-000000000393	00000000-0000-4000-8000-000000000001	00000000-0000-4000-8000-000000000391	sha256$fixtureseed$portalsession01	Mozilla/5.0 fixture	2026-09-30 00:00:00+00	2026-09-03 03:27:13.553703+00	\N
\.


--
-- Data for Name: portal_users; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.portal_users (id, org_id, client_id, email, display_name, password_hash, role, status, created_at, updated_at) FROM stdin;
00000000-0000-4000-8000-000000000391	00000000-0000-4000-8000-000000000001	00000000-0000-4000-8000-000000000051	lena.fischer@northwind.example	Lena Fischer	$argon2id$v=19$m=19456,t=2,p=1$fixtureseed$fixturehashplena	contact	active	2026-09-03 03:27:13.553703+00	2026-09-03 03:27:13.553703+00
00000000-0000-4000-8000-000000000392	00000000-0000-4000-8000-000000000001	00000000-0000-4000-8000-000000000051	cfo@northwind.example	Nora Chen	$argon2id$v=19$m=19456,t=2,p=1$fixtureseed$fixturehashpnora	it_manager	active	2026-09-03 03:27:13.553703+00	2026-09-03 03:27:13.553703+00
\.


--
-- Data for Name: project_phases; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.project_phases (id, org_id, project_id, name, description, sort_order, status, is_milestone, milestone_amount_minor, milestone_currency, completed_at, created_at, updated_at) FROM stdin;
00000000-0000-4000-8000-000000000213	00000000-0000-4000-8000-000000000001	00000000-0000-4000-8000-000000000211	Assessment	Discovery + licensing	0	completed	f	\N	\N	\N	2026-09-03 03:27:13.553703+00	2026-09-03 03:27:13.553703+00
00000000-0000-4000-8000-000000000214	00000000-0000-4000-8000-000000000001	00000000-0000-4000-8000-000000000211	Migration waves	Mailbox + file waves	1	active	f	\N	\N	\N	2026-09-03 03:27:13.553703+00	2026-09-03 03:27:13.553703+00
00000000-0000-4000-8000-000000000215	00000000-0000-4000-8000-000000000001	00000000-0000-4000-8000-000000000212	SOC go-live	Cutover milestone	0	pending	t	500000	USD	\N	2026-09-03 03:27:13.553703+00	2026-09-03 03:27:13.553703+00
\.


--
-- Data for Name: project_task_deps; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.project_task_deps (org_id, task_id, depends_on_task_id, created_at) FROM stdin;
00000000-0000-4000-8000-000000000001	00000000-0000-4000-8000-000000000218	00000000-0000-4000-8000-000000000217	2026-09-03 03:27:13.553703+00
\.


--
-- Data for Name: project_tasks; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.project_tasks (id, org_id, project_id, phase_id, title, description, status, assignee_id, sort_order, is_milestone, milestone_amount_minor, milestone_currency, due_at, completed_at, created_at, updated_at) FROM stdin;
00000000-0000-4000-8000-000000000216	00000000-0000-4000-8000-000000000001	00000000-0000-4000-8000-000000000211	00000000-0000-4000-8000-000000000213	License inventory	Count + reconcile	completed	00000000-0000-4000-8000-000000000024	0	f	\N	\N	2026-07-15 00:00:00+00	2026-07-12 00:00:00+00	2026-09-03 03:27:13.553703+00	2026-09-03 03:27:13.553703+00
00000000-0000-4000-8000-000000000217	00000000-0000-4000-8000-000000000001	00000000-0000-4000-8000-000000000211	00000000-0000-4000-8000-000000000214	Wave 1 — IT pilots	20 pilot mailboxes	in_progress	00000000-0000-4000-8000-000000000023	1	f	\N	\N	2026-09-15 00:00:00+00	\N	2026-09-03 03:27:13.553703+00	2026-09-03 03:27:13.553703+00
00000000-0000-4000-8000-000000000218	00000000-0000-4000-8000-000000000001	00000000-0000-4000-8000-000000000211	00000000-0000-4000-8000-000000000214	Wave 2 — Sales org	Bulk move	pending	00000000-0000-4000-8000-000000000023	2	f	\N	\N	2026-10-15 00:00:00+00	\N	2026-09-03 03:27:13.553703+00	2026-09-03 03:27:13.553703+00
00000000-0000-4000-8000-000000000219	00000000-0000-4000-8000-000000000001	00000000-0000-4000-8000-000000000212	\N	Vendor selection	SOC platform RFP	blocked	00000000-0000-4000-8000-000000000021	0	f	\N	\N	\N	\N	2026-09-03 03:27:13.553703+00	2026-09-03 03:27:13.553703+00
\.


--
-- Data for Name: project_templates; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.project_templates (id, org_id, name, description, spec, created_at, updated_at) FROM stdin;
00000000-0000-4000-8000-000000000221	00000000-0000-4000-8000-000000000001	Client onboarding	Standard onboarding plan	{"phases": [{"name": "Discovery", "tasks": ["Kickoff", "Access audit"]}, {"name": "Cutover", "tasks": ["Go/no-go", "Cutover"]}]}	2026-09-03 03:27:13.553703+00	2026-09-03 03:27:13.553703+00
\.


--
-- Data for Name: project_views; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.project_views (id, org_id, project_id, name, spec, is_default, created_at, updated_at) FROM stdin;
00000000-0000-4000-8000-000000000220	00000000-0000-4000-8000-000000000001	\N	All active projects	{"status": ["active", "planning"]}	t	2026-09-03 03:27:13.553703+00	2026-09-03 03:27:13.553703+00
\.


--
-- Data for Name: projects; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.projects (id, org_id, client_id, name, description, status, billing_method, budget_minor, currency, start_date, due_date, created_at, updated_at) FROM stdin;
00000000-0000-4000-8000-000000000211	00000000-0000-4000-8000-000000000001	00000000-0000-4000-8000-000000000051	Northwind M365 migration	Tenant-to-tenant migration	active	time_and_materials	800000	USD	2026-07-01	2026-11-30	2026-09-03 03:27:13.553703+00	2026-09-03 03:27:13.553703+00
00000000-0000-4000-8000-000000000212	00000000-0000-4000-8000-000000000001	00000000-0000-4000-8000-000000000052	Contoso SOC rollout	Security operations rollout	planning	milestone	1500000	USD	2026-10-01	\N	2026-09-03 03:27:13.553703+00	2026-09-03 03:27:13.553703+00
\.


--
-- Data for Name: provenance_events; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.provenance_events (write_id, field_seq, org_id, entity, entity_id, seq, op, actor_kind, actor_id, field, before, after, session_id, skill, ruleset_hash, is_undo, idempotency_key, occurred_at) FROM stdin;
00000000-0000-4000-8000-000000000431	1	00000000-0000-4000-8000-000000000001	ticket	00000000-0000-4000-8000-000000000301	1	update	human	00000000-0000-4000-8000-000000000023	status	"open"	"in_progress"	\N	\N	\N	f	\N	2026-09-03 03:27:13.553703+00
00000000-0000-4000-8000-000000000432	1	00000000-0000-4000-8000-000000000001	ticket	00000000-0000-4000-8000-000000000301	2	update	agent	00000000-0000-4000-8000-000000000022	priority	"p2"	"p1"	00000000-0000-4000-8000-000000000434	ticket-triage	rules-2026-08	f	\N	2026-09-03 03:27:13.553703+00
\.


--
-- Data for Name: recovery_codes; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.recovery_codes (id, org_id, user_id, code_hash, used_at, created_at) FROM stdin;
00000000-0000-4000-8000-000000000034	00000000-0000-4000-8000-000000000001	00000000-0000-4000-8000-000000000022	sha256$fixtureseed$recocodeseed01	\N	2026-09-03 03:27:13.553703+00
00000000-0000-4000-8000-000000000035	00000000-0000-4000-8000-000000000001	00000000-0000-4000-8000-000000000022	sha256$fixtureseed$recocodeseed02	2026-08-14 16:40:00+00	2026-09-03 03:27:13.553703+00
\.


--
-- Data for Name: report_definitions; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.report_definitions (id, org_id, name, description, kind, spec, viz, scope, created_by, created_at, updated_at) FROM stdin;
00000000-0000-4000-8000-000000000171	00000000-0000-4000-8000-000000000001	Tickets by priority	Open + closed ticket volume per priority	tickets	{"filters": {"board_id": "00000000-0000-4000-8000-000000000081"}, "group_by": "priority", "measures": ["count"]}	bar	org	00000000-0000-4000-8000-000000000021	2026-09-03 03:27:13.553703+00	2026-09-03 03:27:13.553703+00
00000000-0000-4000-8000-000000000172	00000000-0000-4000-8000-000000000001	Billable hours per week	Billable minutes trend	time_entries	{"filters": {"billable": true}, "group_by": "week", "measures": ["minutes"]}	line	org	00000000-0000-4000-8000-000000000021	2026-09-03 03:27:13.553703+00	2026-09-03 03:27:13.553703+00
00000000-0000-4000-8000-000000000173	00000000-0000-4000-8000-000000000001	SLA outcomes detail	Per-ticket SLA outcome table	sla_outcomes	{"filters": {"breached": true}, "group_by": "ticket", "measures": ["count"]}	table	self	00000000-0000-4000-8000-000000000022	2026-09-03 03:27:13.553703+00	2026-09-03 03:27:13.553703+00
\.


--
-- Data for Name: report_deliveries; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.report_deliveries (id, org_id, schedule_id, slot_at, status, detail, created_at) FROM stdin;
00000000-0000-4000-8000-000000000175	00000000-0000-4000-8000-000000000001	00000000-0000-4000-8000-000000000174	2026-08-31 12:00:00+00	delivered	{"format": "csv", "recipients": 2}	2026-09-03 03:27:13.553703+00
\.


--
-- Data for Name: report_schedules; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.report_schedules (id, org_id, report_definition_id, name, recipients, cadence, time_of_day, day_of_week, day_of_month, timezone, window_days, enabled, next_run_at, last_run_at, last_error, created_by, created_at, updated_at) FROM stdin;
00000000-0000-4000-8000-000000000174	00000000-0000-4000-8000-000000000001	00000000-0000-4000-8000-000000000171	Weekly ticket digest	{00000000-0000-4000-8000-000000000021,00000000-0000-4000-8000-000000000022}	weekly	08:00:00	1	\N	America/New_York	7	t	2026-09-07 12:00:00+00	\N	\N	00000000-0000-4000-8000-000000000021	2026-09-03 03:27:13.553703+00	2026-09-03 03:27:13.553703+00
\.


--
-- Data for Name: roles; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.roles (id, org_id, name, builtin, permissions, is_system) FROM stdin;
00000000-0000-4000-8000-000000000011	00000000-0000-4000-8000-000000000001	Administrator	admin	["*"]	t
00000000-0000-4000-8000-000000000012	00000000-0000-4000-8000-000000000001	Member	member	["tickets:read", "tickets:write", "clients:read"]	t
00000000-0000-4000-8000-000000000013	00000000-0000-4000-8000-000000000001	Dispatcher	\N	["tickets:read", "tickets:write", "dispatch:write"]	f
\.


--
-- Data for Name: search_index; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.search_index (id, org_id, entity_kind, entity_id, parent_id, title, body, indexed_at) FROM stdin;
00000000-0000-4000-8000-000000000471	00000000-0000-4000-8000-000000000001	ticket	00000000-0000-4000-8000-000000000301	\N	Firewall flapping on NW-FW-01	Intermittent WAN drops since firmware update.	2026-09-01 09:00:00+00
00000000-0000-4000-8000-000000000472	00000000-0000-4000-8000-000000000001	kb_article	00000000-0000-4000-8000-000000000183	\N	Welcome to the portal	How to raise your first request.	2026-09-01 09:00:00+00
00000000-0000-4000-8000-000000000473	00000000-0000-4000-8000-000000000001	client	00000000-0000-4000-8000-000000000051	\N	Northwind Traders	Flagship MSP account	2026-09-01 09:00:00+00
\.


--
-- Data for Name: settings; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.settings (id, org_id, scope, key, owner_id, value, updated_by, updated_at) FROM stdin;
00000000-0000-4000-8000-000000000141	00000000-0000-4000-8000-000000000001	org	org.display_name	00000000-0000-4000-8000-000000000001	"Acme IT Services"	00000000-0000-4000-8000-000000000021	2026-09-03 03:27:13.553703+00
00000000-0000-4000-8000-000000000142	00000000-0000-4000-8000-000000000001	org	org.default_timezone	00000000-0000-4000-8000-000000000001	"America/New_York"	00000000-0000-4000-8000-000000000021	2026-09-03 03:27:13.553703+00
00000000-0000-4000-8000-000000000143	00000000-0000-4000-8000-000000000001	org	portal.enabled	00000000-0000-4000-8000-000000000001	true	00000000-0000-4000-8000-000000000021	2026-09-03 03:27:13.553703+00
00000000-0000-4000-8000-000000000144	00000000-0000-4000-8000-000000000001	org	sla.default_calendar_hours	00000000-0000-4000-8000-000000000001	8	00000000-0000-4000-8000-000000000022	2026-09-03 03:27:13.553703+00
00000000-0000-4000-8000-000000000145	00000000-0000-4000-8000-000000000001	user	ui.theme	00000000-0000-4000-8000-000000000021	"dark"	00000000-0000-4000-8000-000000000021	2026-09-03 03:27:13.553703+00
00000000-0000-4000-8000-000000000146	00000000-0000-4000-8000-000000000001	user	ui.density	00000000-0000-4000-8000-000000000023	"comfortable"	00000000-0000-4000-8000-000000000023	2026-09-03 03:27:13.553703+00
\.


--
-- Data for Name: sites; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.sites (id, org_id, client_id, name, address, city, region, postal_code, country, latitude, longitude, timezone, created_at) FROM stdin;
00000000-0000-4000-8000-000000000054	00000000-0000-4000-8000-000000000001	00000000-0000-4000-8000-000000000051	Northwind HQ	500 Harbor Blvd	Seattle	WA	98104	US	\N	\N	America/Los_Angeles	2026-09-03 03:27:13.553703+00
00000000-0000-4000-8000-000000000055	00000000-0000-4000-8000-000000000001	00000000-0000-4000-8000-000000000052	Contoso Plant 1	12 Foundry Rd	Detroit	MI	48201	US	\N	\N	America/Detroit	2026-09-03 03:27:13.553703+00
\.


--
-- Data for Name: sla_calendars; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.sla_calendars (id, org_id, name, timezone, windows, holidays, maintenance, created_at, updated_at) FROM stdin;
00000000-0000-4000-8000-000000000151	00000000-0000-4000-8000-000000000001	Business Hours ET	America/New_York	[["09:00", "17:00"], ["09:00", "17:00"], ["09:00", "17:00"], ["09:00", "17:00"], ["09:00", "17:00"], null, null]	["2026-11-26", "2026-11-27", "2026-12-25"]	[{"name": "ISP maintenance window", "ends_at": "2026-09-12T10:00:00Z", "starts_at": "2026-09-12T06:00:00Z"}]	2026-09-03 03:27:13.553703+00	2026-09-03 03:27:13.553703+00
00000000-0000-4000-8000-000000000152	00000000-0000-4000-8000-000000000001	Follow-the-Sun 24x7	UTC	[["00:00", "23:59"], ["00:00", "23:59"], ["00:00", "23:59"], ["00:00", "23:59"], ["00:00", "23:59"], ["00:00", "23:59"], ["00:00", "23:59"]]	[]	[]	2026-09-03 03:27:13.553703+00	2026-09-03 03:27:13.553703+00
\.


--
-- Data for Name: sla_escalation_steps; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.sla_escalation_steps (id, org_id, policy_id, step_index, trigger_kind, at_pct, notify_user_ids, enabled) FROM stdin;
00000000-0000-4000-8000-000000000163	00000000-0000-4000-8000-000000000001	00000000-0000-4000-8000-000000000161	0	risk	75	["00000000-0000-4000-8000-000000000022"]	t
00000000-0000-4000-8000-000000000164	00000000-0000-4000-8000-000000000001	00000000-0000-4000-8000-000000000161	1	breach	100	["00000000-0000-4000-8000-000000000021", "00000000-0000-4000-8000-000000000022"]	t
00000000-0000-4000-8000-000000000165	00000000-0000-4000-8000-000000000001	00000000-0000-4000-8000-000000000161	2	escalate	150	["00000000-0000-4000-8000-000000000021"]	t
00000000-0000-4000-8000-000000000166	00000000-0000-4000-8000-000000000001	00000000-0000-4000-8000-000000000162	0	breach	100	["00000000-0000-4000-8000-000000000022"]	t
\.


--
-- Data for Name: sla_fired_escalations; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.sla_fired_escalations (org_id, ticket_id, step_id, target, fired_at) FROM stdin;
00000000-0000-4000-8000-000000000001	00000000-0000-4000-8000-000000000301	00000000-0000-4000-8000-000000000166	first_response	2026-09-01 09:29:00+00
\.


--
-- Data for Name: sla_policies; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.sla_policies (id, org_id, name, is_default, targets, calendar, created_at, calendar_id) FROM stdin;
00000000-0000-4000-8000-000000000161	00000000-0000-4000-8000-000000000001	Standard Response	t	{"p1": {"resolve_minutes": 480, "first_response_minutes": 15}, "p2": {"resolve_minutes": 1440, "first_response_minutes": 60}, "p3": {"resolve_minutes": 4320, "first_response_minutes": 240}, "p4": {"resolve_minutes": 10080, "first_response_minutes": 480}}	{"name": "Standard Response fallback", "windows": [["09:00", "17:00"], ["09:00", "17:00"], ["09:00", "17:00"], ["09:00", "17:00"], ["09:00", "17:00"], null, null], "holidays": [], "timezone": "America/New_York", "maintenance": []}	2026-09-03 03:27:13.553703+00	00000000-0000-4000-8000-000000000151
00000000-0000-4000-8000-000000000162	00000000-0000-4000-8000-000000000001	Critical Systems 24x7	f	{"p1": {"resolve_minutes": 240, "first_response_minutes": 10}, "p2": {"resolve_minutes": 480, "first_response_minutes": 30}}	{"name": "Critical Systems fallback", "windows": [["00:00", "23:59"], ["00:00", "23:59"], ["00:00", "23:59"], ["00:00", "23:59"], ["00:00", "23:59"], ["00:00", "23:59"], ["00:00", "23:59"]], "holidays": [], "timezone": "UTC", "maintenance": []}	2026-09-03 03:27:13.553703+00	00000000-0000-4000-8000-000000000152
\.


--
-- Data for Name: ticket_comments; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.ticket_comments (id, org_id, ticket_id, author_id, kind, body, created_at, updated_at) FROM stdin;
00000000-0000-4000-8000-000000000311	00000000-0000-4000-8000-000000000001	00000000-0000-4000-8000-000000000301	00000000-0000-4000-8000-000000000023	internal	Firmware rollback scheduled tonight.	2026-09-03 03:27:13.553703+00	\N
00000000-0000-4000-8000-000000000312	00000000-0000-4000-8000-000000000001	00000000-0000-4000-8000-000000000301	00000000-0000-4000-8000-000000000021	client_visible	Acknowledged — please keep us posted.	2026-09-03 03:27:13.553703+00	\N
00000000-0000-4000-8000-000000000313	00000000-0000-4000-8000-000000000001	00000000-0000-4000-8000-000000000302	00000000-0000-4000-8000-000000000024	in_house_update	Reset completed and verified.	2026-09-03 03:27:13.553703+00	\N
00000000-0000-4000-8000-000000000314	00000000-0000-4000-8000-000000000001	00000000-0000-4000-8000-000000000303	00000000-0000-4000-8000-000000000021	internal	Following up with Lena on Thursday.	2026-09-03 03:27:13.553703+00	\N
\.


--
-- Data for Name: ticket_required_skills; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.ticket_required_skills (id, org_id, ticket_id, skill, created_at) FROM stdin;
\.


--
-- Data for Name: ticket_sla_state; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.ticket_sla_state (ticket_id, org_id, policy_id, first_response_due, resolution_due, first_responded_at, paused_business_secs, paused_since, breached, updated_at) FROM stdin;
00000000-0000-4000-8000-000000000301	00000000-0000-4000-8000-000000000001	00000000-0000-4000-8000-000000000162	2026-09-01 09:30:00+00	2026-09-02 09:30:00+00	2026-09-01 09:05:00+00	0	\N	f	2026-09-03 03:27:13.553703+00
00000000-0000-4000-8000-000000000305	00000000-0000-4000-8000-000000000001	00000000-0000-4000-8000-000000000161	2026-09-03 13:00:00+00	2026-09-04 13:00:00+00	\N	1800	\N	f	2026-09-03 03:27:13.553703+00
\.


--
-- Data for Name: tickets; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.tickets (id, org_id, number, board_id, status_id, title, body, priority, client_id, site_id, contact_id, assignee_id, requester_id, category, due_at, resolved_at, created_at, updated_at) FROM stdin;
00000000-0000-4000-8000-000000000301	00000000-0000-4000-8000-000000000001	ACM-1001	00000000-0000-4000-8000-000000000081	00000000-0000-4000-8000-000000000092	Firewall flapping on NW-FW-01	Intermittent WAN drops since firmware update.	p1	00000000-0000-4000-8000-000000000051	00000000-0000-4000-8000-000000000054	00000000-0000-4000-8000-000000000057	00000000-0000-4000-8000-000000000023	00000000-0000-4000-8000-000000000021	in_progress	2026-09-02 18:00:00+00	\N	2026-09-03 03:27:13.553703+00	2026-09-03 03:27:13.553703+00
00000000-0000-4000-8000-000000000302	00000000-0000-4000-8000-000000000001	ACM-1002	00000000-0000-4000-8000-000000000081	00000000-0000-4000-8000-000000000094	Password reset — Marco Ruiz	\N	p3	00000000-0000-4000-8000-000000000052	00000000-0000-4000-8000-000000000055	00000000-0000-4000-8000-000000000058	00000000-0000-4000-8000-000000000024	00000000-0000-4000-8000-000000000021	closed	\N	2026-08-28 15:00:00+00	2026-09-03 03:27:13.553703+00	2026-09-03 03:27:13.553703+00
00000000-0000-4000-8000-000000000303	00000000-0000-4000-8000-000000000001	ACM-1003	00000000-0000-4000-8000-000000000081	00000000-0000-4000-8000-000000000093	Quote for laptop refresh	Awaiting client confirmation on spec.	p3	00000000-0000-4000-8000-000000000051	00000000-0000-4000-8000-000000000054	00000000-0000-4000-8000-000000000057	\N	00000000-0000-4000-8000-000000000021	waiting	\N	\N	2026-09-03 03:27:13.553703+00	2026-09-03 03:27:13.553703+00
00000000-0000-4000-8000-000000000304	00000000-0000-4000-8000-000000000001	ACM-1004	00000000-0000-4000-8000-000000000081	00000000-0000-4000-8000-000000000095	On-site: printer maintenance visit	Scheduled preventive maintenance.	p4	00000000-0000-4000-8000-000000000051	00000000-0000-4000-8000-000000000054	00000000-0000-4000-8000-000000000057	00000000-0000-4000-8000-000000000023	00000000-0000-4000-8000-000000000021	waiting	\N	\N	2026-09-03 03:27:13.553703+00	2026-09-03 03:27:13.553703+00
00000000-0000-4000-8000-000000000305	00000000-0000-4000-8000-000000000001	ACM-1005	00000000-0000-4000-8000-000000000081	00000000-0000-4000-8000-000000000091	New hire onboarding — 5 accounts	\N	p2	00000000-0000-4000-8000-000000000051	00000000-0000-4000-8000-000000000054	00000000-0000-4000-8000-000000000057	\N	00000000-0000-4000-8000-000000000021	open	\N	\N	2026-09-03 03:27:13.553703+00	2026-09-03 03:27:13.553703+00
00000000-0000-4000-8000-000000000306	00000000-0000-4000-8000-000000000001	ACM-1006	00000000-0000-4000-8000-000000000081	00000000-0000-4000-8000-000000000094	VPN tunnel drops nightly	Ruled out ISP; monitored.	p2	00000000-0000-4000-8000-000000000052	00000000-0000-4000-8000-000000000055	00000000-0000-4000-8000-000000000058	00000000-0000-4000-8000-000000000024	00000000-0000-4000-8000-000000000021	closed	\N	2026-08-20 22:00:00+00	2026-09-03 03:27:13.553703+00	2026-09-03 03:27:13.553703+00
00000000-0000-4000-8000-000000000307	00000000-0000-4000-8000-000000000001	ACM-1007	00000000-0000-4000-8000-000000000082	00000000-0000-4000-8000-000000000096	Migration intake — scope review	Intake from projects board.	p3	00000000-0000-4000-8000-000000000051	\N	\N	00000000-0000-4000-8000-000000000024	00000000-0000-4000-8000-000000000021	open	\N	\N	2026-09-03 03:27:13.553703+00	2026-09-03 03:27:13.553703+00
00000000-0000-4000-8000-000000000308	00000000-0000-4000-8000-000000000001	ACM-1008	00000000-0000-4000-8000-000000000082	00000000-0000-4000-8000-000000000098	SOC rollout — vendor on hold	Blocked on RFP responses.	p3	00000000-0000-4000-8000-000000000052	\N	\N	00000000-0000-4000-8000-000000000021	00000000-0000-4000-8000-000000000021	waiting	\N	\N	2026-09-03 03:27:13.553703+00	2026-09-03 03:27:13.553703+00
\.


--
-- Data for Name: time_entries; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.time_entries (id, org_id, ticket_id, user_id, started_at, ended_at, minutes, billable, notes, work_type, timer_session_id, created_at) FROM stdin;
00000000-0000-4000-8000-000000000332	00000000-0000-4000-8000-000000000001	00000000-0000-4000-8000-000000000301	00000000-0000-4000-8000-000000000023	2026-09-01 13:00:00+00	2026-09-01 16:00:00+00	165	t	Firmware rollback + monitoring	remote	00000000-0000-4000-8000-000000000331	2026-09-03 03:27:13.553703+00
00000000-0000-4000-8000-000000000333	00000000-0000-4000-8000-000000000001	00000000-0000-4000-8000-000000000302	00000000-0000-4000-8000-000000000024	2026-08-28 14:30:00+00	2026-08-28 15:00:00+00	30	t	\N	remote	\N	2026-09-03 03:27:13.553703+00
00000000-0000-4000-8000-000000000334	00000000-0000-4000-8000-000000000001	00000000-0000-4000-8000-000000000306	00000000-0000-4000-8000-000000000024	2026-08-20 18:00:00+00	2026-08-20 22:00:00+00	240	t	Nightly tunnel watch	remote	\N	2026-09-03 03:27:13.553703+00
00000000-0000-4000-8000-000000000335	00000000-0000-4000-8000-000000000001	00000000-0000-4000-8000-000000000303	00000000-0000-4000-8000-000000000021	2026-08-25 10:00:00+00	2026-08-25 10:45:00+00	45	f	Internal quote prep	\N	\N	2026-09-03 03:27:13.553703+00
\.


--
-- Data for Name: time_gap_audits; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.time_gap_audits (id, org_id, user_id, day, activity, logged_minutes, expected_minutes, has_gap, nudge_sent_at, created_at, updated_at) FROM stdin;
00000000-0000-4000-8000-000000000336	00000000-0000-4000-8000-000000000001	00000000-0000-4000-8000-000000000023	2026-08-29	t	300	480	t	2026-08-29 22:00:00+00	2026-09-03 03:27:13.553703+00	2026-09-03 03:27:13.553703+00
\.


--
-- Data for Name: timer_sessions; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.timer_sessions (id, org_id, user_id, ticket_id, started_at, stopped_at, segments) FROM stdin;
00000000-0000-4000-8000-000000000331	00000000-0000-4000-8000-000000000001	00000000-0000-4000-8000-000000000023	00000000-0000-4000-8000-000000000301	2026-09-01 13:00:00+00	2026-09-01 16:00:00+00	[{"ended_at": "2026-09-01T14:30:00Z", "started_at": "2026-09-01T13:00:00Z"}, {"ended_at": "2026-09-01T16:00:00Z", "started_at": "2026-09-01T14:45:00Z"}]
\.


--
-- Data for Name: totp_secrets; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.totp_secrets (id, org_id, user_id, secret_enc, confirmed, last_used_step, created_at, updated_at) FROM stdin;
00000000-0000-4000-8000-000000000033	00000000-0000-4000-8000-000000000001	00000000-0000-4000-8000-000000000022	\\x5d1f0a3c8e2b476d9a0c5e8f1b4a7d0c	t	42100000	2026-09-03 03:27:13.553703+00	2026-09-03 03:27:13.553703+00
\.


--
-- Data for Name: travel_entry_drafts; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.travel_entry_drafts (id, org_id, user_id, ticket_id, started_at, ended_at, distance, distance_unit, vehicle, billable, notes, status, submitted_time_entry_id, created_by, created_at, updated_at) FROM stdin;
00000000-0000-4000-8000-000000000491	00000000-0000-4000-8000-000000000001	00000000-0000-4000-8000-000000000023	00000000-0000-4000-8000-000000000304	2026-09-10 16:15:00+00	2026-09-10 17:00:00+00	22.5	mi	Van 2	t	Plant visit outbound leg	draft	\N	00000000-0000-4000-8000-000000000023	2026-09-03 03:27:13.553703+00	2026-09-03 03:27:13.553703+00
\.


--
-- Data for Name: user_roles; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.user_roles (user_id, role_id) FROM stdin;
00000000-0000-4000-8000-000000000021	00000000-0000-4000-8000-000000000011
00000000-0000-4000-8000-000000000022	00000000-0000-4000-8000-000000000011
00000000-0000-4000-8000-000000000023	00000000-0000-4000-8000-000000000012
00000000-0000-4000-8000-000000000024	00000000-0000-4000-8000-000000000013
\.


--
-- Data for Name: user_skills; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.user_skills (id, org_id, user_id, skill, expires_at, created_at, updated_at) FROM stdin;
00000000-0000-4000-8000-000000000425	00000000-0000-4000-8000-000000000001	00000000-0000-4000-8000-000000000024	networking	2027-06-30 00:00:00+00	2026-09-03 03:27:13.553703+00	2026-09-03 03:27:13.553703+00
\.


--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.users (id, org_id, email, display_name, password_hash, timezone, is_active, mfa_totp_secret, created_at, updated_at) FROM stdin;
00000000-0000-4000-8000-000000000021	00000000-0000-4000-8000-000000000001	dana@acme-it.example	Dana Reyes	$argon2id$v=19$m=19456,t=2,p=1$fixtureseed$fixturehashdana	America/New_York	t	\N	2026-09-03 03:27:13.553703+00	2026-09-03 03:27:13.553703+00
00000000-0000-4000-8000-000000000022	00000000-0000-4000-8000-000000000001	omar@acme-it.example	Omar Haddad	$argon2id$v=19$m=19456,t=2,p=1$fixtureseed$fixturehashomar	America/New_York	t	a2VsYWRlZmlyc3R1ZmZpeHRvdHBzZWNyZXQ=	2026-09-03 03:27:13.553703+00	2026-09-03 03:27:13.553703+00
00000000-0000-4000-8000-000000000023	00000000-0000-4000-8000-000000000001	sam@acme-it.example	Sam Okafor	$argon2id$v=19$m=19456,t=2,p=1$fixtureseed$fixturehashsam	America/Chicago	t	\N	2026-09-03 03:27:13.553703+00	2026-09-03 03:27:13.553703+00
00000000-0000-4000-8000-000000000024	00000000-0000-4000-8000-000000000001	priya@acme-it.example	Priya Natarajan	$argon2id$v=19$m=19456,t=2,p=1$fixtureseed$fixturehashpriya	UTC	t	\N	2026-09-03 03:27:13.553703+00	2026-09-03 03:27:13.553703+00
\.


--
-- Data for Name: webauthn_credentials; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.webauthn_credentials (id, org_id, user_id, cred_id, credential, label, created_at, last_used_at) FROM stdin;
\.


--
-- Data for Name: webhook_deliveries; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.webhook_deliveries (id, org_id, webhook_id, event_id, event_type, attempt, response_status, next_retry_at, delivered_at, last_error, created_at) FROM stdin;
00000000-0000-4000-8000-000000000465	00000000-0000-4000-8000-000000000001	00000000-0000-4000-8000-000000000131	00000000-0000-4000-8000-000000000451	ticket.created	1	200	\N	2026-09-01 09:00:12+00	\N	2026-09-03 03:27:13.553703+00
00000000-0000-4000-8000-000000000466	00000000-0000-4000-8000-000000000001	00000000-0000-4000-8000-000000000131	00000000-0000-4000-8000-000000000452	ticket.status_changed	2	\N	\N	\N	connect timeout	2026-09-03 03:27:13.553703+00
\.


--
-- Data for Name: webhooks; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.webhooks (id, org_id, url, secret_encrypted, event_types, enabled, created_by, created_at, updated_at) FROM stdin;
00000000-0000-4000-8000-000000000131	00000000-0000-4000-8000-000000000001	https://hooks.northwind.example/meridian/tickets	\\x3f8a1c2d5e7b90a1c3d5e7f90a1b3c5d7e9f0a2b4c6d8e0f2a4b6c8d0e2f4a6b	{ticket.created,ticket.status_changed}	t	00000000-0000-4000-8000-000000000021	2026-09-03 03:27:13.553703+00	2026-09-03 03:27:13.553703+00
00000000-0000-4000-8000-000000000132	00000000-0000-4000-8000-000000000001	https://ops.acme-it.example/webhooks/wildcard	\\x7b2d9f4e1a3c5b7d9f0e2a4c6b8d0f2a4c6e8b0d2f4a6c8e0b2d4f6a8c0e2b4d	{}	f	00000000-0000-4000-8000-000000000021	2026-09-03 03:27:13.553703+00	2026-09-03 03:27:13.553703+00
\.


--
-- Name: _sqlx_migrations _sqlx_migrations_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public._sqlx_migrations
    ADD CONSTRAINT _sqlx_migrations_pkey PRIMARY KEY (version);


--
-- Name: agent_proposals agent_proposals_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.agent_proposals
    ADD CONSTRAINT agent_proposals_pkey PRIMARY KEY (id);


--
-- Name: agent_skills agent_skills_org_id_slug_version_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.agent_skills
    ADD CONSTRAINT agent_skills_org_id_slug_version_key UNIQUE (org_id, slug, version);


--
-- Name: agent_skills agent_skills_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.agent_skills
    ADD CONSTRAINT agent_skills_pkey PRIMARY KEY (id);


--
-- Name: alert_incidents alert_incidents_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.alert_incidents
    ADD CONSTRAINT alert_incidents_pkey PRIMARY KEY (id);


--
-- Name: alert_sources alert_sources_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.alert_sources
    ADD CONSTRAINT alert_sources_pkey PRIMARY KEY (id);


--
-- Name: alerts alerts_org_id_source_id_dedup_key_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.alerts
    ADD CONSTRAINT alerts_org_id_source_id_dedup_key_key UNIQUE (org_id, source_id, dedup_key);


--
-- Name: alerts alerts_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.alerts
    ADD CONSTRAINT alerts_pkey PRIMARY KEY (id);


--
-- Name: api_keys api_keys_key_hash_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.api_keys
    ADD CONSTRAINT api_keys_key_hash_key UNIQUE (key_hash);


--
-- Name: api_keys api_keys_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.api_keys
    ADD CONSTRAINT api_keys_pkey PRIMARY KEY (id);


--
-- Name: appointments appointments_no_double_booking; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.appointments
    ADD CONSTRAINT appointments_no_double_booking EXCLUDE USING gist (user_id WITH =, tstzrange(starts_at, ends_at, '[)'::text) WITH &&) WHERE ((status <> 'cancelled'::public.appointment_status));


--
-- Name: appointments appointments_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.appointments
    ADD CONSTRAINT appointments_pkey PRIMARY KEY (id);


--
-- Name: attachments attachments_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.attachments
    ADD CONSTRAINT attachments_pkey PRIMARY KEY (id);


--
-- Name: audit_events audit_events_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.audit_events
    ADD CONSTRAINT audit_events_pkey PRIMARY KEY (id);


--
-- Name: auth_sessions auth_sessions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.auth_sessions
    ADD CONSTRAINT auth_sessions_pkey PRIMARY KEY (id);


--
-- Name: automation_rules automation_rules_org_id_name_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.automation_rules
    ADD CONSTRAINT automation_rules_org_id_name_key UNIQUE (org_id, name);


--
-- Name: automation_rules automation_rules_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.automation_rules
    ADD CONSTRAINT automation_rules_pkey PRIMARY KEY (id);


--
-- Name: availability_windows availability_windows_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.availability_windows
    ADD CONSTRAINT availability_windows_pkey PRIMARY KEY (id);


--
-- Name: board_checklist_templates board_checklist_templates_board_id_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.board_checklist_templates
    ADD CONSTRAINT board_checklist_templates_board_id_key UNIQUE (board_id);


--
-- Name: board_checklist_templates board_checklist_templates_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.board_checklist_templates
    ADD CONSTRAINT board_checklist_templates_pkey PRIMARY KEY (id);


--
-- Name: board_favorites board_favorites_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.board_favorites
    ADD CONSTRAINT board_favorites_pkey PRIMARY KEY (user_id, board_id);


--
-- Name: board_groups board_groups_org_id_name_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.board_groups
    ADD CONSTRAINT board_groups_org_id_name_key UNIQUE (org_id, name);


--
-- Name: board_groups board_groups_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.board_groups
    ADD CONSTRAINT board_groups_pkey PRIMARY KEY (id);


--
-- Name: board_members board_members_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.board_members
    ADD CONSTRAINT board_members_pkey PRIMARY KEY (user_id, board_id);


--
-- Name: board_portal_exposure board_portal_exposure_board_id_client_id_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.board_portal_exposure
    ADD CONSTRAINT board_portal_exposure_board_id_client_id_key UNIQUE (board_id, client_id);


--
-- Name: board_portal_exposure board_portal_exposure_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.board_portal_exposure
    ADD CONSTRAINT board_portal_exposure_pkey PRIMARY KEY (id);


--
-- Name: board_status_transitions board_status_transitions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.board_status_transitions
    ADD CONSTRAINT board_status_transitions_pkey PRIMARY KEY (from_status_id, to_status_id);


--
-- Name: board_statuses board_statuses_board_id_id_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.board_statuses
    ADD CONSTRAINT board_statuses_board_id_id_key UNIQUE (board_id, id);


--
-- Name: board_statuses board_statuses_board_id_name_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.board_statuses
    ADD CONSTRAINT board_statuses_board_id_name_key UNIQUE (board_id, name);


--
-- Name: board_statuses board_statuses_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.board_statuses
    ADD CONSTRAINT board_statuses_pkey PRIMARY KEY (id);


--
-- Name: boards boards_org_id_name_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.boards
    ADD CONSTRAINT boards_org_id_name_key UNIQUE (org_id, name);


--
-- Name: boards boards_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.boards
    ADD CONSTRAINT boards_pkey PRIMARY KEY (id);


--
-- Name: byok_secrets byok_secrets_org_id_provider_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.byok_secrets
    ADD CONSTRAINT byok_secrets_org_id_provider_key UNIQUE (org_id, provider);


--
-- Name: byok_secrets byok_secrets_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.byok_secrets
    ADD CONSTRAINT byok_secrets_pkey PRIMARY KEY (id);


--
-- Name: calendar_exclusions calendar_exclusions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.calendar_exclusions
    ADD CONSTRAINT calendar_exclusions_pkey PRIMARY KEY (id);


--
-- Name: checklist_items checklist_items_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.checklist_items
    ADD CONSTRAINT checklist_items_pkey PRIMARY KEY (id);


--
-- Name: checklist_template_items checklist_template_items_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.checklist_template_items
    ADD CONSTRAINT checklist_template_items_pkey PRIMARY KEY (id);


--
-- Name: clients clients_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.clients
    ADD CONSTRAINT clients_pkey PRIMARY KEY (id);


--
-- Name: connector_installations connector_installations_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.connector_installations
    ADD CONSTRAINT connector_installations_pkey PRIMARY KEY (id);


--
-- Name: connector_installations connector_installations_type_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.connector_installations
    ADD CONSTRAINT connector_installations_type_unique UNIQUE (org_id, connector_type);


--
-- Name: contacts contacts_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.contacts
    ADD CONSTRAINT contacts_pkey PRIMARY KEY (id);


--
-- Name: contract_fixed_fees contract_fixed_fees_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.contract_fixed_fees
    ADD CONSTRAINT contract_fixed_fees_pkey PRIMARY KEY (id);


--
-- Name: contract_rates contract_rates_contract_id_work_type_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.contract_rates
    ADD CONSTRAINT contract_rates_contract_id_work_type_key UNIQUE (contract_id, work_type);


--
-- Name: contract_rates contract_rates_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.contract_rates
    ADD CONSTRAINT contract_rates_pkey PRIMARY KEY (id);


--
-- Name: contracts contracts_org_id_number_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.contracts
    ADD CONSTRAINT contracts_org_id_number_key UNIQUE (org_id, number);


--
-- Name: contracts contracts_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.contracts
    ADD CONSTRAINT contracts_pkey PRIMARY KEY (id);


--
-- Name: custom_field_defs custom_field_defs_org_id_entity_name_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.custom_field_defs
    ADD CONSTRAINT custom_field_defs_org_id_entity_name_key UNIQUE (org_id, entity, name);


--
-- Name: custom_field_defs custom_field_defs_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.custom_field_defs
    ADD CONSTRAINT custom_field_defs_pkey PRIMARY KEY (id);


--
-- Name: custom_field_values custom_field_values_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.custom_field_values
    ADD CONSTRAINT custom_field_values_pkey PRIMARY KEY (field_id, entity_id);


--
-- Name: device_assets device_assets_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.device_assets
    ADD CONSTRAINT device_assets_pkey PRIMARY KEY (id);


--
-- Name: dispatch_queue_entries dispatch_queue_entries_org_id_ticket_id_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dispatch_queue_entries
    ADD CONSTRAINT dispatch_queue_entries_org_id_ticket_id_key UNIQUE (org_id, ticket_id);


--
-- Name: dispatch_queue_entries dispatch_queue_entries_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dispatch_queue_entries
    ADD CONSTRAINT dispatch_queue_entries_pkey PRIMARY KEY (id);


--
-- Name: dispatch_status_updates dispatch_status_updates_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dispatch_status_updates
    ADD CONSTRAINT dispatch_status_updates_pkey PRIMARY KEY (id);


--
-- Name: document_versions document_versions_org_id_document_id_version_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.document_versions
    ADD CONSTRAINT document_versions_org_id_document_id_version_key UNIQUE (org_id, document_id, version);


--
-- Name: document_versions document_versions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.document_versions
    ADD CONSTRAINT document_versions_pkey PRIMARY KEY (id);


--
-- Name: documents documents_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.documents
    ADD CONSTRAINT documents_pkey PRIMARY KEY (id);


--
-- Name: email_inbound_settings email_inbound_settings_org_id_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.email_inbound_settings
    ADD CONSTRAINT email_inbound_settings_org_id_key UNIQUE (org_id);


--
-- Name: email_inbound_settings email_inbound_settings_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.email_inbound_settings
    ADD CONSTRAINT email_inbound_settings_pkey PRIMARY KEY (id);


--
-- Name: email_messages email_messages_org_id_rfc_message_id_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.email_messages
    ADD CONSTRAINT email_messages_org_id_rfc_message_id_key UNIQUE (org_id, rfc_message_id);


--
-- Name: email_messages email_messages_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.email_messages
    ADD CONSTRAINT email_messages_pkey PRIMARY KEY (id);


--
-- Name: email_outbound email_outbound_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.email_outbound
    ADD CONSTRAINT email_outbound_pkey PRIMARY KEY (id);


--
-- Name: entity_write_seqs entity_write_seqs_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.entity_write_seqs
    ADD CONSTRAINT entity_write_seqs_pkey PRIMARY KEY (org_id, entity, entity_id);


--
-- Name: entity_writes entity_writes_org_id_entity_entity_id_seq_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.entity_writes
    ADD CONSTRAINT entity_writes_org_id_entity_entity_id_seq_key UNIQUE (org_id, entity, entity_id, seq);


--
-- Name: entity_writes entity_writes_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.entity_writes
    ADD CONSTRAINT entity_writes_pkey PRIMARY KEY (id);


--
-- Name: external_ids external_ids_org_id_entity_kind_external_key_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.external_ids
    ADD CONSTRAINT external_ids_org_id_entity_kind_external_key_key UNIQUE (org_id, entity_kind, external_key);


--
-- Name: external_ids external_ids_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.external_ids
    ADD CONSTRAINT external_ids_pkey PRIMARY KEY (id);


--
-- Name: idempotency_keys idempotency_keys_org_id_key_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.idempotency_keys
    ADD CONSTRAINT idempotency_keys_org_id_key_key UNIQUE (org_id, key);


--
-- Name: idempotency_keys idempotency_keys_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.idempotency_keys
    ADD CONSTRAINT idempotency_keys_pkey PRIMARY KEY (id);


--
-- Name: import_batches import_batches_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.import_batches
    ADD CONSTRAINT import_batches_pkey PRIMARY KEY (id);


--
-- Name: import_mapping_templates import_mapping_templates_org_id_source_system_entity_kind_n_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.import_mapping_templates
    ADD CONSTRAINT import_mapping_templates_org_id_source_system_entity_kind_n_key UNIQUE (org_id, source_system, entity_kind, name);


--
-- Name: import_mapping_templates import_mapping_templates_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.import_mapping_templates
    ADD CONSTRAINT import_mapping_templates_pkey PRIMARY KEY (id);


--
-- Name: invoice_lines invoice_lines_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.invoice_lines
    ADD CONSTRAINT invoice_lines_pkey PRIMARY KEY (id);


--
-- Name: invoice_payments invoice_payments_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.invoice_payments
    ADD CONSTRAINT invoice_payments_pkey PRIMARY KEY (id);


--
-- Name: invoice_runs invoice_runs_org_id_number_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.invoice_runs
    ADD CONSTRAINT invoice_runs_org_id_number_key UNIQUE (org_id, number);


--
-- Name: invoice_runs invoice_runs_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.invoice_runs
    ADD CONSTRAINT invoice_runs_pkey PRIMARY KEY (id);


--
-- Name: invoice_time_entries invoice_time_entries_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.invoice_time_entries
    ADD CONSTRAINT invoice_time_entries_pkey PRIMARY KEY (id);


--
-- Name: invoice_time_entries invoice_time_entries_time_entry_id_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.invoice_time_entries
    ADD CONSTRAINT invoice_time_entries_time_entry_id_key UNIQUE (time_entry_id);


--
-- Name: invoices invoices_org_id_number_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.invoices
    ADD CONSTRAINT invoices_org_id_number_key UNIQUE (org_id, number);


--
-- Name: invoices invoices_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.invoices
    ADD CONSTRAINT invoices_pkey PRIMARY KEY (id);


--
-- Name: jobs jobs_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.jobs
    ADD CONSTRAINT jobs_pkey PRIMARY KEY (id);


--
-- Name: kb_articles kb_articles_org_id_slug_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.kb_articles
    ADD CONSTRAINT kb_articles_org_id_slug_key UNIQUE (org_id, slug);


--
-- Name: kb_articles kb_articles_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.kb_articles
    ADD CONSTRAINT kb_articles_pkey PRIMARY KEY (id);


--
-- Name: kb_categories kb_categories_org_id_slug_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.kb_categories
    ADD CONSTRAINT kb_categories_org_id_slug_key UNIQUE (org_id, slug);


--
-- Name: kb_categories kb_categories_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.kb_categories
    ADD CONSTRAINT kb_categories_pkey PRIMARY KEY (id);


--
-- Name: mcp_capability_grants mcp_capability_grants_org_id_capability_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.mcp_capability_grants
    ADD CONSTRAINT mcp_capability_grants_org_id_capability_key UNIQUE (org_id, capability);


--
-- Name: mcp_capability_grants mcp_capability_grants_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.mcp_capability_grants
    ADD CONSTRAINT mcp_capability_grants_pkey PRIMARY KEY (id);


--
-- Name: mfa_challenges mfa_challenges_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.mfa_challenges
    ADD CONSTRAINT mfa_challenges_pkey PRIMARY KEY (id);


--
-- Name: migration_push_chunks migration_push_chunks_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.migration_push_chunks
    ADD CONSTRAINT migration_push_chunks_pkey PRIMARY KEY (id);


--
-- Name: migration_push_chunks migration_push_chunks_session_id_chunk_index_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.migration_push_chunks
    ADD CONSTRAINT migration_push_chunks_session_id_chunk_index_key UNIQUE (session_id, chunk_index);


--
-- Name: migration_push_sessions migration_push_sessions_batch_id_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.migration_push_sessions
    ADD CONSTRAINT migration_push_sessions_batch_id_key UNIQUE (batch_id);


--
-- Name: migration_push_sessions migration_push_sessions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.migration_push_sessions
    ADD CONSTRAINT migration_push_sessions_pkey PRIMARY KEY (id);


--
-- Name: notification_org_defaults notification_org_defaults_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.notification_org_defaults
    ADD CONSTRAINT notification_org_defaults_pkey PRIMARY KEY (org_id, kind);


--
-- Name: notification_preferences notification_preferences_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.notification_preferences
    ADD CONSTRAINT notification_preferences_pkey PRIMARY KEY (user_id, kind);


--
-- Name: notifications notifications_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.notifications
    ADD CONSTRAINT notifications_pkey PRIMARY KEY (id);


--
-- Name: oidc_accounts oidc_accounts_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.oidc_accounts
    ADD CONSTRAINT oidc_accounts_pkey PRIMARY KEY (id);


--
-- Name: oidc_accounts oidc_accounts_provider_id_subject_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.oidc_accounts
    ADD CONSTRAINT oidc_accounts_provider_id_subject_key UNIQUE (provider_id, subject);


--
-- Name: oidc_providers oidc_providers_org_id_name_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.oidc_providers
    ADD CONSTRAINT oidc_providers_org_id_name_key UNIQUE (org_id, name);


--
-- Name: oidc_providers oidc_providers_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.oidc_providers
    ADD CONSTRAINT oidc_providers_pkey PRIMARY KEY (id);


--
-- Name: on_call_blocks on_call_blocks_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.on_call_blocks
    ADD CONSTRAINT on_call_blocks_pkey PRIMARY KEY (id);


--
-- Name: on_call_blocks on_call_no_overlap; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.on_call_blocks
    ADD CONSTRAINT on_call_no_overlap EXCLUDE USING gist (user_id WITH =, tstzrange(starts_at, ends_at, '[)'::text) WITH &&);


--
-- Name: orgs orgs_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.orgs
    ADD CONSTRAINT orgs_pkey PRIMARY KEY (id);


--
-- Name: orgs orgs_slug_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.orgs
    ADD CONSTRAINT orgs_slug_key UNIQUE (slug);


--
-- Name: outbox_events outbox_events_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.outbox_events
    ADD CONSTRAINT outbox_events_pkey PRIMARY KEY (id);


--
-- Name: portal_appointment_requests portal_appointment_requests_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.portal_appointment_requests
    ADD CONSTRAINT portal_appointment_requests_pkey PRIMARY KEY (id);


--
-- Name: portal_sessions portal_sessions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.portal_sessions
    ADD CONSTRAINT portal_sessions_pkey PRIMARY KEY (id);


--
-- Name: portal_users portal_users_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.portal_users
    ADD CONSTRAINT portal_users_pkey PRIMARY KEY (id);


--
-- Name: project_phases project_phases_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.project_phases
    ADD CONSTRAINT project_phases_pkey PRIMARY KEY (id);


--
-- Name: project_phases project_phases_project_id_name_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.project_phases
    ADD CONSTRAINT project_phases_project_id_name_key UNIQUE (project_id, name);


--
-- Name: project_task_deps project_task_deps_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.project_task_deps
    ADD CONSTRAINT project_task_deps_pkey PRIMARY KEY (task_id, depends_on_task_id);


--
-- Name: project_tasks project_tasks_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.project_tasks
    ADD CONSTRAINT project_tasks_pkey PRIMARY KEY (id);


--
-- Name: project_templates project_templates_org_id_name_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.project_templates
    ADD CONSTRAINT project_templates_org_id_name_key UNIQUE (org_id, name);


--
-- Name: project_templates project_templates_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.project_templates
    ADD CONSTRAINT project_templates_pkey PRIMARY KEY (id);


--
-- Name: project_views project_views_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.project_views
    ADD CONSTRAINT project_views_pkey PRIMARY KEY (id);


--
-- Name: projects projects_org_id_name_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.projects
    ADD CONSTRAINT projects_org_id_name_key UNIQUE (org_id, name);


--
-- Name: projects projects_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.projects
    ADD CONSTRAINT projects_pkey PRIMARY KEY (id);


--
-- Name: provenance_events provenance_events_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.provenance_events
    ADD CONSTRAINT provenance_events_pkey PRIMARY KEY (write_id, field_seq);


--
-- Name: recovery_codes recovery_codes_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.recovery_codes
    ADD CONSTRAINT recovery_codes_pkey PRIMARY KEY (id);


--
-- Name: report_definitions report_definitions_org_id_name_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.report_definitions
    ADD CONSTRAINT report_definitions_org_id_name_key UNIQUE (org_id, name);


--
-- Name: report_definitions report_definitions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.report_definitions
    ADD CONSTRAINT report_definitions_pkey PRIMARY KEY (id);


--
-- Name: report_deliveries report_deliveries_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.report_deliveries
    ADD CONSTRAINT report_deliveries_pkey PRIMARY KEY (id);


--
-- Name: report_schedules report_schedules_org_id_name_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.report_schedules
    ADD CONSTRAINT report_schedules_org_id_name_key UNIQUE (org_id, name);


--
-- Name: report_schedules report_schedules_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.report_schedules
    ADD CONSTRAINT report_schedules_pkey PRIMARY KEY (id);


--
-- Name: roles roles_org_id_name_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.roles
    ADD CONSTRAINT roles_org_id_name_key UNIQUE (org_id, name);


--
-- Name: roles roles_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.roles
    ADD CONSTRAINT roles_pkey PRIMARY KEY (id);


--
-- Name: search_index search_index_org_id_entity_kind_entity_id_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.search_index
    ADD CONSTRAINT search_index_org_id_entity_kind_entity_id_key UNIQUE (org_id, entity_kind, entity_id);


--
-- Name: search_index search_index_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.search_index
    ADD CONSTRAINT search_index_pkey PRIMARY KEY (id);


--
-- Name: settings settings_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.settings
    ADD CONSTRAINT settings_pkey PRIMARY KEY (id);


--
-- Name: sites sites_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sites
    ADD CONSTRAINT sites_pkey PRIMARY KEY (id);


--
-- Name: sla_calendars sla_calendars_org_id_name_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sla_calendars
    ADD CONSTRAINT sla_calendars_org_id_name_key UNIQUE (org_id, name);


--
-- Name: sla_calendars sla_calendars_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sla_calendars
    ADD CONSTRAINT sla_calendars_pkey PRIMARY KEY (id);


--
-- Name: sla_escalation_steps sla_escalation_steps_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sla_escalation_steps
    ADD CONSTRAINT sla_escalation_steps_pkey PRIMARY KEY (id);


--
-- Name: sla_escalation_steps sla_escalation_steps_policy_id_step_index_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sla_escalation_steps
    ADD CONSTRAINT sla_escalation_steps_policy_id_step_index_key UNIQUE (policy_id, step_index);


--
-- Name: sla_fired_escalations sla_fired_escalations_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sla_fired_escalations
    ADD CONSTRAINT sla_fired_escalations_pkey PRIMARY KEY (ticket_id, step_id, target);


--
-- Name: sla_policies sla_policies_org_id_name_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sla_policies
    ADD CONSTRAINT sla_policies_org_id_name_key UNIQUE (org_id, name);


--
-- Name: sla_policies sla_policies_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sla_policies
    ADD CONSTRAINT sla_policies_pkey PRIMARY KEY (id);


--
-- Name: ticket_comments ticket_comments_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ticket_comments
    ADD CONSTRAINT ticket_comments_pkey PRIMARY KEY (id);


--
-- Name: ticket_required_skills ticket_required_skills_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ticket_required_skills
    ADD CONSTRAINT ticket_required_skills_pkey PRIMARY KEY (id);


--
-- Name: ticket_required_skills ticket_required_skills_ticket_id_skill_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ticket_required_skills
    ADD CONSTRAINT ticket_required_skills_ticket_id_skill_key UNIQUE (ticket_id, skill);


--
-- Name: ticket_sla_state ticket_sla_state_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ticket_sla_state
    ADD CONSTRAINT ticket_sla_state_pkey PRIMARY KEY (ticket_id);


--
-- Name: tickets tickets_org_id_number_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tickets
    ADD CONSTRAINT tickets_org_id_number_key UNIQUE (org_id, number);


--
-- Name: tickets tickets_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tickets
    ADD CONSTRAINT tickets_pkey PRIMARY KEY (id);


--
-- Name: time_entries time_entries_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.time_entries
    ADD CONSTRAINT time_entries_pkey PRIMARY KEY (id);


--
-- Name: time_gap_audits time_gap_audits_org_id_user_id_day_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.time_gap_audits
    ADD CONSTRAINT time_gap_audits_org_id_user_id_day_key UNIQUE (org_id, user_id, day);


--
-- Name: time_gap_audits time_gap_audits_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.time_gap_audits
    ADD CONSTRAINT time_gap_audits_pkey PRIMARY KEY (id);


--
-- Name: timer_sessions timer_sessions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.timer_sessions
    ADD CONSTRAINT timer_sessions_pkey PRIMARY KEY (id);


--
-- Name: totp_secrets totp_secrets_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.totp_secrets
    ADD CONSTRAINT totp_secrets_pkey PRIMARY KEY (id);


--
-- Name: totp_secrets totp_secrets_user_id_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.totp_secrets
    ADD CONSTRAINT totp_secrets_user_id_key UNIQUE (user_id);


--
-- Name: travel_entry_drafts travel_entry_drafts_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.travel_entry_drafts
    ADD CONSTRAINT travel_entry_drafts_pkey PRIMARY KEY (id);


--
-- Name: user_roles user_roles_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_roles
    ADD CONSTRAINT user_roles_pkey PRIMARY KEY (user_id, role_id);


--
-- Name: user_skills user_skills_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_skills
    ADD CONSTRAINT user_skills_pkey PRIMARY KEY (id);


--
-- Name: user_skills user_skills_user_id_skill_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_skills
    ADD CONSTRAINT user_skills_user_id_skill_key UNIQUE (user_id, skill);


--
-- Name: users users_org_id_email_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_org_id_email_key UNIQUE (org_id, email);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- Name: webauthn_credentials webauthn_credentials_cred_id_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.webauthn_credentials
    ADD CONSTRAINT webauthn_credentials_cred_id_key UNIQUE (cred_id);


--
-- Name: webauthn_credentials webauthn_credentials_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.webauthn_credentials
    ADD CONSTRAINT webauthn_credentials_pkey PRIMARY KEY (id);


--
-- Name: webhook_deliveries webhook_deliveries_attempt_unique; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.webhook_deliveries
    ADD CONSTRAINT webhook_deliveries_attempt_unique UNIQUE (webhook_id, event_id, attempt);


--
-- Name: webhook_deliveries webhook_deliveries_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.webhook_deliveries
    ADD CONSTRAINT webhook_deliveries_pkey PRIMARY KEY (id);


--
-- Name: webhooks webhooks_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.webhooks
    ADD CONSTRAINT webhooks_pkey PRIMARY KEY (id);


--
-- Name: alert_sources_org_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX alert_sources_org_idx ON public.alert_sources USING btree (org_id);


--
-- Name: custom_field_defs_active_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX custom_field_defs_active_idx ON public.custom_field_defs USING btree (org_id, entity, board_id) WHERE (archived_at IS NULL);


--
-- Name: custom_field_values_entity_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX custom_field_values_entity_idx ON public.custom_field_values USING btree (org_id, entity_id);


--
-- Name: idx_agent_proposals_org_entity; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_agent_proposals_org_entity ON public.agent_proposals USING btree (org_id, entity, entity_id);


--
-- Name: idx_agent_proposals_org_status; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_agent_proposals_org_status ON public.agent_proposals USING btree (org_id, status, created_at DESC, id DESC);


--
-- Name: idx_agent_skills_org_slug; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_agent_skills_org_slug ON public.agent_skills USING btree (org_id, slug, version DESC);


--
-- Name: idx_alert_incidents_open; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX idx_alert_incidents_open ON public.alert_incidents USING btree (org_id, source_id, correlation_key) WHERE (closed_at IS NULL);


--
-- Name: idx_alert_incidents_ticket; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_alert_incidents_ticket ON public.alert_incidents USING btree (ticket_id);


--
-- Name: idx_alert_sources_ref; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX idx_alert_sources_ref ON public.alert_sources USING btree (source_ref);


--
-- Name: idx_alerts_received; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_alerts_received ON public.alerts USING btree (org_id, received_at DESC);


--
-- Name: idx_alerts_ticket; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_alerts_ticket ON public.alerts USING btree (org_id, incident_ticket_id) WHERE (incident_ticket_id IS NOT NULL);


--
-- Name: idx_appointments_org_time; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_appointments_org_time ON public.appointments USING btree (org_id, starts_at);


--
-- Name: idx_appointments_ticket; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_appointments_ticket ON public.appointments USING btree (ticket_id) WHERE (ticket_id IS NOT NULL);


--
-- Name: idx_appointments_user_time; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_appointments_user_time ON public.appointments USING btree (user_id, starts_at);


--
-- Name: idx_assets_client; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_assets_client ON public.device_assets USING btree (client_id);


--
-- Name: idx_attachments_comment; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_attachments_comment ON public.attachments USING btree (org_id, ticket_comment_id) WHERE (ticket_comment_id IS NOT NULL);


--
-- Name: idx_attachments_dedupe; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_attachments_dedupe ON public.attachments USING btree (org_id, sha256);


--
-- Name: idx_attachments_email; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_attachments_email ON public.attachments USING btree (org_id, email_message_id) WHERE (email_message_id IS NOT NULL);


--
-- Name: idx_attachments_key_refs; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_attachments_key_refs ON public.attachments USING btree (storage_key);


--
-- Name: idx_attachments_ticket; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_attachments_ticket ON public.attachments USING btree (org_id, ticket_id);


--
-- Name: idx_audit_org_time; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_audit_org_time ON public.audit_events USING btree (org_id, occurred_at DESC);


--
-- Name: idx_auth_sessions_chain; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_auth_sessions_chain ON public.auth_sessions USING btree (chain_id);


--
-- Name: idx_auth_sessions_user; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_auth_sessions_user ON public.auth_sessions USING btree (user_id);


--
-- Name: idx_automation_rules_trigger; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_automation_rules_trigger ON public.automation_rules USING btree (org_id, trigger_event) WHERE enabled;


--
-- Name: idx_availability_no_dupes; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX idx_availability_no_dupes ON public.availability_windows USING btree (org_id, user_id, weekday, start_local, end_local, timezone, COALESCE(effective_from, '0001-01-01'::date), COALESCE(effective_until, '0001-01-01'::date));


--
-- Name: idx_availability_user; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_availability_user ON public.availability_windows USING btree (org_id, user_id);


--
-- Name: idx_board_exposure_client; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_board_exposure_client ON public.board_portal_exposure USING btree (org_id, client_id);


--
-- Name: idx_board_groups_org; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_board_groups_org ON public.board_groups USING btree (org_id, "position");


--
-- Name: idx_board_members_board; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_board_members_board ON public.board_members USING btree (board_id);


--
-- Name: idx_board_statuses_board; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_board_statuses_board ON public.board_statuses USING btree (board_id, sort_order);


--
-- Name: idx_board_transitions_board; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_board_transitions_board ON public.board_status_transitions USING btree (board_id);


--
-- Name: idx_boards_group; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_boards_group ON public.boards USING btree (board_group_id);


--
-- Name: idx_boards_inbound_address; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX idx_boards_inbound_address ON public.boards USING btree (inbound_address) WHERE (inbound_address IS NOT NULL);


--
-- Name: idx_byok_secrets_org; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_byok_secrets_org ON public.byok_secrets USING btree (org_id);


--
-- Name: idx_calendar_exclusions_user_time; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_calendar_exclusions_user_time ON public.calendar_exclusions USING btree (org_id, user_id, starts_at);


--
-- Name: idx_checklist_template_link; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_checklist_template_link ON public.checklist_items USING btree (template_item_id);


--
-- Name: idx_checklist_ticket; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_checklist_ticket ON public.checklist_items USING btree (ticket_id, sort_order);


--
-- Name: idx_clients_org; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_clients_org ON public.clients USING btree (org_id, name);


--
-- Name: idx_comments_ticket; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_comments_ticket ON public.ticket_comments USING btree (ticket_id, created_at);


--
-- Name: idx_contacts_client; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_contacts_client ON public.contacts USING btree (client_id);


--
-- Name: idx_contract_fees_due; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_contract_fees_due ON public.contract_fixed_fees USING btree (contract_id, due_on);


--
-- Name: idx_contracts_client; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_contracts_client ON public.contracts USING btree (org_id, client_id);


--
-- Name: idx_contracts_status; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_contracts_status ON public.contracts USING btree (org_id, status);


--
-- Name: idx_dispatch_queue_entries_rank; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_dispatch_queue_entries_rank ON public.dispatch_queue_entries USING btree (org_id, rank);


--
-- Name: idx_dispatch_status_updates_appt; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_dispatch_status_updates_appt ON public.dispatch_status_updates USING btree (org_id, appointment_id, occurred_at DESC);


--
-- Name: idx_document_versions_doc; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_document_versions_doc ON public.document_versions USING btree (org_id, document_id, version DESC);


--
-- Name: idx_email_inbound_catchall_addr; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX idx_email_inbound_catchall_addr ON public.email_inbound_settings USING btree (catchall_address);


--
-- Name: idx_email_messages_in_reply_to; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_email_messages_in_reply_to ON public.email_messages USING btree (org_id, in_reply_to) WHERE (in_reply_to IS NOT NULL);


--
-- Name: idx_email_messages_ticket; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_email_messages_ticket ON public.email_messages USING btree (org_id, ticket_id);


--
-- Name: idx_email_outbound_due; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_email_outbound_due ON public.email_outbound USING btree (status, next_attempt_at);


--
-- Name: idx_entity_writes_actor; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_entity_writes_actor ON public.entity_writes USING btree (org_id, actor_id, created_at DESC);


--
-- Name: idx_entity_writes_trail; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_entity_writes_trail ON public.entity_writes USING btree (org_id, entity, entity_id, created_at DESC);


--
-- Name: idx_entries_org_time; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_entries_org_time ON public.time_entries USING btree (org_id, started_at);


--
-- Name: idx_entries_ticket; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_entries_ticket ON public.time_entries USING btree (ticket_id);


--
-- Name: idx_entries_user_time; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_entries_user_time ON public.time_entries USING btree (user_id, started_at DESC);


--
-- Name: idx_external_ids_internal; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_external_ids_internal ON public.external_ids USING btree (org_id, entity_kind, internal_id);


--
-- Name: idx_gap_audits_org_day; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_gap_audits_org_day ON public.time_gap_audits USING btree (org_id, day DESC);


--
-- Name: idx_import_batches_org; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_import_batches_org ON public.import_batches USING btree (org_id, started_at DESC);


--
-- Name: idx_import_mapping_templates_org; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_import_mapping_templates_org ON public.import_mapping_templates USING btree (org_id, source_system);


--
-- Name: idx_invoice_lines_invoice; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_invoice_lines_invoice ON public.invoice_lines USING btree (invoice_id, "position");


--
-- Name: idx_invoice_payments_invoice; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_invoice_payments_invoice ON public.invoice_payments USING btree (invoice_id, received_at);


--
-- Name: idx_invoice_runs_created; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_invoice_runs_created ON public.invoice_runs USING btree (org_id, created_at DESC);


--
-- Name: idx_invoice_time_entries_invoice; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_invoice_time_entries_invoice ON public.invoice_time_entries USING btree (invoice_id);


--
-- Name: idx_invoices_client; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_invoices_client ON public.invoices USING btree (org_id, client_id);


--
-- Name: idx_invoices_contract; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_invoices_contract ON public.invoices USING btree (org_id, contract_id);


--
-- Name: idx_invoices_dunning; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_invoices_dunning ON public.invoices USING btree (org_id, dunning_state);


--
-- Name: idx_invoices_status; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_invoices_status ON public.invoices USING btree (org_id, status);


--
-- Name: idx_jobs_claim; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_jobs_claim ON public.jobs USING btree (status, run_after) WHERE (status = 'pending'::text);


--
-- Name: idx_jobs_stale; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_jobs_stale ON public.jobs USING btree (claimed_at) WHERE (status = 'running'::text);


--
-- Name: idx_kb_articles_org_category; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_kb_articles_org_category ON public.kb_articles USING btree (org_id, category_id);


--
-- Name: idx_kb_articles_org_status; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_kb_articles_org_status ON public.kb_articles USING btree (org_id, status);


--
-- Name: idx_mcp_capability_grants_org; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_mcp_capability_grants_org ON public.mcp_capability_grants USING btree (org_id);


--
-- Name: idx_mfa_challenges_expiry; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_mfa_challenges_expiry ON public.mfa_challenges USING btree (expires_at);


--
-- Name: idx_migration_push_chunks_session; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_migration_push_chunks_session ON public.migration_push_chunks USING btree (session_id, chunk_index);


--
-- Name: idx_migration_push_sessions_org; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_migration_push_sessions_org ON public.migration_push_sessions USING btree (org_id, created_at DESC);


--
-- Name: idx_notifications_unread; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_notifications_unread ON public.notifications USING btree (org_id, user_id) WHERE (read_at IS NULL);


--
-- Name: idx_notifications_user; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_notifications_user ON public.notifications USING btree (user_id, created_at DESC);


--
-- Name: idx_oidc_accounts_user; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_oidc_accounts_user ON public.oidc_accounts USING btree (user_id);


--
-- Name: idx_on_call_org_time; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_on_call_org_time ON public.on_call_blocks USING btree (org_id, starts_at);


--
-- Name: idx_on_call_user_time; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_on_call_user_time ON public.on_call_blocks USING btree (user_id, starts_at);


--
-- Name: idx_outbox_unpublished; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_outbox_unpublished ON public.outbox_events USING btree (occurred_at) WHERE (published_at IS NULL);


--
-- Name: idx_portal_appt_requests_client; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_portal_appt_requests_client ON public.portal_appointment_requests USING btree (org_id, client_id, created_at DESC);


--
-- Name: idx_portal_appt_requests_staff; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_portal_appt_requests_staff ON public.portal_appointment_requests USING btree (org_id, user_id, starts_at);


--
-- Name: idx_portal_appt_requests_status; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_portal_appt_requests_status ON public.portal_appointment_requests USING btree (org_id, status, created_at DESC);


--
-- Name: idx_portal_sessions_user; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_portal_sessions_user ON public.portal_sessions USING btree (portal_user_id);


--
-- Name: idx_portal_users_client; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_portal_users_client ON public.portal_users USING btree (org_id, client_id);


--
-- Name: idx_project_phases_project; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_project_phases_project ON public.project_phases USING btree (project_id, sort_order);


--
-- Name: idx_project_task_deps_reverse; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_project_task_deps_reverse ON public.project_task_deps USING btree (depends_on_task_id);


--
-- Name: idx_project_tasks_assignee; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_project_tasks_assignee ON public.project_tasks USING btree (org_id, assignee_id) WHERE (status <> ALL (ARRAY['completed'::text, 'cancelled'::text]));


--
-- Name: idx_project_tasks_project; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_project_tasks_project ON public.project_tasks USING btree (project_id, sort_order);


--
-- Name: idx_project_views_org; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_project_views_org ON public.project_views USING btree (org_id, project_id);


--
-- Name: idx_projects_org; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_projects_org ON public.projects USING btree (org_id, status);


--
-- Name: idx_provenance_actor; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_provenance_actor ON public.provenance_events USING btree (org_id, actor_id, occurred_at DESC, write_id DESC);


--
-- Name: idx_provenance_record; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_provenance_record ON public.provenance_events USING btree (org_id, entity, entity_id, field, occurred_at DESC, write_id DESC);


--
-- Name: idx_provenance_ruleset; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_provenance_ruleset ON public.provenance_events USING btree (org_id, ruleset_hash, occurred_at DESC) WHERE (ruleset_hash IS NOT NULL);


--
-- Name: idx_provenance_session; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_provenance_session ON public.provenance_events USING btree (org_id, session_id, occurred_at DESC) WHERE (session_id IS NOT NULL);


--
-- Name: idx_provenance_skill; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_provenance_skill ON public.provenance_events USING btree (org_id, skill, occurred_at DESC) WHERE (skill IS NOT NULL);


--
-- Name: idx_recovery_codes_user_unused; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_recovery_codes_user_unused ON public.recovery_codes USING btree (user_id) WHERE (used_at IS NULL);


--
-- Name: idx_report_definitions_org; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_report_definitions_org ON public.report_definitions USING btree (org_id, scope, name);


--
-- Name: idx_report_deliveries_schedule; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_report_deliveries_schedule ON public.report_deliveries USING btree (schedule_id, slot_at DESC);


--
-- Name: idx_report_schedules_due; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_report_schedules_due ON public.report_schedules USING btree (next_run_at) WHERE enabled;


--
-- Name: idx_report_schedules_org; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_report_schedules_org ON public.report_schedules USING btree (org_id, name);


--
-- Name: idx_search_fts; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_search_fts ON public.search_index USING gin (tsv);


--
-- Name: idx_search_kind; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_search_kind ON public.search_index USING btree (org_id, entity_kind);


--
-- Name: idx_search_trgm; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_search_trgm ON public.search_index USING gin ((((title || ' '::text) || body)) public.gin_trgm_ops);


--
-- Name: idx_sites_client; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_sites_client ON public.sites USING btree (client_id);


--
-- Name: idx_sla_state_due; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_sla_state_due ON public.ticket_sla_state USING btree (org_id, resolution_due) WHERE (breached = false);


--
-- Name: idx_sla_steps_policy; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_sla_steps_policy ON public.sla_escalation_steps USING btree (policy_id) WHERE enabled;


--
-- Name: idx_template_items_template; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_template_items_template ON public.checklist_template_items USING btree (template_id, sort_order);


--
-- Name: idx_ticket_required_skills_org; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_ticket_required_skills_org ON public.ticket_required_skills USING btree (org_id, skill);


--
-- Name: idx_tickets_assignee; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_tickets_assignee ON public.tickets USING btree (org_id, assignee_id) WHERE (assignee_id IS NOT NULL);


--
-- Name: idx_tickets_board; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_tickets_board ON public.tickets USING btree (board_id, category, updated_at DESC);


--
-- Name: idx_tickets_client; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_tickets_client ON public.tickets USING btree (client_id);


--
-- Name: idx_tickets_title_fts; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_tickets_title_fts ON public.tickets USING gin (to_tsvector('english'::regconfig, ((title || ' '::text) || COALESCE(body, ''::text))));


--
-- Name: idx_timer_one_running_per_user; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX idx_timer_one_running_per_user ON public.timer_sessions USING btree (user_id) WHERE is_running;


--
-- Name: idx_timer_user_paused; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_timer_user_paused ON public.timer_sessions USING btree (user_id, started_at DESC) WHERE ((stopped_at IS NULL) AND (NOT is_running));


--
-- Name: idx_timer_user_recent; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_timer_user_recent ON public.timer_sessions USING btree (user_id, started_at DESC);


--
-- Name: idx_travel_entry_drafts_org; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_travel_entry_drafts_org ON public.travel_entry_drafts USING btree (org_id, status, user_id);


--
-- Name: idx_user_skills_org; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_user_skills_org ON public.user_skills USING btree (org_id, skill);


--
-- Name: idx_users_email; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_users_email ON public.users USING btree (lower(email));


--
-- Name: idx_webauthn_creds_user; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_webauthn_creds_user ON public.webauthn_credentials USING btree (user_id);


--
-- Name: settings_key_unique; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX settings_key_unique ON public.settings USING btree (org_id, scope, key, COALESCE(owner_id, '00000000-0000-0000-0000-000000000000'::uuid));


--
-- Name: uq_invoice_lines_fixed_fee; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX uq_invoice_lines_fixed_fee ON public.invoice_lines USING btree (org_id, contract_id, kind, period_start, description) WHERE (kind = 'fixed_fee'::text);


--
-- Name: uq_invoice_lines_period; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX uq_invoice_lines_period ON public.invoice_lines USING btree (org_id, contract_id, kind, period_start) WHERE (kind = ANY (ARRAY['recurring_base'::text, 'retainer_base'::text, 'retainer_overage'::text]));


--
-- Name: uq_portal_users_org_email; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX uq_portal_users_org_email ON public.portal_users USING btree (org_id, lower(email));


--
-- Name: webhook_deliveries_page_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX webhook_deliveries_page_idx ON public.webhook_deliveries USING btree (webhook_id, created_at DESC, id DESC);


--
-- Name: webhooks_org_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX webhooks_org_idx ON public.webhooks USING btree (org_id);


--
-- Name: entity_writes provenance_project; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER provenance_project AFTER INSERT ON public.entity_writes FOR EACH ROW EXECUTE FUNCTION public.provenance_project_write();


--
-- Name: agent_proposals agent_proposals_decided_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.agent_proposals
    ADD CONSTRAINT agent_proposals_decided_by_fkey FOREIGN KEY (decided_by) REFERENCES public.users(id);


--
-- Name: agent_proposals agent_proposals_for_user_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.agent_proposals
    ADD CONSTRAINT agent_proposals_for_user_fkey FOREIGN KEY (for_user) REFERENCES public.users(id);


--
-- Name: agent_proposals agent_proposals_org_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.agent_proposals
    ADD CONSTRAINT agent_proposals_org_id_fkey FOREIGN KEY (org_id) REFERENCES public.orgs(id) ON DELETE CASCADE;


--
-- Name: agent_skills agent_skills_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.agent_skills
    ADD CONSTRAINT agent_skills_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.users(id);


--
-- Name: agent_skills agent_skills_org_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.agent_skills
    ADD CONSTRAINT agent_skills_org_id_fkey FOREIGN KEY (org_id) REFERENCES public.orgs(id) ON DELETE CASCADE;


--
-- Name: alert_incidents alert_incidents_org_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.alert_incidents
    ADD CONSTRAINT alert_incidents_org_id_fkey FOREIGN KEY (org_id) REFERENCES public.orgs(id) ON DELETE CASCADE;


--
-- Name: alert_incidents alert_incidents_source_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.alert_incidents
    ADD CONSTRAINT alert_incidents_source_id_fkey FOREIGN KEY (source_id) REFERENCES public.alert_sources(id) ON DELETE CASCADE;


--
-- Name: alert_incidents alert_incidents_ticket_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.alert_incidents
    ADD CONSTRAINT alert_incidents_ticket_id_fkey FOREIGN KEY (ticket_id) REFERENCES public.tickets(id) ON DELETE CASCADE;


--
-- Name: alert_sources alert_sources_board_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.alert_sources
    ADD CONSTRAINT alert_sources_board_id_fkey FOREIGN KEY (board_id) REFERENCES public.boards(id) ON DELETE RESTRICT;


--
-- Name: alert_sources alert_sources_client_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.alert_sources
    ADD CONSTRAINT alert_sources_client_id_fkey FOREIGN KEY (client_id) REFERENCES public.clients(id) ON DELETE SET NULL;


--
-- Name: alert_sources alert_sources_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.alert_sources
    ADD CONSTRAINT alert_sources_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: alert_sources alert_sources_org_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.alert_sources
    ADD CONSTRAINT alert_sources_org_id_fkey FOREIGN KEY (org_id) REFERENCES public.orgs(id) ON DELETE CASCADE;


--
-- Name: alerts alerts_incident_ticket_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.alerts
    ADD CONSTRAINT alerts_incident_ticket_id_fkey FOREIGN KEY (incident_ticket_id) REFERENCES public.tickets(id) ON DELETE SET NULL;


--
-- Name: alerts alerts_org_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.alerts
    ADD CONSTRAINT alerts_org_id_fkey FOREIGN KEY (org_id) REFERENCES public.orgs(id) ON DELETE CASCADE;


--
-- Name: alerts alerts_source_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.alerts
    ADD CONSTRAINT alerts_source_id_fkey FOREIGN KEY (source_id) REFERENCES public.alert_sources(id) ON DELETE CASCADE;


--
-- Name: api_keys api_keys_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.api_keys
    ADD CONSTRAINT api_keys_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: api_keys api_keys_org_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.api_keys
    ADD CONSTRAINT api_keys_org_id_fkey FOREIGN KEY (org_id) REFERENCES public.orgs(id) ON DELETE CASCADE;


--
-- Name: appointments appointments_client_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.appointments
    ADD CONSTRAINT appointments_client_id_fkey FOREIGN KEY (client_id) REFERENCES public.clients(id) ON DELETE SET NULL;


--
-- Name: appointments appointments_org_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.appointments
    ADD CONSTRAINT appointments_org_id_fkey FOREIGN KEY (org_id) REFERENCES public.orgs(id) ON DELETE CASCADE;


--
-- Name: appointments appointments_site_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.appointments
    ADD CONSTRAINT appointments_site_id_fkey FOREIGN KEY (site_id) REFERENCES public.sites(id) ON DELETE SET NULL;


--
-- Name: appointments appointments_ticket_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.appointments
    ADD CONSTRAINT appointments_ticket_id_fkey FOREIGN KEY (ticket_id) REFERENCES public.tickets(id) ON DELETE SET NULL;


--
-- Name: appointments appointments_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.appointments
    ADD CONSTRAINT appointments_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: attachments attachments_email_message_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.attachments
    ADD CONSTRAINT attachments_email_message_id_fkey FOREIGN KEY (email_message_id) REFERENCES public.email_messages(id) ON DELETE CASCADE;


--
-- Name: attachments attachments_org_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.attachments
    ADD CONSTRAINT attachments_org_id_fkey FOREIGN KEY (org_id) REFERENCES public.orgs(id) ON DELETE CASCADE;


--
-- Name: attachments attachments_ticket_comment_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.attachments
    ADD CONSTRAINT attachments_ticket_comment_id_fkey FOREIGN KEY (ticket_comment_id) REFERENCES public.ticket_comments(id) ON DELETE CASCADE;


--
-- Name: attachments attachments_ticket_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.attachments
    ADD CONSTRAINT attachments_ticket_id_fkey FOREIGN KEY (ticket_id) REFERENCES public.tickets(id) ON DELETE CASCADE;


--
-- Name: attachments attachments_uploaded_by_portal_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.attachments
    ADD CONSTRAINT attachments_uploaded_by_portal_user_id_fkey FOREIGN KEY (uploaded_by_portal_user_id) REFERENCES public.portal_users(id) ON DELETE SET NULL;


--
-- Name: attachments attachments_uploaded_by_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.attachments
    ADD CONSTRAINT attachments_uploaded_by_user_id_fkey FOREIGN KEY (uploaded_by_user_id) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: audit_events audit_events_org_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.audit_events
    ADD CONSTRAINT audit_events_org_id_fkey FOREIGN KEY (org_id) REFERENCES public.orgs(id) ON DELETE CASCADE;


--
-- Name: auth_sessions auth_sessions_rotated_from_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.auth_sessions
    ADD CONSTRAINT auth_sessions_rotated_from_fkey FOREIGN KEY (rotated_from) REFERENCES public.auth_sessions(id) ON DELETE SET NULL;


--
-- Name: auth_sessions auth_sessions_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.auth_sessions
    ADD CONSTRAINT auth_sessions_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: automation_rules automation_rules_board_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.automation_rules
    ADD CONSTRAINT automation_rules_board_id_fkey FOREIGN KEY (board_id) REFERENCES public.boards(id) ON DELETE CASCADE;


--
-- Name: automation_rules automation_rules_org_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.automation_rules
    ADD CONSTRAINT automation_rules_org_id_fkey FOREIGN KEY (org_id) REFERENCES public.orgs(id) ON DELETE CASCADE;


--
-- Name: availability_windows availability_windows_org_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.availability_windows
    ADD CONSTRAINT availability_windows_org_id_fkey FOREIGN KEY (org_id) REFERENCES public.orgs(id) ON DELETE CASCADE;


--
-- Name: availability_windows availability_windows_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.availability_windows
    ADD CONSTRAINT availability_windows_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: board_checklist_templates board_checklist_templates_board_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.board_checklist_templates
    ADD CONSTRAINT board_checklist_templates_board_id_fkey FOREIGN KEY (board_id) REFERENCES public.boards(id) ON DELETE CASCADE;


--
-- Name: board_checklist_templates board_checklist_templates_org_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.board_checklist_templates
    ADD CONSTRAINT board_checklist_templates_org_id_fkey FOREIGN KEY (org_id) REFERENCES public.orgs(id) ON DELETE CASCADE;


--
-- Name: board_favorites board_favorites_board_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.board_favorites
    ADD CONSTRAINT board_favorites_board_id_fkey FOREIGN KEY (board_id) REFERENCES public.boards(id) ON DELETE CASCADE;


--
-- Name: board_favorites board_favorites_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.board_favorites
    ADD CONSTRAINT board_favorites_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: board_groups board_groups_org_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.board_groups
    ADD CONSTRAINT board_groups_org_id_fkey FOREIGN KEY (org_id) REFERENCES public.orgs(id) ON DELETE CASCADE;


--
-- Name: board_groups board_groups_owner_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.board_groups
    ADD CONSTRAINT board_groups_owner_id_fkey FOREIGN KEY (owner_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: board_members board_members_board_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.board_members
    ADD CONSTRAINT board_members_board_id_fkey FOREIGN KEY (board_id) REFERENCES public.boards(id) ON DELETE CASCADE;


--
-- Name: board_members board_members_org_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.board_members
    ADD CONSTRAINT board_members_org_id_fkey FOREIGN KEY (org_id) REFERENCES public.orgs(id) ON DELETE CASCADE;


--
-- Name: board_members board_members_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.board_members
    ADD CONSTRAINT board_members_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: board_portal_exposure board_portal_exposure_board_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.board_portal_exposure
    ADD CONSTRAINT board_portal_exposure_board_id_fkey FOREIGN KEY (board_id) REFERENCES public.boards(id) ON DELETE CASCADE;


--
-- Name: board_portal_exposure board_portal_exposure_client_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.board_portal_exposure
    ADD CONSTRAINT board_portal_exposure_client_id_fkey FOREIGN KEY (client_id) REFERENCES public.clients(id) ON DELETE CASCADE;


--
-- Name: board_portal_exposure board_portal_exposure_org_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.board_portal_exposure
    ADD CONSTRAINT board_portal_exposure_org_id_fkey FOREIGN KEY (org_id) REFERENCES public.orgs(id) ON DELETE CASCADE;


--
-- Name: board_status_transitions board_status_transitions_board_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.board_status_transitions
    ADD CONSTRAINT board_status_transitions_board_id_fkey FOREIGN KEY (board_id) REFERENCES public.boards(id) ON DELETE CASCADE;


--
-- Name: board_status_transitions board_status_transitions_from_status_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.board_status_transitions
    ADD CONSTRAINT board_status_transitions_from_status_id_fkey FOREIGN KEY (from_status_id) REFERENCES public.board_statuses(id) ON DELETE CASCADE;


--
-- Name: board_status_transitions board_status_transitions_org_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.board_status_transitions
    ADD CONSTRAINT board_status_transitions_org_id_fkey FOREIGN KEY (org_id) REFERENCES public.orgs(id) ON DELETE CASCADE;


--
-- Name: board_status_transitions board_status_transitions_to_status_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.board_status_transitions
    ADD CONSTRAINT board_status_transitions_to_status_id_fkey FOREIGN KEY (to_status_id) REFERENCES public.board_statuses(id) ON DELETE CASCADE;


--
-- Name: board_statuses board_statuses_board_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.board_statuses
    ADD CONSTRAINT board_statuses_board_id_fkey FOREIGN KEY (board_id) REFERENCES public.boards(id) ON DELETE CASCADE;


--
-- Name: board_statuses board_statuses_org_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.board_statuses
    ADD CONSTRAINT board_statuses_org_id_fkey FOREIGN KEY (org_id) REFERENCES public.orgs(id) ON DELETE CASCADE;


--
-- Name: board_status_transitions board_transitions_from_same_board; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.board_status_transitions
    ADD CONSTRAINT board_transitions_from_same_board FOREIGN KEY (board_id, from_status_id) REFERENCES public.board_statuses(board_id, id) ON DELETE CASCADE;


--
-- Name: board_status_transitions board_transitions_to_same_board; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.board_status_transitions
    ADD CONSTRAINT board_transitions_to_same_board FOREIGN KEY (board_id, to_status_id) REFERENCES public.board_statuses(board_id, id) ON DELETE CASCADE;


--
-- Name: boards boards_board_group_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.boards
    ADD CONSTRAINT boards_board_group_id_fkey FOREIGN KEY (board_group_id) REFERENCES public.board_groups(id) ON DELETE SET NULL;


--
-- Name: boards boards_org_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.boards
    ADD CONSTRAINT boards_org_id_fkey FOREIGN KEY (org_id) REFERENCES public.orgs(id) ON DELETE CASCADE;


--
-- Name: byok_secrets byok_secrets_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.byok_secrets
    ADD CONSTRAINT byok_secrets_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: byok_secrets byok_secrets_org_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.byok_secrets
    ADD CONSTRAINT byok_secrets_org_id_fkey FOREIGN KEY (org_id) REFERENCES public.orgs(id) ON DELETE CASCADE;


--
-- Name: calendar_exclusions calendar_exclusions_org_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.calendar_exclusions
    ADD CONSTRAINT calendar_exclusions_org_id_fkey FOREIGN KEY (org_id) REFERENCES public.orgs(id) ON DELETE CASCADE;


--
-- Name: calendar_exclusions calendar_exclusions_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.calendar_exclusions
    ADD CONSTRAINT calendar_exclusions_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: checklist_items checklist_items_checked_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.checklist_items
    ADD CONSTRAINT checklist_items_checked_by_fkey FOREIGN KEY (checked_by) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: checklist_items checklist_items_org_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.checklist_items
    ADD CONSTRAINT checklist_items_org_id_fkey FOREIGN KEY (org_id) REFERENCES public.orgs(id) ON DELETE CASCADE;


--
-- Name: checklist_items checklist_items_template_item_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.checklist_items
    ADD CONSTRAINT checklist_items_template_item_id_fkey FOREIGN KEY (template_item_id) REFERENCES public.checklist_template_items(id) ON DELETE SET NULL;


--
-- Name: checklist_items checklist_items_ticket_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.checklist_items
    ADD CONSTRAINT checklist_items_ticket_id_fkey FOREIGN KEY (ticket_id) REFERENCES public.tickets(id) ON DELETE CASCADE;


--
-- Name: checklist_template_items checklist_template_items_org_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.checklist_template_items
    ADD CONSTRAINT checklist_template_items_org_id_fkey FOREIGN KEY (org_id) REFERENCES public.orgs(id) ON DELETE CASCADE;


--
-- Name: checklist_template_items checklist_template_items_template_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.checklist_template_items
    ADD CONSTRAINT checklist_template_items_template_id_fkey FOREIGN KEY (template_id) REFERENCES public.board_checklist_templates(id) ON DELETE CASCADE;


--
-- Name: clients clients_org_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.clients
    ADD CONSTRAINT clients_org_id_fkey FOREIGN KEY (org_id) REFERENCES public.orgs(id) ON DELETE CASCADE;


--
-- Name: connector_installations connector_installations_consented_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.connector_installations
    ADD CONSTRAINT connector_installations_consented_by_fkey FOREIGN KEY (consented_by) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: connector_installations connector_installations_org_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.connector_installations
    ADD CONSTRAINT connector_installations_org_id_fkey FOREIGN KEY (org_id) REFERENCES public.orgs(id) ON DELETE CASCADE;


--
-- Name: contacts contacts_client_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.contacts
    ADD CONSTRAINT contacts_client_id_fkey FOREIGN KEY (client_id) REFERENCES public.clients(id) ON DELETE CASCADE;


--
-- Name: contacts contacts_org_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.contacts
    ADD CONSTRAINT contacts_org_id_fkey FOREIGN KEY (org_id) REFERENCES public.orgs(id) ON DELETE CASCADE;


--
-- Name: contacts contacts_site_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.contacts
    ADD CONSTRAINT contacts_site_id_fkey FOREIGN KEY (site_id) REFERENCES public.sites(id) ON DELETE SET NULL;


--
-- Name: contract_fixed_fees contract_fixed_fees_contract_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.contract_fixed_fees
    ADD CONSTRAINT contract_fixed_fees_contract_id_fkey FOREIGN KEY (contract_id) REFERENCES public.contracts(id) ON DELETE CASCADE;


--
-- Name: contract_fixed_fees contract_fixed_fees_org_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.contract_fixed_fees
    ADD CONSTRAINT contract_fixed_fees_org_id_fkey FOREIGN KEY (org_id) REFERENCES public.orgs(id) ON DELETE CASCADE;


--
-- Name: contract_rates contract_rates_contract_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.contract_rates
    ADD CONSTRAINT contract_rates_contract_id_fkey FOREIGN KEY (contract_id) REFERENCES public.contracts(id) ON DELETE CASCADE;


--
-- Name: contract_rates contract_rates_org_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.contract_rates
    ADD CONSTRAINT contract_rates_org_id_fkey FOREIGN KEY (org_id) REFERENCES public.orgs(id) ON DELETE CASCADE;


--
-- Name: contracts contracts_client_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.contracts
    ADD CONSTRAINT contracts_client_id_fkey FOREIGN KEY (client_id) REFERENCES public.clients(id) ON DELETE CASCADE;


--
-- Name: contracts contracts_org_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.contracts
    ADD CONSTRAINT contracts_org_id_fkey FOREIGN KEY (org_id) REFERENCES public.orgs(id) ON DELETE CASCADE;


--
-- Name: custom_field_defs custom_field_defs_board_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.custom_field_defs
    ADD CONSTRAINT custom_field_defs_board_id_fkey FOREIGN KEY (board_id) REFERENCES public.boards(id) ON DELETE CASCADE;


--
-- Name: custom_field_defs custom_field_defs_org_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.custom_field_defs
    ADD CONSTRAINT custom_field_defs_org_id_fkey FOREIGN KEY (org_id) REFERENCES public.orgs(id) ON DELETE CASCADE;


--
-- Name: custom_field_values custom_field_values_field_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.custom_field_values
    ADD CONSTRAINT custom_field_values_field_id_fkey FOREIGN KEY (field_id) REFERENCES public.custom_field_defs(id) ON DELETE CASCADE;


--
-- Name: custom_field_values custom_field_values_org_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.custom_field_values
    ADD CONSTRAINT custom_field_values_org_id_fkey FOREIGN KEY (org_id) REFERENCES public.orgs(id) ON DELETE CASCADE;


--
-- Name: device_assets device_assets_client_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.device_assets
    ADD CONSTRAINT device_assets_client_id_fkey FOREIGN KEY (client_id) REFERENCES public.clients(id) ON DELETE CASCADE;


--
-- Name: device_assets device_assets_org_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.device_assets
    ADD CONSTRAINT device_assets_org_id_fkey FOREIGN KEY (org_id) REFERENCES public.orgs(id) ON DELETE CASCADE;


--
-- Name: device_assets device_assets_site_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.device_assets
    ADD CONSTRAINT device_assets_site_id_fkey FOREIGN KEY (site_id) REFERENCES public.sites(id) ON DELETE SET NULL;


--
-- Name: dispatch_queue_entries dispatch_queue_entries_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dispatch_queue_entries
    ADD CONSTRAINT dispatch_queue_entries_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.users(id);


--
-- Name: dispatch_queue_entries dispatch_queue_entries_org_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dispatch_queue_entries
    ADD CONSTRAINT dispatch_queue_entries_org_id_fkey FOREIGN KEY (org_id) REFERENCES public.orgs(id) ON DELETE CASCADE;


--
-- Name: dispatch_queue_entries dispatch_queue_entries_ticket_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dispatch_queue_entries
    ADD CONSTRAINT dispatch_queue_entries_ticket_id_fkey FOREIGN KEY (ticket_id) REFERENCES public.tickets(id) ON DELETE CASCADE;


--
-- Name: dispatch_status_updates dispatch_status_updates_appointment_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dispatch_status_updates
    ADD CONSTRAINT dispatch_status_updates_appointment_id_fkey FOREIGN KEY (appointment_id) REFERENCES public.appointments(id) ON DELETE CASCADE;


--
-- Name: dispatch_status_updates dispatch_status_updates_org_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.dispatch_status_updates
    ADD CONSTRAINT dispatch_status_updates_org_id_fkey FOREIGN KEY (org_id) REFERENCES public.orgs(id) ON DELETE CASCADE;


--
-- Name: document_versions document_versions_author_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.document_versions
    ADD CONSTRAINT document_versions_author_id_fkey FOREIGN KEY (author_id) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: document_versions document_versions_document_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.document_versions
    ADD CONSTRAINT document_versions_document_id_fkey FOREIGN KEY (document_id) REFERENCES public.documents(id) ON DELETE CASCADE;


--
-- Name: document_versions document_versions_org_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.document_versions
    ADD CONSTRAINT document_versions_org_id_fkey FOREIGN KEY (org_id) REFERENCES public.orgs(id) ON DELETE CASCADE;


--
-- Name: documents documents_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.documents
    ADD CONSTRAINT documents_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: documents documents_org_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.documents
    ADD CONSTRAINT documents_org_id_fkey FOREIGN KEY (org_id) REFERENCES public.orgs(id) ON DELETE CASCADE;


--
-- Name: documents documents_updated_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.documents
    ADD CONSTRAINT documents_updated_by_fkey FOREIGN KEY (updated_by) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: email_inbound_settings email_inbound_settings_catchall_board_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.email_inbound_settings
    ADD CONSTRAINT email_inbound_settings_catchall_board_id_fkey FOREIGN KEY (catchall_board_id) REFERENCES public.boards(id) ON DELETE RESTRICT;


--
-- Name: email_inbound_settings email_inbound_settings_org_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.email_inbound_settings
    ADD CONSTRAINT email_inbound_settings_org_id_fkey FOREIGN KEY (org_id) REFERENCES public.orgs(id) ON DELETE CASCADE;


--
-- Name: email_messages email_messages_comment_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.email_messages
    ADD CONSTRAINT email_messages_comment_id_fkey FOREIGN KEY (comment_id) REFERENCES public.ticket_comments(id) ON DELETE SET NULL;


--
-- Name: email_messages email_messages_org_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.email_messages
    ADD CONSTRAINT email_messages_org_id_fkey FOREIGN KEY (org_id) REFERENCES public.orgs(id) ON DELETE CASCADE;


--
-- Name: email_messages email_messages_ticket_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.email_messages
    ADD CONSTRAINT email_messages_ticket_id_fkey FOREIGN KEY (ticket_id) REFERENCES public.tickets(id) ON DELETE SET NULL;


--
-- Name: email_outbound email_outbound_email_message_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.email_outbound
    ADD CONSTRAINT email_outbound_email_message_id_fkey FOREIGN KEY (email_message_id) REFERENCES public.email_messages(id) ON DELETE CASCADE;


--
-- Name: email_outbound email_outbound_org_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.email_outbound
    ADD CONSTRAINT email_outbound_org_id_fkey FOREIGN KEY (org_id) REFERENCES public.orgs(id) ON DELETE CASCADE;


--
-- Name: entity_write_seqs entity_write_seqs_org_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.entity_write_seqs
    ADD CONSTRAINT entity_write_seqs_org_id_fkey FOREIGN KEY (org_id) REFERENCES public.orgs(id) ON DELETE CASCADE;


--
-- Name: entity_writes entity_writes_org_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.entity_writes
    ADD CONSTRAINT entity_writes_org_id_fkey FOREIGN KEY (org_id) REFERENCES public.orgs(id) ON DELETE CASCADE;


--
-- Name: external_ids external_ids_last_seen_batch_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.external_ids
    ADD CONSTRAINT external_ids_last_seen_batch_fkey FOREIGN KEY (last_seen_batch) REFERENCES public.import_batches(id) ON DELETE SET NULL;


--
-- Name: external_ids external_ids_org_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.external_ids
    ADD CONSTRAINT external_ids_org_id_fkey FOREIGN KEY (org_id) REFERENCES public.orgs(id) ON DELETE CASCADE;


--
-- Name: idempotency_keys idempotency_keys_org_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.idempotency_keys
    ADD CONSTRAINT idempotency_keys_org_id_fkey FOREIGN KEY (org_id) REFERENCES public.orgs(id) ON DELETE CASCADE;


--
-- Name: import_batches import_batches_org_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.import_batches
    ADD CONSTRAINT import_batches_org_id_fkey FOREIGN KEY (org_id) REFERENCES public.orgs(id) ON DELETE CASCADE;


--
-- Name: import_mapping_templates import_mapping_templates_org_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.import_mapping_templates
    ADD CONSTRAINT import_mapping_templates_org_id_fkey FOREIGN KEY (org_id) REFERENCES public.orgs(id) ON DELETE CASCADE;


--
-- Name: invoice_lines invoice_lines_contract_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.invoice_lines
    ADD CONSTRAINT invoice_lines_contract_id_fkey FOREIGN KEY (contract_id) REFERENCES public.contracts(id) ON DELETE RESTRICT;


--
-- Name: invoice_lines invoice_lines_invoice_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.invoice_lines
    ADD CONSTRAINT invoice_lines_invoice_id_fkey FOREIGN KEY (invoice_id) REFERENCES public.invoices(id) ON DELETE CASCADE;


--
-- Name: invoice_lines invoice_lines_org_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.invoice_lines
    ADD CONSTRAINT invoice_lines_org_id_fkey FOREIGN KEY (org_id) REFERENCES public.orgs(id) ON DELETE CASCADE;


--
-- Name: invoice_payments invoice_payments_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.invoice_payments
    ADD CONSTRAINT invoice_payments_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: invoice_payments invoice_payments_invoice_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.invoice_payments
    ADD CONSTRAINT invoice_payments_invoice_id_fkey FOREIGN KEY (invoice_id) REFERENCES public.invoices(id) ON DELETE RESTRICT;


--
-- Name: invoice_payments invoice_payments_org_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.invoice_payments
    ADD CONSTRAINT invoice_payments_org_id_fkey FOREIGN KEY (org_id) REFERENCES public.orgs(id) ON DELETE CASCADE;


--
-- Name: invoice_runs invoice_runs_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.invoice_runs
    ADD CONSTRAINT invoice_runs_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: invoice_runs invoice_runs_org_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.invoice_runs
    ADD CONSTRAINT invoice_runs_org_id_fkey FOREIGN KEY (org_id) REFERENCES public.orgs(id) ON DELETE CASCADE;


--
-- Name: invoice_time_entries invoice_time_entries_invoice_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.invoice_time_entries
    ADD CONSTRAINT invoice_time_entries_invoice_id_fkey FOREIGN KEY (invoice_id) REFERENCES public.invoices(id) ON DELETE CASCADE;


--
-- Name: invoice_time_entries invoice_time_entries_org_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.invoice_time_entries
    ADD CONSTRAINT invoice_time_entries_org_id_fkey FOREIGN KEY (org_id) REFERENCES public.orgs(id) ON DELETE CASCADE;


--
-- Name: invoice_time_entries invoice_time_entries_time_entry_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.invoice_time_entries
    ADD CONSTRAINT invoice_time_entries_time_entry_id_fkey FOREIGN KEY (time_entry_id) REFERENCES public.time_entries(id) ON DELETE RESTRICT;


--
-- Name: invoices invoices_client_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.invoices
    ADD CONSTRAINT invoices_client_id_fkey FOREIGN KEY (client_id) REFERENCES public.clients(id) ON DELETE RESTRICT;


--
-- Name: invoices invoices_contract_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.invoices
    ADD CONSTRAINT invoices_contract_id_fkey FOREIGN KEY (contract_id) REFERENCES public.contracts(id) ON DELETE RESTRICT;


--
-- Name: invoices invoices_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.invoices
    ADD CONSTRAINT invoices_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: invoices invoices_org_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.invoices
    ADD CONSTRAINT invoices_org_id_fkey FOREIGN KEY (org_id) REFERENCES public.orgs(id) ON DELETE CASCADE;


--
-- Name: invoices invoices_run_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.invoices
    ADD CONSTRAINT invoices_run_id_fkey FOREIGN KEY (run_id) REFERENCES public.invoice_runs(id) ON DELETE SET NULL;


--
-- Name: jobs jobs_org_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.jobs
    ADD CONSTRAINT jobs_org_id_fkey FOREIGN KEY (org_id) REFERENCES public.orgs(id) ON DELETE CASCADE;


--
-- Name: kb_articles kb_articles_category_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.kb_articles
    ADD CONSTRAINT kb_articles_category_id_fkey FOREIGN KEY (category_id) REFERENCES public.kb_categories(id) ON DELETE SET NULL;


--
-- Name: kb_articles kb_articles_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.kb_articles
    ADD CONSTRAINT kb_articles_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: kb_articles kb_articles_org_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.kb_articles
    ADD CONSTRAINT kb_articles_org_id_fkey FOREIGN KEY (org_id) REFERENCES public.orgs(id) ON DELETE CASCADE;


--
-- Name: kb_articles kb_articles_updated_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.kb_articles
    ADD CONSTRAINT kb_articles_updated_by_fkey FOREIGN KEY (updated_by) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: kb_categories kb_categories_org_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.kb_categories
    ADD CONSTRAINT kb_categories_org_id_fkey FOREIGN KEY (org_id) REFERENCES public.orgs(id) ON DELETE CASCADE;


--
-- Name: mcp_capability_grants mcp_capability_grants_granted_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.mcp_capability_grants
    ADD CONSTRAINT mcp_capability_grants_granted_by_fkey FOREIGN KEY (granted_by) REFERENCES public.users(id);


--
-- Name: mcp_capability_grants mcp_capability_grants_org_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.mcp_capability_grants
    ADD CONSTRAINT mcp_capability_grants_org_id_fkey FOREIGN KEY (org_id) REFERENCES public.orgs(id) ON DELETE CASCADE;


--
-- Name: mfa_challenges mfa_challenges_org_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.mfa_challenges
    ADD CONSTRAINT mfa_challenges_org_id_fkey FOREIGN KEY (org_id) REFERENCES public.orgs(id) ON DELETE CASCADE;


--
-- Name: mfa_challenges mfa_challenges_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.mfa_challenges
    ADD CONSTRAINT mfa_challenges_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: migration_push_chunks migration_push_chunks_org_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.migration_push_chunks
    ADD CONSTRAINT migration_push_chunks_org_id_fkey FOREIGN KEY (org_id) REFERENCES public.orgs(id) ON DELETE CASCADE;


--
-- Name: migration_push_chunks migration_push_chunks_session_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.migration_push_chunks
    ADD CONSTRAINT migration_push_chunks_session_id_fkey FOREIGN KEY (session_id) REFERENCES public.migration_push_sessions(id) ON DELETE CASCADE;


--
-- Name: migration_push_sessions migration_push_sessions_batch_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.migration_push_sessions
    ADD CONSTRAINT migration_push_sessions_batch_id_fkey FOREIGN KEY (batch_id) REFERENCES public.import_batches(id) ON DELETE CASCADE;


--
-- Name: migration_push_sessions migration_push_sessions_org_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.migration_push_sessions
    ADD CONSTRAINT migration_push_sessions_org_id_fkey FOREIGN KEY (org_id) REFERENCES public.orgs(id) ON DELETE CASCADE;


--
-- Name: notification_org_defaults notification_org_defaults_org_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.notification_org_defaults
    ADD CONSTRAINT notification_org_defaults_org_id_fkey FOREIGN KEY (org_id) REFERENCES public.orgs(id) ON DELETE CASCADE;


--
-- Name: notification_preferences notification_preferences_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.notification_preferences
    ADD CONSTRAINT notification_preferences_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: notifications notifications_org_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.notifications
    ADD CONSTRAINT notifications_org_id_fkey FOREIGN KEY (org_id) REFERENCES public.orgs(id) ON DELETE CASCADE;


--
-- Name: notifications notifications_ticket_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.notifications
    ADD CONSTRAINT notifications_ticket_id_fkey FOREIGN KEY (ticket_id) REFERENCES public.tickets(id) ON DELETE CASCADE;


--
-- Name: notifications notifications_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.notifications
    ADD CONSTRAINT notifications_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: oidc_accounts oidc_accounts_linked_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.oidc_accounts
    ADD CONSTRAINT oidc_accounts_linked_by_fkey FOREIGN KEY (linked_by) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: oidc_accounts oidc_accounts_org_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.oidc_accounts
    ADD CONSTRAINT oidc_accounts_org_id_fkey FOREIGN KEY (org_id) REFERENCES public.orgs(id) ON DELETE CASCADE;


--
-- Name: oidc_accounts oidc_accounts_provider_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.oidc_accounts
    ADD CONSTRAINT oidc_accounts_provider_id_fkey FOREIGN KEY (provider_id) REFERENCES public.oidc_providers(id) ON DELETE CASCADE;


--
-- Name: oidc_accounts oidc_accounts_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.oidc_accounts
    ADD CONSTRAINT oidc_accounts_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: oidc_providers oidc_providers_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.oidc_providers
    ADD CONSTRAINT oidc_providers_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: oidc_providers oidc_providers_org_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.oidc_providers
    ADD CONSTRAINT oidc_providers_org_id_fkey FOREIGN KEY (org_id) REFERENCES public.orgs(id) ON DELETE CASCADE;


--
-- Name: on_call_blocks on_call_blocks_org_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.on_call_blocks
    ADD CONSTRAINT on_call_blocks_org_id_fkey FOREIGN KEY (org_id) REFERENCES public.orgs(id) ON DELETE CASCADE;


--
-- Name: on_call_blocks on_call_blocks_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.on_call_blocks
    ADD CONSTRAINT on_call_blocks_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: outbox_events outbox_events_org_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.outbox_events
    ADD CONSTRAINT outbox_events_org_id_fkey FOREIGN KEY (org_id) REFERENCES public.orgs(id) ON DELETE CASCADE;


--
-- Name: portal_appointment_requests portal_appointment_requests_appointment_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.portal_appointment_requests
    ADD CONSTRAINT portal_appointment_requests_appointment_id_fkey FOREIGN KEY (appointment_id) REFERENCES public.appointments(id) ON DELETE SET NULL;


--
-- Name: portal_appointment_requests portal_appointment_requests_client_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.portal_appointment_requests
    ADD CONSTRAINT portal_appointment_requests_client_id_fkey FOREIGN KEY (client_id) REFERENCES public.clients(id) ON DELETE CASCADE;


--
-- Name: portal_appointment_requests portal_appointment_requests_decided_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.portal_appointment_requests
    ADD CONSTRAINT portal_appointment_requests_decided_by_fkey FOREIGN KEY (decided_by) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: portal_appointment_requests portal_appointment_requests_org_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.portal_appointment_requests
    ADD CONSTRAINT portal_appointment_requests_org_id_fkey FOREIGN KEY (org_id) REFERENCES public.orgs(id) ON DELETE CASCADE;


--
-- Name: portal_appointment_requests portal_appointment_requests_portal_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.portal_appointment_requests
    ADD CONSTRAINT portal_appointment_requests_portal_user_id_fkey FOREIGN KEY (portal_user_id) REFERENCES public.portal_users(id) ON DELETE CASCADE;


--
-- Name: portal_appointment_requests portal_appointment_requests_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.portal_appointment_requests
    ADD CONSTRAINT portal_appointment_requests_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: portal_sessions portal_sessions_org_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.portal_sessions
    ADD CONSTRAINT portal_sessions_org_id_fkey FOREIGN KEY (org_id) REFERENCES public.orgs(id) ON DELETE CASCADE;


--
-- Name: portal_sessions portal_sessions_portal_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.portal_sessions
    ADD CONSTRAINT portal_sessions_portal_user_id_fkey FOREIGN KEY (portal_user_id) REFERENCES public.portal_users(id) ON DELETE CASCADE;


--
-- Name: portal_users portal_users_client_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.portal_users
    ADD CONSTRAINT portal_users_client_id_fkey FOREIGN KEY (client_id) REFERENCES public.clients(id) ON DELETE CASCADE;


--
-- Name: portal_users portal_users_org_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.portal_users
    ADD CONSTRAINT portal_users_org_id_fkey FOREIGN KEY (org_id) REFERENCES public.orgs(id) ON DELETE CASCADE;


--
-- Name: project_phases project_phases_org_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.project_phases
    ADD CONSTRAINT project_phases_org_id_fkey FOREIGN KEY (org_id) REFERENCES public.orgs(id) ON DELETE CASCADE;


--
-- Name: project_phases project_phases_project_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.project_phases
    ADD CONSTRAINT project_phases_project_id_fkey FOREIGN KEY (project_id) REFERENCES public.projects(id) ON DELETE CASCADE;


--
-- Name: project_task_deps project_task_deps_depends_on_task_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.project_task_deps
    ADD CONSTRAINT project_task_deps_depends_on_task_id_fkey FOREIGN KEY (depends_on_task_id) REFERENCES public.project_tasks(id) ON DELETE CASCADE;


--
-- Name: project_task_deps project_task_deps_org_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.project_task_deps
    ADD CONSTRAINT project_task_deps_org_id_fkey FOREIGN KEY (org_id) REFERENCES public.orgs(id) ON DELETE CASCADE;


--
-- Name: project_task_deps project_task_deps_task_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.project_task_deps
    ADD CONSTRAINT project_task_deps_task_id_fkey FOREIGN KEY (task_id) REFERENCES public.project_tasks(id) ON DELETE CASCADE;


--
-- Name: project_tasks project_tasks_assignee_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.project_tasks
    ADD CONSTRAINT project_tasks_assignee_id_fkey FOREIGN KEY (assignee_id) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: project_tasks project_tasks_org_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.project_tasks
    ADD CONSTRAINT project_tasks_org_id_fkey FOREIGN KEY (org_id) REFERENCES public.orgs(id) ON DELETE CASCADE;


--
-- Name: project_tasks project_tasks_phase_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.project_tasks
    ADD CONSTRAINT project_tasks_phase_id_fkey FOREIGN KEY (phase_id) REFERENCES public.project_phases(id) ON DELETE SET NULL;


--
-- Name: project_tasks project_tasks_project_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.project_tasks
    ADD CONSTRAINT project_tasks_project_id_fkey FOREIGN KEY (project_id) REFERENCES public.projects(id) ON DELETE CASCADE;


--
-- Name: project_templates project_templates_org_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.project_templates
    ADD CONSTRAINT project_templates_org_id_fkey FOREIGN KEY (org_id) REFERENCES public.orgs(id) ON DELETE CASCADE;


--
-- Name: project_views project_views_org_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.project_views
    ADD CONSTRAINT project_views_org_id_fkey FOREIGN KEY (org_id) REFERENCES public.orgs(id) ON DELETE CASCADE;


--
-- Name: project_views project_views_project_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.project_views
    ADD CONSTRAINT project_views_project_id_fkey FOREIGN KEY (project_id) REFERENCES public.projects(id) ON DELETE CASCADE;


--
-- Name: projects projects_client_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.projects
    ADD CONSTRAINT projects_client_id_fkey FOREIGN KEY (client_id) REFERENCES public.clients(id) ON DELETE SET NULL;


--
-- Name: projects projects_org_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.projects
    ADD CONSTRAINT projects_org_id_fkey FOREIGN KEY (org_id) REFERENCES public.orgs(id) ON DELETE CASCADE;


--
-- Name: provenance_events provenance_events_org_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.provenance_events
    ADD CONSTRAINT provenance_events_org_id_fkey FOREIGN KEY (org_id) REFERENCES public.orgs(id) ON DELETE CASCADE;


--
-- Name: recovery_codes recovery_codes_org_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.recovery_codes
    ADD CONSTRAINT recovery_codes_org_id_fkey FOREIGN KEY (org_id) REFERENCES public.orgs(id) ON DELETE CASCADE;


--
-- Name: recovery_codes recovery_codes_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.recovery_codes
    ADD CONSTRAINT recovery_codes_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: report_definitions report_definitions_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.report_definitions
    ADD CONSTRAINT report_definitions_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.users(id);


--
-- Name: report_definitions report_definitions_org_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.report_definitions
    ADD CONSTRAINT report_definitions_org_id_fkey FOREIGN KEY (org_id) REFERENCES public.orgs(id) ON DELETE CASCADE;


--
-- Name: report_deliveries report_deliveries_org_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.report_deliveries
    ADD CONSTRAINT report_deliveries_org_id_fkey FOREIGN KEY (org_id) REFERENCES public.orgs(id) ON DELETE CASCADE;


--
-- Name: report_deliveries report_deliveries_schedule_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.report_deliveries
    ADD CONSTRAINT report_deliveries_schedule_id_fkey FOREIGN KEY (schedule_id) REFERENCES public.report_schedules(id) ON DELETE CASCADE;


--
-- Name: report_schedules report_schedules_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.report_schedules
    ADD CONSTRAINT report_schedules_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.users(id);


--
-- Name: report_schedules report_schedules_org_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.report_schedules
    ADD CONSTRAINT report_schedules_org_id_fkey FOREIGN KEY (org_id) REFERENCES public.orgs(id) ON DELETE CASCADE;


--
-- Name: report_schedules report_schedules_report_definition_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.report_schedules
    ADD CONSTRAINT report_schedules_report_definition_id_fkey FOREIGN KEY (report_definition_id) REFERENCES public.report_definitions(id) ON DELETE CASCADE;


--
-- Name: roles roles_org_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.roles
    ADD CONSTRAINT roles_org_id_fkey FOREIGN KEY (org_id) REFERENCES public.orgs(id) ON DELETE CASCADE;


--
-- Name: search_index search_index_org_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.search_index
    ADD CONSTRAINT search_index_org_id_fkey FOREIGN KEY (org_id) REFERENCES public.orgs(id) ON DELETE CASCADE;


--
-- Name: settings settings_org_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.settings
    ADD CONSTRAINT settings_org_id_fkey FOREIGN KEY (org_id) REFERENCES public.orgs(id) ON DELETE CASCADE;


--
-- Name: settings settings_updated_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.settings
    ADD CONSTRAINT settings_updated_by_fkey FOREIGN KEY (updated_by) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: sites sites_client_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sites
    ADD CONSTRAINT sites_client_id_fkey FOREIGN KEY (client_id) REFERENCES public.clients(id) ON DELETE CASCADE;


--
-- Name: sites sites_org_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sites
    ADD CONSTRAINT sites_org_id_fkey FOREIGN KEY (org_id) REFERENCES public.orgs(id) ON DELETE CASCADE;


--
-- Name: sla_calendars sla_calendars_org_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sla_calendars
    ADD CONSTRAINT sla_calendars_org_id_fkey FOREIGN KEY (org_id) REFERENCES public.orgs(id) ON DELETE CASCADE;


--
-- Name: sla_escalation_steps sla_escalation_steps_org_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sla_escalation_steps
    ADD CONSTRAINT sla_escalation_steps_org_id_fkey FOREIGN KEY (org_id) REFERENCES public.orgs(id) ON DELETE CASCADE;


--
-- Name: sla_escalation_steps sla_escalation_steps_policy_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sla_escalation_steps
    ADD CONSTRAINT sla_escalation_steps_policy_id_fkey FOREIGN KEY (policy_id) REFERENCES public.sla_policies(id) ON DELETE CASCADE;


--
-- Name: sla_fired_escalations sla_fired_escalations_org_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sla_fired_escalations
    ADD CONSTRAINT sla_fired_escalations_org_id_fkey FOREIGN KEY (org_id) REFERENCES public.orgs(id) ON DELETE CASCADE;


--
-- Name: sla_fired_escalations sla_fired_escalations_step_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sla_fired_escalations
    ADD CONSTRAINT sla_fired_escalations_step_id_fkey FOREIGN KEY (step_id) REFERENCES public.sla_escalation_steps(id) ON DELETE CASCADE;


--
-- Name: sla_fired_escalations sla_fired_escalations_ticket_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sla_fired_escalations
    ADD CONSTRAINT sla_fired_escalations_ticket_id_fkey FOREIGN KEY (ticket_id) REFERENCES public.tickets(id) ON DELETE CASCADE;


--
-- Name: sla_policies sla_policies_calendar_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sla_policies
    ADD CONSTRAINT sla_policies_calendar_id_fkey FOREIGN KEY (calendar_id) REFERENCES public.sla_calendars(id) ON DELETE SET NULL;


--
-- Name: sla_policies sla_policies_org_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.sla_policies
    ADD CONSTRAINT sla_policies_org_id_fkey FOREIGN KEY (org_id) REFERENCES public.orgs(id) ON DELETE CASCADE;


--
-- Name: ticket_comments ticket_comments_author_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ticket_comments
    ADD CONSTRAINT ticket_comments_author_id_fkey FOREIGN KEY (author_id) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: ticket_comments ticket_comments_org_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ticket_comments
    ADD CONSTRAINT ticket_comments_org_id_fkey FOREIGN KEY (org_id) REFERENCES public.orgs(id) ON DELETE CASCADE;


--
-- Name: ticket_comments ticket_comments_ticket_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ticket_comments
    ADD CONSTRAINT ticket_comments_ticket_id_fkey FOREIGN KEY (ticket_id) REFERENCES public.tickets(id) ON DELETE CASCADE;


--
-- Name: ticket_required_skills ticket_required_skills_org_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ticket_required_skills
    ADD CONSTRAINT ticket_required_skills_org_id_fkey FOREIGN KEY (org_id) REFERENCES public.orgs(id) ON DELETE CASCADE;


--
-- Name: ticket_required_skills ticket_required_skills_ticket_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ticket_required_skills
    ADD CONSTRAINT ticket_required_skills_ticket_id_fkey FOREIGN KEY (ticket_id) REFERENCES public.tickets(id) ON DELETE CASCADE;


--
-- Name: ticket_sla_state ticket_sla_state_org_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ticket_sla_state
    ADD CONSTRAINT ticket_sla_state_org_id_fkey FOREIGN KEY (org_id) REFERENCES public.orgs(id) ON DELETE CASCADE;


--
-- Name: ticket_sla_state ticket_sla_state_policy_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ticket_sla_state
    ADD CONSTRAINT ticket_sla_state_policy_id_fkey FOREIGN KEY (policy_id) REFERENCES public.sla_policies(id) ON DELETE RESTRICT;


--
-- Name: ticket_sla_state ticket_sla_state_ticket_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ticket_sla_state
    ADD CONSTRAINT ticket_sla_state_ticket_id_fkey FOREIGN KEY (ticket_id) REFERENCES public.tickets(id) ON DELETE CASCADE;


--
-- Name: tickets tickets_assignee_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tickets
    ADD CONSTRAINT tickets_assignee_id_fkey FOREIGN KEY (assignee_id) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: tickets tickets_board_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tickets
    ADD CONSTRAINT tickets_board_id_fkey FOREIGN KEY (board_id) REFERENCES public.boards(id) ON DELETE RESTRICT;


--
-- Name: tickets tickets_client_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tickets
    ADD CONSTRAINT tickets_client_id_fkey FOREIGN KEY (client_id) REFERENCES public.clients(id) ON DELETE SET NULL;


--
-- Name: tickets tickets_contact_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tickets
    ADD CONSTRAINT tickets_contact_id_fkey FOREIGN KEY (contact_id) REFERENCES public.contacts(id) ON DELETE SET NULL;


--
-- Name: tickets tickets_org_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tickets
    ADD CONSTRAINT tickets_org_id_fkey FOREIGN KEY (org_id) REFERENCES public.orgs(id) ON DELETE CASCADE;


--
-- Name: tickets tickets_requester_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tickets
    ADD CONSTRAINT tickets_requester_id_fkey FOREIGN KEY (requester_id) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: tickets tickets_site_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tickets
    ADD CONSTRAINT tickets_site_id_fkey FOREIGN KEY (site_id) REFERENCES public.sites(id) ON DELETE SET NULL;


--
-- Name: tickets tickets_status_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tickets
    ADD CONSTRAINT tickets_status_id_fkey FOREIGN KEY (status_id) REFERENCES public.board_statuses(id) ON DELETE RESTRICT;


--
-- Name: time_entries time_entries_org_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.time_entries
    ADD CONSTRAINT time_entries_org_id_fkey FOREIGN KEY (org_id) REFERENCES public.orgs(id) ON DELETE CASCADE;


--
-- Name: time_entries time_entries_ticket_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.time_entries
    ADD CONSTRAINT time_entries_ticket_id_fkey FOREIGN KEY (ticket_id) REFERENCES public.tickets(id) ON DELETE CASCADE;


--
-- Name: time_entries time_entries_timer_session_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.time_entries
    ADD CONSTRAINT time_entries_timer_session_id_fkey FOREIGN KEY (timer_session_id) REFERENCES public.timer_sessions(id) ON DELETE SET NULL;


--
-- Name: time_entries time_entries_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.time_entries
    ADD CONSTRAINT time_entries_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: time_gap_audits time_gap_audits_org_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.time_gap_audits
    ADD CONSTRAINT time_gap_audits_org_id_fkey FOREIGN KEY (org_id) REFERENCES public.orgs(id) ON DELETE CASCADE;


--
-- Name: time_gap_audits time_gap_audits_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.time_gap_audits
    ADD CONSTRAINT time_gap_audits_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: timer_sessions timer_sessions_org_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.timer_sessions
    ADD CONSTRAINT timer_sessions_org_id_fkey FOREIGN KEY (org_id) REFERENCES public.orgs(id) ON DELETE CASCADE;


--
-- Name: timer_sessions timer_sessions_ticket_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.timer_sessions
    ADD CONSTRAINT timer_sessions_ticket_id_fkey FOREIGN KEY (ticket_id) REFERENCES public.tickets(id) ON DELETE CASCADE;


--
-- Name: timer_sessions timer_sessions_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.timer_sessions
    ADD CONSTRAINT timer_sessions_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: totp_secrets totp_secrets_org_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.totp_secrets
    ADD CONSTRAINT totp_secrets_org_id_fkey FOREIGN KEY (org_id) REFERENCES public.orgs(id) ON DELETE CASCADE;


--
-- Name: totp_secrets totp_secrets_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.totp_secrets
    ADD CONSTRAINT totp_secrets_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: travel_entry_drafts travel_entry_drafts_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.travel_entry_drafts
    ADD CONSTRAINT travel_entry_drafts_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.users(id);


--
-- Name: travel_entry_drafts travel_entry_drafts_org_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.travel_entry_drafts
    ADD CONSTRAINT travel_entry_drafts_org_id_fkey FOREIGN KEY (org_id) REFERENCES public.orgs(id) ON DELETE CASCADE;


--
-- Name: travel_entry_drafts travel_entry_drafts_ticket_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.travel_entry_drafts
    ADD CONSTRAINT travel_entry_drafts_ticket_id_fkey FOREIGN KEY (ticket_id) REFERENCES public.tickets(id) ON DELETE CASCADE;


--
-- Name: travel_entry_drafts travel_entry_drafts_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.travel_entry_drafts
    ADD CONSTRAINT travel_entry_drafts_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: user_roles user_roles_role_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_roles
    ADD CONSTRAINT user_roles_role_id_fkey FOREIGN KEY (role_id) REFERENCES public.roles(id) ON DELETE CASCADE;


--
-- Name: user_roles user_roles_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_roles
    ADD CONSTRAINT user_roles_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: user_skills user_skills_org_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_skills
    ADD CONSTRAINT user_skills_org_id_fkey FOREIGN KEY (org_id) REFERENCES public.orgs(id) ON DELETE CASCADE;


--
-- Name: user_skills user_skills_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.user_skills
    ADD CONSTRAINT user_skills_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: users users_org_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_org_id_fkey FOREIGN KEY (org_id) REFERENCES public.orgs(id) ON DELETE CASCADE;


--
-- Name: webauthn_credentials webauthn_credentials_org_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.webauthn_credentials
    ADD CONSTRAINT webauthn_credentials_org_id_fkey FOREIGN KEY (org_id) REFERENCES public.orgs(id) ON DELETE CASCADE;


--
-- Name: webauthn_credentials webauthn_credentials_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.webauthn_credentials
    ADD CONSTRAINT webauthn_credentials_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: webhook_deliveries webhook_deliveries_org_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.webhook_deliveries
    ADD CONSTRAINT webhook_deliveries_org_id_fkey FOREIGN KEY (org_id) REFERENCES public.orgs(id) ON DELETE CASCADE;


--
-- Name: webhook_deliveries webhook_deliveries_webhook_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.webhook_deliveries
    ADD CONSTRAINT webhook_deliveries_webhook_id_fkey FOREIGN KEY (webhook_id) REFERENCES public.webhooks(id) ON DELETE CASCADE;


--
-- Name: webhooks webhooks_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.webhooks
    ADD CONSTRAINT webhooks_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.users(id) ON DELETE SET NULL;


--
-- Name: webhooks webhooks_org_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.webhooks
    ADD CONSTRAINT webhooks_org_id_fkey FOREIGN KEY (org_id) REFERENCES public.orgs(id) ON DELETE CASCADE;


--
-- Name: agent_proposals; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.agent_proposals ENABLE ROW LEVEL SECURITY;

--
-- Name: agent_proposals agent_proposals_org; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY agent_proposals_org ON public.agent_proposals USING ((org_id = (current_setting('app.org_id'::text, true))::uuid));


--
-- Name: agent_skills; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.agent_skills ENABLE ROW LEVEL SECURITY;

--
-- Name: agent_skills agent_skills_org; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY agent_skills_org ON public.agent_skills USING ((org_id = (current_setting('app.org_id'::text, true))::uuid));


--
-- Name: alert_incidents; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.alert_incidents ENABLE ROW LEVEL SECURITY;

--
-- Name: alert_incidents alert_incidents_org; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY alert_incidents_org ON public.alert_incidents USING ((org_id = (NULLIF(current_setting('app.org_id'::text, true), ''::text))::uuid));


--
-- Name: alert_sources; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.alert_sources ENABLE ROW LEVEL SECURITY;

--
-- Name: alert_sources alert_sources_org; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY alert_sources_org ON public.alert_sources USING ((org_id = (NULLIF(current_setting('app.org_id'::text, true), ''::text))::uuid));


--
-- Name: alerts; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.alerts ENABLE ROW LEVEL SECURITY;

--
-- Name: alerts alerts_org; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY alerts_org ON public.alerts USING ((org_id = (NULLIF(current_setting('app.org_id'::text, true), ''::text))::uuid));


--
-- Name: api_keys; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.api_keys ENABLE ROW LEVEL SECURITY;

--
-- Name: api_keys api_keys_org; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY api_keys_org ON public.api_keys USING ((org_id = (current_setting('app.org_id'::text, true))::uuid));


--
-- Name: appointments; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.appointments ENABLE ROW LEVEL SECURITY;

--
-- Name: appointments appointments_org; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY appointments_org ON public.appointments USING ((org_id = (current_setting('app.org_id'::text, true))::uuid));


--
-- Name: attachments; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.attachments ENABLE ROW LEVEL SECURITY;

--
-- Name: attachments attachments_org; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY attachments_org ON public.attachments USING ((org_id = (current_setting('app.org_id'::text, true))::uuid));


--
-- Name: audit_events; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.audit_events ENABLE ROW LEVEL SECURITY;

--
-- Name: audit_events audit_events_org; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY audit_events_org ON public.audit_events USING ((org_id = (current_setting('app.org_id'::text, true))::uuid));


--
-- Name: auth_sessions; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.auth_sessions ENABLE ROW LEVEL SECURITY;

--
-- Name: auth_sessions auth_sessions_org; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY auth_sessions_org ON public.auth_sessions USING ((EXISTS ( SELECT 1
   FROM public.users u
  WHERE ((u.id = auth_sessions.user_id) AND (u.org_id = (current_setting('app.org_id'::text, true))::uuid)))));


--
-- Name: automation_rules; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.automation_rules ENABLE ROW LEVEL SECURITY;

--
-- Name: automation_rules automation_rules_org; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY automation_rules_org ON public.automation_rules USING ((org_id = (current_setting('app.org_id'::text, true))::uuid));


--
-- Name: availability_windows; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.availability_windows ENABLE ROW LEVEL SECURITY;

--
-- Name: availability_windows availability_windows_org; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY availability_windows_org ON public.availability_windows USING ((org_id = (current_setting('app.org_id'::text, true))::uuid));


--
-- Name: board_checklist_templates; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.board_checklist_templates ENABLE ROW LEVEL SECURITY;

--
-- Name: board_checklist_templates board_checklist_templates_org; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY board_checklist_templates_org ON public.board_checklist_templates USING ((org_id = (current_setting('app.org_id'::text, true))::uuid));


--
-- Name: board_favorites; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.board_favorites ENABLE ROW LEVEL SECURITY;

--
-- Name: board_favorites board_favorites_org; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY board_favorites_org ON public.board_favorites USING ((EXISTS ( SELECT 1
   FROM public.users u
  WHERE ((u.id = board_favorites.user_id) AND (u.org_id = (current_setting('app.org_id'::text, true))::uuid)))));


--
-- Name: board_groups; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.board_groups ENABLE ROW LEVEL SECURITY;

--
-- Name: board_groups board_groups_org; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY board_groups_org ON public.board_groups USING ((org_id = (current_setting('app.org_id'::text, true))::uuid));


--
-- Name: board_members; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.board_members ENABLE ROW LEVEL SECURITY;

--
-- Name: board_members board_members_org; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY board_members_org ON public.board_members USING ((org_id = (current_setting('app.org_id'::text, true))::uuid));


--
-- Name: board_portal_exposure; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.board_portal_exposure ENABLE ROW LEVEL SECURITY;

--
-- Name: board_portal_exposure board_portal_exposure_org; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY board_portal_exposure_org ON public.board_portal_exposure USING ((org_id = (current_setting('app.org_id'::text, true))::uuid));


--
-- Name: board_status_transitions; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.board_status_transitions ENABLE ROW LEVEL SECURITY;

--
-- Name: board_status_transitions board_status_transitions_org; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY board_status_transitions_org ON public.board_status_transitions USING ((org_id = (current_setting('app.org_id'::text, true))::uuid));


--
-- Name: board_statuses; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.board_statuses ENABLE ROW LEVEL SECURITY;

--
-- Name: board_statuses board_statuses_org; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY board_statuses_org ON public.board_statuses USING ((org_id = (current_setting('app.org_id'::text, true))::uuid));


--
-- Name: boards; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.boards ENABLE ROW LEVEL SECURITY;

--
-- Name: boards boards_org; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY boards_org ON public.boards USING ((org_id = (current_setting('app.org_id'::text, true))::uuid));


--
-- Name: byok_secrets; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.byok_secrets ENABLE ROW LEVEL SECURITY;

--
-- Name: byok_secrets byok_secrets_org; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY byok_secrets_org ON public.byok_secrets USING ((org_id = (current_setting('app.org_id'::text, true))::uuid));


--
-- Name: calendar_exclusions; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.calendar_exclusions ENABLE ROW LEVEL SECURITY;

--
-- Name: calendar_exclusions calendar_exclusions_org; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY calendar_exclusions_org ON public.calendar_exclusions USING ((org_id = (current_setting('app.org_id'::text, true))::uuid));


--
-- Name: checklist_items; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.checklist_items ENABLE ROW LEVEL SECURITY;

--
-- Name: checklist_items checklist_items_org; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY checklist_items_org ON public.checklist_items USING ((org_id = (current_setting('app.org_id'::text, true))::uuid));


--
-- Name: checklist_template_items; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.checklist_template_items ENABLE ROW LEVEL SECURITY;

--
-- Name: checklist_template_items checklist_template_items_org; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY checklist_template_items_org ON public.checklist_template_items USING ((org_id = (current_setting('app.org_id'::text, true))::uuid));


--
-- Name: clients; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.clients ENABLE ROW LEVEL SECURITY;

--
-- Name: clients clients_org; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY clients_org ON public.clients USING ((org_id = (current_setting('app.org_id'::text, true))::uuid));


--
-- Name: connector_installations; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.connector_installations ENABLE ROW LEVEL SECURITY;

--
-- Name: connector_installations connector_installations_org; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY connector_installations_org ON public.connector_installations USING ((org_id = (NULLIF(current_setting('app.org_id'::text, true), ''::text))::uuid));


--
-- Name: contacts; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.contacts ENABLE ROW LEVEL SECURITY;

--
-- Name: contacts contacts_org; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY contacts_org ON public.contacts USING ((org_id = (current_setting('app.org_id'::text, true))::uuid));


--
-- Name: contract_fixed_fees; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.contract_fixed_fees ENABLE ROW LEVEL SECURITY;

--
-- Name: contract_fixed_fees contract_fixed_fees_org; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY contract_fixed_fees_org ON public.contract_fixed_fees USING ((org_id = (current_setting('app.org_id'::text, true))::uuid));


--
-- Name: contract_rates; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.contract_rates ENABLE ROW LEVEL SECURITY;

--
-- Name: contract_rates contract_rates_org; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY contract_rates_org ON public.contract_rates USING ((org_id = (current_setting('app.org_id'::text, true))::uuid));


--
-- Name: contracts; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.contracts ENABLE ROW LEVEL SECURITY;

--
-- Name: contracts contracts_org; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY contracts_org ON public.contracts USING ((org_id = (current_setting('app.org_id'::text, true))::uuid));


--
-- Name: custom_field_defs; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.custom_field_defs ENABLE ROW LEVEL SECURITY;

--
-- Name: custom_field_defs custom_field_defs_org; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY custom_field_defs_org ON public.custom_field_defs USING ((org_id = (current_setting('app.org_id'::text, true))::uuid));


--
-- Name: custom_field_values; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.custom_field_values ENABLE ROW LEVEL SECURITY;

--
-- Name: custom_field_values custom_field_values_org; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY custom_field_values_org ON public.custom_field_values USING ((org_id = (current_setting('app.org_id'::text, true))::uuid));


--
-- Name: device_assets; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.device_assets ENABLE ROW LEVEL SECURITY;

--
-- Name: device_assets device_assets_org; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY device_assets_org ON public.device_assets USING ((org_id = (current_setting('app.org_id'::text, true))::uuid));


--
-- Name: dispatch_queue_entries; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.dispatch_queue_entries ENABLE ROW LEVEL SECURITY;

--
-- Name: dispatch_queue_entries dispatch_queue_entries_org; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY dispatch_queue_entries_org ON public.dispatch_queue_entries USING ((org_id = (current_setting('app.org_id'::text, true))::uuid));


--
-- Name: dispatch_status_updates; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.dispatch_status_updates ENABLE ROW LEVEL SECURITY;

--
-- Name: dispatch_status_updates dispatch_status_updates_org; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY dispatch_status_updates_org ON public.dispatch_status_updates USING ((org_id = (current_setting('app.org_id'::text, true))::uuid));


--
-- Name: document_versions; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.document_versions ENABLE ROW LEVEL SECURITY;

--
-- Name: document_versions document_versions_org; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY document_versions_org ON public.document_versions USING ((org_id = (current_setting('app.org_id'::text, true))::uuid));


--
-- Name: documents; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.documents ENABLE ROW LEVEL SECURITY;

--
-- Name: documents documents_org; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY documents_org ON public.documents USING ((org_id = (current_setting('app.org_id'::text, true))::uuid));


--
-- Name: email_inbound_settings; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.email_inbound_settings ENABLE ROW LEVEL SECURITY;

--
-- Name: email_inbound_settings email_inbound_settings_org; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY email_inbound_settings_org ON public.email_inbound_settings USING ((org_id = (current_setting('app.org_id'::text, true))::uuid));


--
-- Name: email_messages; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.email_messages ENABLE ROW LEVEL SECURITY;

--
-- Name: email_messages email_messages_org; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY email_messages_org ON public.email_messages USING ((org_id = (current_setting('app.org_id'::text, true))::uuid));


--
-- Name: email_outbound; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.email_outbound ENABLE ROW LEVEL SECURITY;

--
-- Name: email_outbound email_outbound_org; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY email_outbound_org ON public.email_outbound USING ((org_id = (current_setting('app.org_id'::text, true))::uuid));


--
-- Name: entity_write_seqs; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.entity_write_seqs ENABLE ROW LEVEL SECURITY;

--
-- Name: entity_write_seqs entity_write_seqs_org; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY entity_write_seqs_org ON public.entity_write_seqs USING ((org_id = (current_setting('app.org_id'::text, true))::uuid));


--
-- Name: entity_writes; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.entity_writes ENABLE ROW LEVEL SECURITY;

--
-- Name: entity_writes entity_writes_org; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY entity_writes_org ON public.entity_writes USING ((org_id = (current_setting('app.org_id'::text, true))::uuid));


--
-- Name: external_ids; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.external_ids ENABLE ROW LEVEL SECURITY;

--
-- Name: external_ids external_ids_org; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY external_ids_org ON public.external_ids USING ((org_id = (current_setting('app.org_id'::text, true))::uuid));


--
-- Name: idempotency_keys; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.idempotency_keys ENABLE ROW LEVEL SECURITY;

--
-- Name: idempotency_keys idempotency_keys_org; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY idempotency_keys_org ON public.idempotency_keys USING ((org_id = (current_setting('app.org_id'::text, true))::uuid));


--
-- Name: import_batches; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.import_batches ENABLE ROW LEVEL SECURITY;

--
-- Name: import_batches import_batches_org; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY import_batches_org ON public.import_batches USING ((org_id = (current_setting('app.org_id'::text, true))::uuid));


--
-- Name: import_mapping_templates; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.import_mapping_templates ENABLE ROW LEVEL SECURITY;

--
-- Name: import_mapping_templates import_mapping_templates_org; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY import_mapping_templates_org ON public.import_mapping_templates USING ((org_id = (current_setting('app.org_id'::text, true))::uuid));


--
-- Name: invoice_lines; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.invoice_lines ENABLE ROW LEVEL SECURITY;

--
-- Name: invoice_lines invoice_lines_org; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY invoice_lines_org ON public.invoice_lines USING ((org_id = (current_setting('app.org_id'::text, true))::uuid));


--
-- Name: invoice_payments; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.invoice_payments ENABLE ROW LEVEL SECURITY;

--
-- Name: invoice_payments invoice_payments_org; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY invoice_payments_org ON public.invoice_payments USING ((org_id = (current_setting('app.org_id'::text, true))::uuid));


--
-- Name: invoice_runs; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.invoice_runs ENABLE ROW LEVEL SECURITY;

--
-- Name: invoice_runs invoice_runs_org; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY invoice_runs_org ON public.invoice_runs USING ((org_id = (current_setting('app.org_id'::text, true))::uuid));


--
-- Name: invoice_time_entries; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.invoice_time_entries ENABLE ROW LEVEL SECURITY;

--
-- Name: invoice_time_entries invoice_time_entries_org; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY invoice_time_entries_org ON public.invoice_time_entries USING ((org_id = (current_setting('app.org_id'::text, true))::uuid));


--
-- Name: invoices; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.invoices ENABLE ROW LEVEL SECURITY;

--
-- Name: invoices invoices_org; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY invoices_org ON public.invoices USING ((org_id = (current_setting('app.org_id'::text, true))::uuid));


--
-- Name: jobs; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.jobs ENABLE ROW LEVEL SECURITY;

--
-- Name: jobs jobs_org; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY jobs_org ON public.jobs USING ((org_id = (current_setting('app.org_id'::text, true))::uuid));


--
-- Name: kb_articles; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.kb_articles ENABLE ROW LEVEL SECURITY;

--
-- Name: kb_articles kb_articles_org; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY kb_articles_org ON public.kb_articles USING ((org_id = (current_setting('app.org_id'::text, true))::uuid));


--
-- Name: kb_categories; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.kb_categories ENABLE ROW LEVEL SECURITY;

--
-- Name: kb_categories kb_categories_org; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY kb_categories_org ON public.kb_categories USING ((org_id = (current_setting('app.org_id'::text, true))::uuid));


--
-- Name: mcp_capability_grants; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.mcp_capability_grants ENABLE ROW LEVEL SECURITY;

--
-- Name: mcp_capability_grants mcp_capability_grants_org; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY mcp_capability_grants_org ON public.mcp_capability_grants USING ((org_id = (current_setting('app.org_id'::text, true))::uuid));


--
-- Name: mfa_challenges; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.mfa_challenges ENABLE ROW LEVEL SECURITY;

--
-- Name: mfa_challenges mfa_challenges_org; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY mfa_challenges_org ON public.mfa_challenges USING ((org_id = (current_setting('app.org_id'::text, true))::uuid));


--
-- Name: migration_push_chunks; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.migration_push_chunks ENABLE ROW LEVEL SECURITY;

--
-- Name: migration_push_chunks migration_push_chunks_org; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY migration_push_chunks_org ON public.migration_push_chunks USING ((org_id = (current_setting('app.org_id'::text, true))::uuid));


--
-- Name: migration_push_sessions; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.migration_push_sessions ENABLE ROW LEVEL SECURITY;

--
-- Name: migration_push_sessions migration_push_sessions_org; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY migration_push_sessions_org ON public.migration_push_sessions USING ((org_id = (current_setting('app.org_id'::text, true))::uuid));


--
-- Name: notification_org_defaults; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.notification_org_defaults ENABLE ROW LEVEL SECURITY;

--
-- Name: notification_org_defaults notification_org_defaults_org; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY notification_org_defaults_org ON public.notification_org_defaults USING ((org_id = (current_setting('app.org_id'::text, true))::uuid));


--
-- Name: notification_preferences; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.notification_preferences ENABLE ROW LEVEL SECURITY;

--
-- Name: notification_preferences notification_prefs_org; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY notification_prefs_org ON public.notification_preferences USING ((EXISTS ( SELECT 1
   FROM public.users u
  WHERE ((u.id = notification_preferences.user_id) AND (u.org_id = (current_setting('app.org_id'::text, true))::uuid)))));


--
-- Name: notifications; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.notifications ENABLE ROW LEVEL SECURITY;

--
-- Name: notifications notifications_org; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY notifications_org ON public.notifications USING ((org_id = (current_setting('app.org_id'::text, true))::uuid));


--
-- Name: oidc_accounts; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.oidc_accounts ENABLE ROW LEVEL SECURITY;

--
-- Name: oidc_accounts oidc_accounts_org; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY oidc_accounts_org ON public.oidc_accounts USING ((org_id = (current_setting('app.org_id'::text, true))::uuid));


--
-- Name: oidc_providers; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.oidc_providers ENABLE ROW LEVEL SECURITY;

--
-- Name: oidc_providers oidc_providers_org; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY oidc_providers_org ON public.oidc_providers USING ((org_id = (current_setting('app.org_id'::text, true))::uuid));


--
-- Name: on_call_blocks; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.on_call_blocks ENABLE ROW LEVEL SECURITY;

--
-- Name: on_call_blocks on_call_blocks_org; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY on_call_blocks_org ON public.on_call_blocks USING ((org_id = (current_setting('app.org_id'::text, true))::uuid));


--
-- Name: orgs org_self; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY org_self ON public.orgs USING ((id = (current_setting('app.org_id'::text, true))::uuid));


--
-- Name: orgs; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.orgs ENABLE ROW LEVEL SECURITY;

--
-- Name: outbox_events; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.outbox_events ENABLE ROW LEVEL SECURITY;

--
-- Name: outbox_events outbox_events_org; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY outbox_events_org ON public.outbox_events USING ((org_id = (current_setting('app.org_id'::text, true))::uuid));


--
-- Name: portal_appointment_requests; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.portal_appointment_requests ENABLE ROW LEVEL SECURITY;

--
-- Name: portal_appointment_requests portal_appointment_requests_org; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY portal_appointment_requests_org ON public.portal_appointment_requests USING ((org_id = (current_setting('app.org_id'::text, true))::uuid));


--
-- Name: portal_sessions; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.portal_sessions ENABLE ROW LEVEL SECURITY;

--
-- Name: portal_sessions portal_sessions_org; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY portal_sessions_org ON public.portal_sessions USING ((EXISTS ( SELECT 1
   FROM public.portal_users pu
  WHERE ((pu.id = portal_sessions.portal_user_id) AND (pu.org_id = (current_setting('app.org_id'::text, true))::uuid)))));


--
-- Name: portal_users; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.portal_users ENABLE ROW LEVEL SECURITY;

--
-- Name: portal_users portal_users_org; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY portal_users_org ON public.portal_users USING ((org_id = (current_setting('app.org_id'::text, true))::uuid));


--
-- Name: project_phases; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.project_phases ENABLE ROW LEVEL SECURITY;

--
-- Name: project_phases project_phases_org; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY project_phases_org ON public.project_phases USING ((org_id = (current_setting('app.org_id'::text, true))::uuid));


--
-- Name: project_task_deps; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.project_task_deps ENABLE ROW LEVEL SECURITY;

--
-- Name: project_task_deps project_task_deps_org; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY project_task_deps_org ON public.project_task_deps USING ((org_id = (current_setting('app.org_id'::text, true))::uuid));


--
-- Name: project_tasks; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.project_tasks ENABLE ROW LEVEL SECURITY;

--
-- Name: project_tasks project_tasks_org; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY project_tasks_org ON public.project_tasks USING ((org_id = (current_setting('app.org_id'::text, true))::uuid));


--
-- Name: project_templates; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.project_templates ENABLE ROW LEVEL SECURITY;

--
-- Name: project_templates project_templates_org; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY project_templates_org ON public.project_templates USING ((org_id = (current_setting('app.org_id'::text, true))::uuid));


--
-- Name: project_views; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.project_views ENABLE ROW LEVEL SECURITY;

--
-- Name: project_views project_views_org; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY project_views_org ON public.project_views USING ((org_id = (current_setting('app.org_id'::text, true))::uuid));


--
-- Name: projects; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.projects ENABLE ROW LEVEL SECURITY;

--
-- Name: projects projects_org; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY projects_org ON public.projects USING ((org_id = (current_setting('app.org_id'::text, true))::uuid));


--
-- Name: provenance_events; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.provenance_events ENABLE ROW LEVEL SECURITY;

--
-- Name: provenance_events provenance_events_org; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY provenance_events_org ON public.provenance_events USING ((org_id = (current_setting('app.org_id'::text, true))::uuid));


--
-- Name: recovery_codes; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.recovery_codes ENABLE ROW LEVEL SECURITY;

--
-- Name: recovery_codes recovery_codes_org; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY recovery_codes_org ON public.recovery_codes USING ((org_id = (current_setting('app.org_id'::text, true))::uuid));


--
-- Name: report_definitions; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.report_definitions ENABLE ROW LEVEL SECURITY;

--
-- Name: report_definitions report_definitions_org; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY report_definitions_org ON public.report_definitions USING ((org_id = (current_setting('app.org_id'::text, true))::uuid));


--
-- Name: report_deliveries; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.report_deliveries ENABLE ROW LEVEL SECURITY;

--
-- Name: report_deliveries report_deliveries_org; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY report_deliveries_org ON public.report_deliveries USING ((org_id = (current_setting('app.org_id'::text, true))::uuid));


--
-- Name: report_schedules; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.report_schedules ENABLE ROW LEVEL SECURITY;

--
-- Name: report_schedules report_schedules_org; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY report_schedules_org ON public.report_schedules USING ((org_id = (current_setting('app.org_id'::text, true))::uuid));


--
-- Name: roles; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.roles ENABLE ROW LEVEL SECURITY;

--
-- Name: roles roles_org; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY roles_org ON public.roles USING ((org_id = (current_setting('app.org_id'::text, true))::uuid));


--
-- Name: search_index; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.search_index ENABLE ROW LEVEL SECURITY;

--
-- Name: search_index search_index_org; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY search_index_org ON public.search_index USING ((org_id = (current_setting('app.org_id'::text, true))::uuid));


--
-- Name: settings; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.settings ENABLE ROW LEVEL SECURITY;

--
-- Name: settings settings_org; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY settings_org ON public.settings USING (((org_id = (NULLIF(current_setting('app.org_id'::text, true), ''::text))::uuid) AND ((scope = 'org'::text) OR (owner_id = (NULLIF(current_setting('app.user_id'::text, true), ''::text))::uuid))));


--
-- Name: sites; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.sites ENABLE ROW LEVEL SECURITY;

--
-- Name: sites sites_org; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY sites_org ON public.sites USING ((org_id = (current_setting('app.org_id'::text, true))::uuid));


--
-- Name: sla_calendars; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.sla_calendars ENABLE ROW LEVEL SECURITY;

--
-- Name: sla_calendars sla_calendars_org; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY sla_calendars_org ON public.sla_calendars USING ((org_id = (current_setting('app.org_id'::text, true))::uuid));


--
-- Name: sla_escalation_steps; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.sla_escalation_steps ENABLE ROW LEVEL SECURITY;

--
-- Name: sla_escalation_steps sla_escalation_steps_org; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY sla_escalation_steps_org ON public.sla_escalation_steps USING ((org_id = (current_setting('app.org_id'::text, true))::uuid));


--
-- Name: sla_fired_escalations; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.sla_fired_escalations ENABLE ROW LEVEL SECURITY;

--
-- Name: sla_fired_escalations sla_fired_escalations_org; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY sla_fired_escalations_org ON public.sla_fired_escalations USING ((org_id = (current_setting('app.org_id'::text, true))::uuid));


--
-- Name: sla_policies; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.sla_policies ENABLE ROW LEVEL SECURITY;

--
-- Name: sla_policies sla_policies_org; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY sla_policies_org ON public.sla_policies USING ((org_id = (current_setting('app.org_id'::text, true))::uuid));


--
-- Name: ticket_comments; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.ticket_comments ENABLE ROW LEVEL SECURITY;

--
-- Name: ticket_comments ticket_comments_org; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY ticket_comments_org ON public.ticket_comments USING ((org_id = (current_setting('app.org_id'::text, true))::uuid));


--
-- Name: ticket_required_skills; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.ticket_required_skills ENABLE ROW LEVEL SECURITY;

--
-- Name: ticket_required_skills ticket_required_skills_org; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY ticket_required_skills_org ON public.ticket_required_skills USING ((org_id = (current_setting('app.org_id'::text, true))::uuid));


--
-- Name: ticket_sla_state; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.ticket_sla_state ENABLE ROW LEVEL SECURITY;

--
-- Name: ticket_sla_state ticket_sla_state_org; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY ticket_sla_state_org ON public.ticket_sla_state USING ((org_id = (current_setting('app.org_id'::text, true))::uuid));


--
-- Name: tickets; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.tickets ENABLE ROW LEVEL SECURITY;

--
-- Name: tickets tickets_org; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY tickets_org ON public.tickets USING ((org_id = (current_setting('app.org_id'::text, true))::uuid));


--
-- Name: time_entries; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.time_entries ENABLE ROW LEVEL SECURITY;

--
-- Name: time_entries time_entries_org; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY time_entries_org ON public.time_entries USING ((org_id = (current_setting('app.org_id'::text, true))::uuid));


--
-- Name: time_gap_audits; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.time_gap_audits ENABLE ROW LEVEL SECURITY;

--
-- Name: time_gap_audits time_gap_audits_org; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY time_gap_audits_org ON public.time_gap_audits USING ((org_id = (current_setting('app.org_id'::text, true))::uuid));


--
-- Name: timer_sessions; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.timer_sessions ENABLE ROW LEVEL SECURITY;

--
-- Name: timer_sessions timer_sessions_org; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY timer_sessions_org ON public.timer_sessions USING ((org_id = (current_setting('app.org_id'::text, true))::uuid));


--
-- Name: totp_secrets; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.totp_secrets ENABLE ROW LEVEL SECURITY;

--
-- Name: totp_secrets totp_secrets_org; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY totp_secrets_org ON public.totp_secrets USING ((org_id = (current_setting('app.org_id'::text, true))::uuid));


--
-- Name: travel_entry_drafts; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.travel_entry_drafts ENABLE ROW LEVEL SECURITY;

--
-- Name: travel_entry_drafts travel_entry_drafts_org; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY travel_entry_drafts_org ON public.travel_entry_drafts USING ((org_id = (current_setting('app.org_id'::text, true))::uuid));


--
-- Name: user_roles; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.user_roles ENABLE ROW LEVEL SECURITY;

--
-- Name: user_roles user_roles_org; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY user_roles_org ON public.user_roles USING ((EXISTS ( SELECT 1
   FROM public.users u
  WHERE ((u.id = user_roles.user_id) AND (u.org_id = (current_setting('app.org_id'::text, true))::uuid)))));


--
-- Name: user_skills; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.user_skills ENABLE ROW LEVEL SECURITY;

--
-- Name: user_skills user_skills_org; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY user_skills_org ON public.user_skills USING ((org_id = (current_setting('app.org_id'::text, true))::uuid));


--
-- Name: users; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.users ENABLE ROW LEVEL SECURITY;

--
-- Name: users users_org; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY users_org ON public.users USING ((org_id = (current_setting('app.org_id'::text, true))::uuid));


--
-- Name: webauthn_credentials; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.webauthn_credentials ENABLE ROW LEVEL SECURITY;

--
-- Name: webauthn_credentials webauthn_credentials_org; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY webauthn_credentials_org ON public.webauthn_credentials USING ((org_id = (current_setting('app.org_id'::text, true))::uuid));


--
-- Name: webhook_deliveries; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.webhook_deliveries ENABLE ROW LEVEL SECURITY;

--
-- Name: webhook_deliveries webhook_deliveries_org; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY webhook_deliveries_org ON public.webhook_deliveries USING ((org_id = (NULLIF(current_setting('app.org_id'::text, true), ''::text))::uuid));


--
-- Name: webhooks; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.webhooks ENABLE ROW LEVEL SECURITY;

--
-- Name: webhooks webhooks_org; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY webhooks_org ON public.webhooks USING ((org_id = (NULLIF(current_setting('app.org_id'::text, true), ''::text))::uuid));


--
-- PostgreSQL database dump complete
--

\unrestrict bZZcbRdii1dkMa7O6qIapMTOJLSQnshgmkgU2aSVjLAIz2XTiXCojw3hdeVfJgP

